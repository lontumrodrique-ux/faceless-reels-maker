# Faceless Reels Maker (Android)

Paste a script, import pictures, pick a voice and an editing style, tap GENERATE, and get a
1080 x 1920 vertical MP4 (H.264 + AAC, up to 2 minutes) for Facebook Reels, TikTok and YouTube Shorts.

## Get the APK
Every push to `main` builds the app with GitHub Actions and publishes `FacelessReelsMaker.apk`
under **Releases**. Download it on the phone and install it (allow "install unknown apps").

## Works offline
Script editing, pictures, phone text-to-speech voices, subtitles, built-in music, rendering, export.

## Needs internet (optional)
Online AI voices (ElevenLabs or an OpenAI-style speech service) with your own API key.
The voice service bills you directly; the app adds no fee, ads or subscription.
