package com.lontum.facelessreels

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object AppState {
    var screen by mutableStateOf("home")
    var project by mutableStateOf<Project?>(null)
    var listTick by mutableStateOf(0)

    fun edit(f: (Project) -> Project) {
        val p = project ?: return
        project = f(p).copy(updated = System.currentTimeMillis())
    }
}

val Accent = Color(0xFF8B6CFF)
val Gold = Color(0xFFFFD54A)
val Danger = Color(0xFFFF6B6B)
val Good = Color(0xFF69F0AE)

private val AppColors = darkColorScheme(
    primary = Accent,
    onPrimary = Color.White,
    secondary = Gold,
    onSecondary = Color.Black,
    background = Color(0xFF0E0F14),
    onBackground = Color(0xFFECEDF2),
    surface = Color(0xFF181A22),
    onSurface = Color(0xFFECEDF2),
    surfaceVariant = Color(0xFF242733),
    onSurfaceVariant = Color(0xFFA9ADBD),
    error = Danger,
    outline = Color(0xFF3A3E4D)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Settings.init(applicationContext)
        Narrator.clearOld(applicationContext)
        setContent {
            MaterialTheme(colorScheme = AppColors) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { App() }
            }
        }
    }

    override fun onStop() {
        super.onStop()
        AppState.project?.let { Store.save(applicationContext, it) }
        PhoneTts.stop()
        PcmPlayer.stop()
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val p = AppState.project

    // Automatic saving: every change is written shortly after it happens.
    LaunchedEffect(p) {
        if (p != null) {
            delay(400)
            withContext(Dispatchers.IO) { Store.save(ctx, p) }
        }
    }

    val back: () -> Unit = {
        PhoneTts.stop()
        PcmPlayer.stop()
        when (AppState.screen) {
            "home" -> {}
            "hub" -> {
                AppState.project?.let { Store.save(ctx, it) }
                AppState.project = null
                AppState.listTick++
                AppState.screen = "home"
            }
            "scenes" -> AppState.screen = "script"
            else -> AppState.screen = "hub"
        }
    }
    BackHandler(enabled = AppState.screen != "home") { back() }

    if (p == null) {
        HomeScreen()
    } else {
        when (AppState.screen) {
            "script" -> ScriptScreen(p, back)
            "scenes" -> ScenesScreen(p, back)
            "pictures" -> PicturesScreen(p, back)
            "voice" -> VoiceScreen(p, back)
            "style" -> StyleScreen(p, back)
            "subs" -> SubtitleScreen(p, back)
            "music" -> MusicScreen(p, back)
            "preview" -> PreviewScreen(p, back)
            else -> HubScreen(p, back)
        }
    }
}

// ---------- shared pieces ----------

@Composable
fun Screen(title: String, onBack: (() -> Unit)?, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Row(Modifier.fillMaxWidth().height(56.dp), verticalAlignment = Alignment.CenterVertically) {
            if (onBack != null) {
                IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = Color.White) }
            } else Spacer(Modifier.width(16.dp))
            Text(title, fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Color.White, maxLines = 1,
                overflow = TextOverflow.Ellipsis)
        }
        content()
    }
}

@Composable
fun BigButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, gold: Boolean = false, onClick: () -> Unit) {
    val brush = if (!enabled) Brush.horizontalGradient(listOf(Color(0xFF2B2E3A), Color(0xFF2B2E3A)))
    else if (gold) Brush.horizontalGradient(listOf(Color(0xFFFFB300), Gold))
    else Brush.horizontalGradient(listOf(Color(0xFF6A4DFF), Color(0xFFB06CFF)))
    Box(
        modifier.fillMaxWidth().height(56.dp).clip(RoundedCornerShape(16.dp)).background(brush)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(text, fontWeight = FontWeight.Bold, fontSize = 16.sp,
            color = if (!enabled) Color(0xFF777B8C) else if (gold) Color.Black else Color.White)
    }
}

@Composable
fun SmallButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    Box(
        modifier.clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable(enabled = enabled, onClick = onClick).padding(horizontal = 14.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, fontSize = 14.sp, fontWeight = FontWeight.Medium,
            color = if (enabled) Color.White else Color(0xFF777B8C))
    }
}

@Composable
fun Chip(text: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.padding(end = 8.dp, bottom = 8.dp).clip(RoundedCornerShape(50))
            .background(if (selected) Accent else MaterialTheme.colorScheme.surfaceVariant)
            .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 9.dp)
    ) {
        Text(text, fontSize = 14.sp, color = Color.White, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
    }
}

@Composable
fun Panel(modifier: Modifier = Modifier, selected: Boolean = false, onClick: (() -> Unit)? = null,
          content: @Composable ColumnScope.() -> Unit) {
    var m = modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
        .background(if (selected) Color(0xFF2A2350) else MaterialTheme.colorScheme.surface)
    if (onClick != null) m = m.clickable(onClick = onClick)
    Column(m.padding(16.dp), content = content)
}

@Composable
fun Label(text: String) {
    Text(text, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(top = 18.dp, bottom = 8.dp))
}

@Composable
fun Note(text: String, color: Color = MaterialTheme.colorScheme.onSurfaceVariant) {
    Text(text, fontSize = 13.sp, color = color, lineHeight = 18.sp)
}

fun fmtTime(sec: Float): String {
    val s = sec.toInt()
    return if (s >= 60) "${s / 60} min ${s % 60} s" else "$s s"
}

// ---------- home ----------

@Composable
fun HomeScreen() {
    val ctx = LocalContext.current
    val tick = AppState.listTick
    val projects = remember(tick) { Store.list(ctx) }
    var confirmDelete by remember { mutableStateOf<Project?>(null) }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).verticalScroll(rememberScrollState())
        .padding(20.dp)) {
        Spacer(Modifier.height(12.dp))
        Text("Faceless Reels Maker", fontSize = 28.sp, fontWeight = FontWeight.Black, color = Color.White)
        Text("Script + pictures in. Finished vertical video out.", fontSize = 14.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(24.dp))
        BigButton("＋  CREATE NEW VIDEO") {
            val np = Store.create(ctx)
            AppState.project = np
            AppState.screen = "hub"
        }
        Label("MY SAVED PROJECTS")
        if (projects.isEmpty()) {
            Panel { Note("No projects yet. Tap CREATE NEW VIDEO to start. Everything you type is saved automatically.") }
        }
        val df = remember { SimpleDateFormat("d MMM yyyy, HH:mm", Locale.getDefault()) }
        for (pr in projects) {
            Panel(Modifier.padding(bottom = 10.dp), onClick = {
                AppState.project = pr
                AppState.screen = "hub"
            }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(pr.name, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 16.sp, maxLines = 1,
                            overflow = TextOverflow.Ellipsis)
                        Note("${ScriptTools.wordCount(pr.script)} words · ${pr.pics.size} pictures · " + df.format(Date(pr.updated)))
                    }
                    IconButton(onClick = { confirmDelete = pr }) {
                        Icon(Icons.Filled.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
        Spacer(Modifier.height(20.dp))
        Note("Works offline with your phone's voices. Online AI voices are optional and need your own paid key. No ads, no hidden subscription, no social-media logins.")
    }

    val del = confirmDelete
    if (del != null) {
        AlertDialog(
            onDismissRequest = { confirmDelete = null },
            title = { Text("Delete \"${del.name}\"?") },
            text = { Text("The script, pictures and preview of this project will be removed from the app. Videos already exported to your gallery stay.") },
            confirmButton = {
                TextButton(onClick = {
                    Store.delete(ctx, del.id)
                    confirmDelete = null
                    AppState.listTick++
                }) { Text("Delete", color = Danger) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = null }) { Text("Cancel") } }
        )
    }
}

// ---------- project hub ----------

@Composable
private fun HubRow(step: String, title: String, summary: String, ok: Boolean, onClick: () -> Unit) {
    Panel(Modifier.padding(bottom = 10.dp), onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(34.dp).clip(CircleShape).background(if (ok) Accent else MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center) {
                Text(step, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 15.sp)
                Text(summary, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2,
                    overflow = TextOverflow.Ellipsis)
            }
            Text("›", fontSize = 24.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun HubScreen(p: Project, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val words = ScriptTools.wordCount(p.script)
    val est = ScriptTools.estimateSeconds(p.script, p.voice.speed * Styles.narr[p.voice.narr.coerceIn(0, Styles.narr.size - 1)].rate)
    val style = Styles.styles[p.style.coerceIn(0, Styles.styles.size - 1)]
    var problem by remember { mutableStateOf<String?>(null) }

    Screen("Project", onBack) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
            OutlinedTextField(
                value = p.name, onValueChange = { v -> AppState.edit { it.copy(name = v.take(60)) } },
                label = { Text("Project name") }, singleLine = true, modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(14.dp))
            HubRow("1", "PASTE YOUR SCRIPT",
                if (words == 0) "Empty. Paste or type the narration here."
                else "$words words · about ${fmtTime(est)} · ${ScriptTools.scenes(p.script).size} scenes" +
                    (if (est > 120f) " · TOO LONG" else ""),
                words > 0) { AppState.screen = "script" }
            HubRow("2", "IMPORT PICTURES",
                if (p.pics.isEmpty()) "No pictures yet. Pick them from your gallery." else "${p.pics.size} pictures imported",
                p.pics.isNotEmpty()) { AppState.screen = "pictures" }
            HubRow("3", "SELECT VOICEOVER",
                (if (p.voice.engine == "online") "Online AI voice" else "Phone voice (offline)") + " · " +
                    Styles.narr[p.voice.narr.coerceIn(0, Styles.narr.size - 1)].name + " · speed ${"%.2f".format(p.voice.speed)}×",
                true) { AppState.screen = "voice" }
            HubRow("4", "SELECT EDITING STYLE", style.name, true) { AppState.screen = "style" }
            HubRow("5", "SUBTITLES AND CAPTIONS",
                if (p.sub.on) "On · word-by-word highlight " + (if (p.sub.wordHi) "on" else "off") else "Off",
                true) { AppState.screen = "subs" }
            HubRow("6", "ADD BACKGROUND MUSIC",
                when (p.music.kind) {
                    "none" -> "No music"
                    "file" -> "My music: " + p.music.fileName
                    "mood" -> "Built-in: " + Styles.moodNames[p.music.mood.coerceIn(0, 7)]
                    else -> "Matches the editing style (" + Styles.moodNames[style.mood] + ")"
                }, true) { AppState.screen = "music" }
            HubRow("7", "VIDEO PREVIEW  ·  EXPORT VIDEO",
                if (RenderEngine.isFresh(ctx, p)) "Video is ready to watch and export"
                else if (RenderEngine.outputFile(ctx, p.id).exists()) "Settings changed since the last video. Generate again."
                else "Nothing generated yet",
                RenderEngine.isFresh(ctx, p)) { AppState.screen = "preview" }
            Spacer(Modifier.height(8.dp))
        }
        Column(Modifier.padding(16.dp)) {
            BigButton(if (RenderManager.running) "GENERATING…  OPEN PROGRESS" else "GENERATE VIDEO") {
                if (RenderManager.running) { AppState.screen = "preview"; return@BigButton }
                val issue = generateProblem(p)
                if (issue != null) problem = issue
                else {
                    Store.save(ctx, p)
                    RenderManager.start(ctx, p)
                    AppState.screen = "preview"
                }
            }
        }
    }

    val pr = problem
    if (pr != null) {
        AlertDialog(onDismissRequest = { problem = null }, title = { Text("Not ready yet") }, text = { Text(pr) },
            confirmButton = { TextButton(onClick = { problem = null }) { Text("OK") } })
    }
}

/** Returns what is missing before a video can be generated, or null when everything is in place. */
fun generateProblem(p: Project): String? {
    if (p.script.isBlank()) return "Paste your script first (step 1)."
    if (p.pics.isEmpty()) return "Import at least one picture (step 2)."
    if (p.voice.engine == "online" && !Settings.onlineReady())
        return "Online AI voice is selected, but its API key or voice is not set. Open SELECT VOICEOVER to finish the setup, or switch to the free phone voice."
    return null
}
