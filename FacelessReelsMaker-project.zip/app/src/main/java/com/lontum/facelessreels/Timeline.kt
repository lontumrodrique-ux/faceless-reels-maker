package com.lontum.facelessreels

import android.content.Context
import kotlin.coroutines.cancellation.CancellationException
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min

class Word(val text: String, val start: Float, val end: Float)
class Cue(val start: Float, var end: Float, val words: List<Word>, val speaker: String = "")

class Shot(
    val pic: Int, val start: Float, val end: Float,
    val tIn: Int, val tDur: Float,
    val z0: Float, val z1: Float, val x0: Float, val x1: Float, val y0: Float, val y1: Float
) {
    var vis0 = start
    var vis1 = end
}

class Timeline(
    val total: Float,
    val shots: List<Shot>,
    val cues: List<Cue>,
    val narration: ShortArray
)

class TooLongException(val seconds: Float) : Exception(
    "The narration is ${seconds.toInt()} seconds, but the limit is 120 seconds. " +
        "Nothing was cut. Shorten the script or raise the narration speed, then generate again."
)

object TimelineBuilder {
    private const val LEAD = 0.5f
    private const val SENT_GAP = 0.14f
    private const val SCENE_GAP = 0.5f
    private const val TAIL = 1.6f
    const val MAX_SECONDS = 120f

    fun timeWords(text: String, t0: Float, t1: Float, into: MutableList<Word>) {
        val toks = text.split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (toks.isEmpty()) return
        val w = FloatArray(toks.size)
        for (k in toks.indices) {
            val tk = toks[k]
            var x = tk.count { it.isLetterOrDigit() } + 2f
            if (k < toks.size - 1) {
                val last = tk.last()
                if (last == ',' || last == ';' || last == ':' || last == '—') x += 2f
                if (last == '.' || last == '!' || last == '?' || last == '…') x += 3f
            }
            w[k] = x
        }
        val sum = w.sum()
        var acc = 0f
        for (k in toks.indices) {
            val a = t0 + (t1 - t0) * acc / sum
            acc += w[k]
            val b = t0 + (t1 - t0) * acc / sum
            into.add(Word(toks[k], a, b))
        }
    }

    private fun makeShot(pic: Int, s0: Float, s1: Float, tIn: Int, tDur: Float, n: Int, aspect: Float, z: Float): Shot {
        val dur = s1 - s0
        val wide = aspect > 0.75f
        val travel = min(0.8f, 0.18f * dur)
        val a = 0.5f - travel / 2
        val b = 0.5f + travel / 2
        return if (wide) {
            when (n % 4) {
                0 -> Shot(pic, s0, s1, tIn, tDur, 1.0f, 1f + z * 0.4f, a, b, 0.5f, 0.5f)
                1 -> Shot(pic, s0, s1, tIn, tDur, 1.0f, 1f + z, 0.5f, 0.5f, 0.5f, 0.5f)
                2 -> Shot(pic, s0, s1, tIn, tDur, 1f + z * 0.4f, 1.0f, b, a, 0.5f, 0.5f)
                else -> Shot(pic, s0, s1, tIn, tDur, 1f + z, 1.0f, 0.4f, 0.6f, 0.5f, 0.5f)
            }
        } else {
            when (n % 4) {
                0 -> Shot(pic, s0, s1, tIn, tDur, 1.0f, 1f + z, 0.5f, 0.5f, 0.5f, 0.45f)
                1 -> Shot(pic, s0, s1, tIn, tDur, 1f + z * 0.6f, 1f + z * 0.6f, 0.5f, 0.5f, b, a)
                2 -> Shot(pic, s0, s1, tIn, tDur, 1f + z, 1.0f, 0.5f, 0.5f, 0.45f, 0.5f)
                else -> Shot(pic, s0, s1, tIn, tDur, 1f + z * 0.6f, 1f + z * 0.6f, 0.5f, 0.5f, a, b)
            }
        }
    }

    suspend fun build(
        ctx: Context, p: Project, aspects: FloatArray,
        progress: (Float, String) -> Unit, cancelled: () -> Boolean
    ): Timeline {
        val scenes = ScriptTools.scenes(p.script)
        if (scenes.isEmpty()) throw Exception("Paste your script first.")
        if (p.pics.isEmpty()) throw Exception("Import at least one picture.")
        val n = scenes.size
        val style = Styles.styles[p.style.coerceIn(0, Styles.styles.size - 1)]

        // 1. Voice for every sentence.
        val sentLists = scenes.map { ScriptTools.sentences(it).ifEmpty { listOf(it) } }
        val totalSent = max(1, sentLists.sumOf { it.size })
        var done = 0
        val audio = ArrayList<List<ShortArray>>()
        for (sl in sentLists) {
            val l = ArrayList<ShortArray>()
            for (s in sl) {
                if (cancelled()) throw CancellationException("Cancelled")
                l.add(Narrator.sentence(ctx, p.voice, s))
                done++
                progress(done.toFloat() / totalSent, "Generating voice $done of $totalSent")
            }
            audio.add(l)
        }

        // 2. Place narration on the timeline with natural pauses.
        var cur = (LEAD * SR).toInt()
        val sceneStart = IntArray(n)
        val sceneSpeechEnd = IntArray(n)
        val sentStart = ArrayList<IntArray>()
        for (i in 0 until n) {
            sceneStart[i] = cur
            val st = IntArray(audio[i].size)
            for (j in audio[i].indices) {
                st[j] = cur
                cur += audio[i][j].size
                if (j < audio[i].size - 1) cur += (SENT_GAP * SR).toInt()
            }
            sceneSpeechEnd[i] = cur
            sentStart.add(st)
            if (i < n - 1) cur += (SCENE_GAP * SR).toInt()
        }
        val totalN = cur + (TAIL * SR).toInt()
        val total = totalN.toFloat() / SR
        if (total > MAX_SECONDS + 0.5f) throw TooLongException(total)
        val narr = ShortArray(totalN)
        for (i in 0 until n) for (j in audio[i].indices) {
            val a = audio[i][j]
            System.arraycopy(a, 0, narr, sentStart[i][j], a.size)
        }

        // 3. Subtitles with a time for every word.
        val maxChars = if (style.upper) 16 else 18
        val maxWords = 3
        val cues = ArrayList<Cue>()
        var curW = ArrayList<Word>()
        var chars = 0
        fun flush() {
            if (curW.isNotEmpty()) {
                cues.add(Cue(curW.first().start, curW.last().end, curW.toList()))
                curW = ArrayList()
                chars = 0
            }
        }
        fun group(ws: List<Word>) {
            for (w in ws) {
                if (curW.isNotEmpty() && (curW.size >= maxWords || chars + w.text.length + 1 > maxChars)) flush()
                curW.add(w)
                chars += w.text.length + 1
                val last = w.text.last()
                if (last == '.' || last == '!' || last == '?' || last == '…') flush()
            }
            flush()
        }
        for (i in 0 until n) {
            val edit = p.subEdits[scenes[i]]
            if (edit != null && edit.isNotBlank()) {
                val ws = ArrayList<Word>()
                timeWords(edit.trim(), sceneStart[i].toFloat() / SR, sceneSpeechEnd[i].toFloat() / SR, ws)
                group(ws)
            } else {
                for (j in sentLists[i].indices) {
                    val ws = ArrayList<Word>()
                    val t0 = sentStart[i][j].toFloat() / SR
                    val t1 = (sentStart[i][j] + audio[i][j].size).toFloat() / SR
                    timeWords(sentLists[i][j], t0 + 0.03f, t1 - 0.06f, ws)
                    group(ws)
                }
            }
        }
        for (i in cues.indices) {
            val next = if (i + 1 < cues.size) cues[i + 1].start else Float.MAX_VALUE
            cues[i].end = min(next, cues[i].end + 0.3f)
        }

        // 4. Decide which picture is on screen when.
        val sT0 = FloatArray(n) { i -> if (i == 0) 0f else sceneStart[i].toFloat() / SR - SCENE_GAP / 2 }
        val sT1 = FloatArray(n) { i -> if (i == n - 1) total else sT0[i + 1] }
        val perScene = Array(n) { ArrayList<Int>() }
        val un = ArrayList<Int>()
        p.pics.forEachIndexed { idx, pic -> if (pic.scene in 0 until n) perScene[pic.scene].add(idx) else un.add(idx) }
        val free = (0 until n).filter { perScene[it].isEmpty() }
        val targets = if (free.isEmpty()) (0 until n).toList() else free
        if (un.isNotEmpty()) {
            val durs = targets.map { sT1[it] - sT0[it] }
            val sum = durs.sum()
            for ((k, idx) in un.withIndex()) {
                val pos = (k + 0.5f) / un.size * sum
                var acc = 0f
                var chosen = targets.last()
                for (ti in targets.indices) {
                    acc += durs[ti]
                    if (pos <= acc) { chosen = targets[ti]; break }
                }
                perScene[chosen].add(idx)
            }
        }
        var lastPic = perScene.firstOrNull { it.isNotEmpty() }?.first() ?: 0
        for (i in 0 until n) {
            if (perScene[i].isEmpty()) perScene[i].add(lastPic) else lastPic = perScene[i].last()
        }

        val shots = ArrayList<Shot>()
        var counter = 0
        var transCounter = 0
        for (i in 0 until n) {
            val dur = sT1[i] - sT0[i]
            var list: List<Int> = perScene[i]
            val maxC = max(1, (dur / 1.2f).toInt())
            if (list.size > maxC) {
                val src = list
                list = (0 until maxC).map { src[it * src.size / maxC] }
            }
            val each = dur / list.size
            for ((k, picIdx) in list.withIndex()) {
                val a = sT0[i] + k * each
                val parts = max(1, ceil(each / style.maxShot).toInt())
                val pd = each / parts
                for (q in 0 until parts) {
                    val s0 = a + q * pd
                    val s1 = s0 + pd
                    val prev = shots.lastOrNull()
                    val tIn = if (prev == null || prev.pic == picIdx) T_CUT
                    else style.transitions[transCounter++ % style.transitions.size]
                    val prevDur = if (prev == null) 0f else prev.end - prev.start
                    val tDur = if (tIn == T_CUT) 0f else min(style.transDur, 0.6f * min(pd, prevDur))
                    shots.add(makeShot(picIdx, s0, s1, tIn, tDur, counter++, aspects[picIdx], style.zoom))
                }
            }
        }
        for (i in shots.indices) {
            shots[i].vis0 = shots[i].start - shots[i].tDur / 2
            shots[i].vis1 = shots[i].end + (if (i + 1 < shots.size) shots[i + 1].tDur / 2 else 0f)
        }
        return Timeline(total, shots, cues, narr)
    }
}
