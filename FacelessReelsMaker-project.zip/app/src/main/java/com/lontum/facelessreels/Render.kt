package com.lontum.facelessreels

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.Shader
import android.media.ExifInterface
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaScannerConnection
import android.net.Uri
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLExt
import android.opengl.EGLSurface
import android.opengl.GLES20
import android.opengl.GLUtils
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.view.Surface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import kotlin.coroutines.cancellation.CancellationException
import kotlin.math.PI
import kotlin.math.ceil
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

object ImageLoader {
    private fun rotation(path: String): Int = try {
        when (ExifInterface(path).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90
            ExifInterface.ORIENTATION_ROTATE_180 -> 180
            ExifInterface.ORIENTATION_ROTATE_270 -> 270
            else -> 0
        }
    } catch (_: Exception) { 0 }

    private fun bounds(path: String): Pair<Int, Int> {
        val o = BitmapFactory.Options()
        o.inJustDecodeBounds = true
        BitmapFactory.decodeFile(path, o)
        return Pair(o.outWidth, o.outHeight)
    }

    /** Width divided by height, after applying the photo's rotation. */
    fun aspect(path: String): Float {
        val (w, h) = bounds(path)
        if (w <= 0 || h <= 0) throw Exception("One of the pictures could not be opened. Remove it and import it again.")
        val rot = rotation(path)
        return if (rot == 90 || rot == 270) h.toFloat() / w else w.toFloat() / h
    }

    /** Loads a picture just large enough to fill needW x needH, never wasting memory on more. */
    fun load(path: String, needW: Int, needH: Int): Bitmap {
        val (w, h) = bounds(path)
        if (w <= 0 || h <= 0) throw Exception("One of the pictures could not be opened. Remove it and import it again.")
        val rot = rotation(path)
        val nw = if (rot == 90 || rot == 270) needH else needW
        val nh = if (rot == 90 || rot == 270) needW else needH
        var sample = 1
        while (w / (sample * 2) >= nw && h / (sample * 2) >= nh) sample *= 2
        while (max(w, h) / sample > 3200) sample *= 2
        val o = BitmapFactory.Options()
        o.inSampleSize = sample
        o.inPreferredConfig = Bitmap.Config.ARGB_8888
        val b = BitmapFactory.decodeFile(path, o)
            ?: throw Exception("One of the pictures could not be opened. Remove it and import it again.")
        if (rot == 0) return b
        val m = Matrix()
        m.postRotate(rot.toFloat())
        val r = Bitmap.createBitmap(b, 0, 0, b.width, b.height, m, true)
        if (r != b) b.recycle()
        return r
    }

    fun thumb(path: String, size: Int): Bitmap? = try { load(path, size, size) } catch (_: Exception) { null }
}

private fun smooth(x: Float): Float = x * x * (3f - 2f * x)
private fun lerp(a: Float, b: Float, u: Float): Float = a + (b - a) * u

/** Draws one complete video frame (picture motion, transition, colour look, subtitles) onto a canvas. */
class FramePainter(private val p: Project, private val tl: Timeline, private val W: Int, private val H: Int) {
    private val style = Styles.styles[p.style.coerceIn(0, Styles.styles.size - 1)]
    private val platform = Styles.platforms[p.platform.coerceIn(0, Styles.platforms.size - 1)]
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val overlay = Paint()
    private val plain = Paint(Paint.FILTER_BITMAP_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val m = Matrix()
    private val cache = LinkedHashMap<Int, Bitmap>(8, 0.75f, true)
    private var vignette: Bitmap? = null
    private val full = Rect(0, 0, W, H)
    private var si = 0
    private var ci = 0

    private val look = if (p.sub.look >= 0) p.sub.look else style.subLook
    private val baseColor = Styles.colors[(if (p.sub.color >= 0) p.sub.color else style.subColor).coerceIn(0, Styles.colors.size - 1)]
    private val hiColor = Styles.colors[(if (p.sub.hi >= 0) p.sub.hi else style.subHi).coerceIn(0, Styles.colors.size - 1)]
    private val posY = when (p.sub.pos) { 0 -> 0.2f; 1 -> 0.5f; 2 -> 0.75f; else -> platform.subY }

    init {
        val cm = ColorMatrix()
        cm.setSaturation(style.sat)
        val c = style.contrast
        val o = 128f * (1f - c)
        cm.postConcat(ColorMatrix(floatArrayOf(c, 0f, 0f, 0f, o, 0f, c, 0f, 0f, o, 0f, 0f, c, 0f, o, 0f, 0f, 0f, 1f, 0f)))
        if (style.tintAmt > 0f) {
            val a = style.tintAmt
            val k = 1f - a
            cm.postConcat(ColorMatrix(floatArrayOf(
                k, 0f, 0f, 0f, a * Color.red(style.tint),
                0f, k, 0f, 0f, a * Color.green(style.tint),
                0f, 0f, k, 0f, a * Color.blue(style.tint),
                0f, 0f, 0f, 1f, 0f
            )))
        }
        bmpPaint.colorFilter = ColorMatrixColorFilter(cm)

        val tf = Styles.typeface(if (p.sub.font >= 0) p.sub.font else style.subFont)
        textPaint.typeface = tf
        strokePaint.typeface = tf
        strokePaint.style = Paint.Style.STROKE
        strokePaint.strokeJoin = Paint.Join.ROUND
        strokePaint.color = Color.BLACK

        if (style.vignette > 0.01f) {
            val vw = W / 4
            val vh = H / 4
            val vb = Bitmap.createBitmap(vw, vh, Bitmap.Config.ARGB_8888)
            val vp = Paint()
            vp.shader = RadialGradient(
                vw / 2f, vh / 2f, hypot(vw / 2f, vh / 2f),
                intArrayOf(0, 0, Color.argb((style.vignette * 255).toInt(), 0, 0, 0)),
                floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
            )
            Canvas(vb).drawRect(0f, 0f, vw.toFloat(), vh.toFloat(), vp)
            vignette = vb
        }
    }

    private fun bitmap(idx: Int): Bitmap {
        cache[idx]?.let { return it }
        while (cache.size >= 3) {
            val k = cache.keys.first()
            cache.remove(k)?.recycle()
        }
        val b = ImageLoader.load(p.pics[idx].file, (W * 1.25f).toInt(), (H * 1.25f).toInt())
        cache[idx] = b
        return b
    }

    private fun drawShot(c: Canvas, s: Shot, t: Float, alpha: Float, extra: Float, dx: Float) {
        val bmp = bitmap(s.pic)
        val span = max(0.001f, s.vis1 - s.vis0)
        var u = ((t - s.vis0) / span).coerceIn(0f, 1f)
        u = u * 0.7f + smooth(u) * 0.3f
        val zoom = lerp(s.z0, s.z1, u) * extra
        val cover = max(W.toFloat() / bmp.width, H.toFloat() / bmp.height)
        val sc = cover * zoom
        val ox = (bmp.width * sc - W) * lerp(s.x0, s.x1, u)
        val oy = (bmp.height * sc - H) * lerp(s.y0, s.y1, u)
        m.reset()
        m.setScale(sc, sc)
        m.postTranslate(-ox + dx, -oy)
        bmpPaint.alpha = (alpha.coerceIn(0f, 1f) * 255).toInt()
        c.drawBitmap(bmp, m, bmpPaint)
    }

    private fun wash(c: Canvas, color: Int, alpha: Float) {
        overlay.color = color
        overlay.alpha = (alpha.coerceIn(0f, 1f) * 255).toInt()
        c.drawRect(0f, 0f, W.toFloat(), H.toFloat(), overlay)
    }

    private fun transition(c: Canvas, a: Shot, b: Shot, pr: Float, t: Float) {
        val e = smooth(pr)
        when (b.tIn) {
            T_BLACK -> {
                if (pr < 0.5f) { drawShot(c, a, t, 1f, 1f, 0f); wash(c, Color.BLACK, pr * 2f) }
                else { drawShot(c, b, t, 1f, 1f, 0f); wash(c, Color.BLACK, (1f - pr) * 2f) }
            }
            T_FLASH -> {
                drawShot(c, if (pr < 0.5f) a else b, t, 1f, 1f, 0f)
                wash(c, Color.WHITE, sin(PI * pr).toFloat() * 0.85f)
            }
            T_SLIDE -> {
                drawShot(c, a, t, 1f, 1f, -e * W)
                drawShot(c, b, t, 1f, 1f, (1f - e) * W)
            }
            T_ZOOM -> {
                drawShot(c, a, t, 1f, 1f + 0.35f * e, 0f)
                drawShot(c, b, t, e, 1.35f - 0.35f * e, 0f)
            }
            else -> {
                drawShot(c, a, t, 1f, 1f, 0f)
                drawShot(c, b, t, e, 1f, 0f)
            }
        }
    }

    fun draw(c: Canvas, t: Float) {
        c.drawColor(Color.BLACK)
        val shots = tl.shots
        while (si < shots.size - 1 && t >= shots[si].end) si++
        while (si > 0 && t < shots[si].start) si--
        val cur = shots[si]
        val next = if (si + 1 < shots.size) shots[si + 1] else null
        if (next != null && next.tIn != T_CUT && next.tDur > 0f && t > cur.end - next.tDur / 2) {
            transition(c, cur, next, ((t - (cur.end - next.tDur / 2)) / next.tDur).coerceIn(0f, 1f), t)
        } else if (si > 0 && cur.tIn != T_CUT && cur.tDur > 0f && t < cur.start + cur.tDur / 2) {
            transition(c, shots[si - 1], cur, ((t - (cur.start - cur.tDur / 2)) / cur.tDur).coerceIn(0f, 1f), t)
        } else {
            // Opening: a quick push-in on the very first picture to hook the viewer.
            val boost = if (t < 0.9f) { val q = 1f - t / 0.9f; 1f + 0.12f * q * q } else 1f
            drawShot(c, cur, t, 1f, boost, 0f)
        }
        vignette?.let { c.drawBitmap(it, null, full, plain) }
        if (p.sub.on) drawSubs(c, t)
        if (t < 0.5f) wash(c, Color.BLACK, 1f - t / 0.5f)
        if (t > tl.total - 1.0f) wash(c, Color.BLACK, (t - (tl.total - 1.0f)) / 1.0f)
    }

    private fun drawSubs(c: Canvas, t: Float) {
        val cues = tl.cues
        if (cues.isEmpty()) return
        while (ci < cues.size - 1 && t >= cues[ci].end) ci++
        while (ci > 0 && t < cues[ci].start) ci--
        val cue = cues[ci]
        if (t < cue.start || t >= cue.end) return
        val texts = cue.words.map { if (style.upper) it.text.uppercase() else it.text }
        val maxW = W * platform.maxTextWidth
        var size = W * 0.078f * p.sub.size
        textPaint.textSize = size
        var widest = 0f
        for (s in texts) widest = max(widest, textPaint.measureText(s))
        if (widest > maxW) { size *= maxW / widest; textPaint.textSize = size }
        strokePaint.textSize = size
        strokePaint.strokeWidth = size * (if (look == 1) 0.07f else 0.17f)
        val space = textPaint.measureText(" ")
        val widths = FloatArray(texts.size) { textPaint.measureText(texts[it]) }

        val lineStart = ArrayList<Int>()
        val lineEnd = ArrayList<Int>()
        val lineW = ArrayList<Float>()
        var st = 0
        var lw = 0f
        for (i in texts.indices) {
            val add = widths[i] + (if (i > st) space else 0f)
            if (i > st && lw + add > maxW) {
                lineStart.add(st); lineEnd.add(i); lineW.add(lw)
                st = i; lw = widths[i]
            } else lw += add
        }
        lineStart.add(st); lineEnd.add(texts.size); lineW.add(lw)

        var active = 0
        for (i in cue.words.indices) if (t >= cue.words[i].start) active = i
        val lineH = size * 1.24f
        val blockH = lineH * lineStart.size
        val cy = H * posY
        val appear = ((t - cue.start) / 0.12f).coerceIn(0f, 1f)
        val pop = 0.86f + 0.14f * (1f - (1f - appear) * (1f - appear))
        c.save()
        c.scale(pop, pop, W / 2f, cy)
        if (look == 1) {
            var bw = 0f
            for (x in lineW) bw = max(bw, x)
            boxPaint.color = 0xB8000000.toInt()
            val padX = size * 0.45f
            val padY = size * 0.28f
            c.drawRoundRect(W / 2f - bw / 2 - padX, cy - blockH / 2 - padY, W / 2f + bw / 2 + padX,
                cy + blockH / 2 + padY, size * 0.3f, size * 0.3f, boxPaint)
        }
        val asc = textPaint.ascent()
        val desc = textPaint.descent()
        var y = cy - blockH / 2 + lineH / 2 - (asc + desc) / 2
        for (ln in lineStart.indices) {
            var x = W / 2f - lineW[ln] / 2
            for (i in lineStart[ln] until lineEnd[ln]) {
                val isAct = p.sub.wordHi && i == active
                if (isAct) {
                    c.save()
                    c.scale(1.08f, 1.08f, x + widths[i] / 2, y + (asc + desc) / 2)
                    if (look == 2) {
                        boxPaint.color = hiColor
                        c.drawRoundRect(x - size * 0.16f, y + asc - size * 0.02f, x + widths[i] + size * 0.16f,
                            y + desc + size * 0.04f, size * 0.22f, size * 0.22f, boxPaint)
                    }
                }
                c.drawText(texts[i], x, y, strokePaint)
                textPaint.color = if (isAct && look != 2) hiColor else baseColor
                c.drawText(texts[i], x, y, textPaint)
                if (isAct) c.restore()
                x += widths[i] + space
            }
            y += lineH
        }
        c.restore()
    }

    fun release() {
        cache.values.forEach { try { it.recycle() } catch (_: Exception) {} }
        cache.clear()
        vignette?.recycle()
        vignette = null
    }
}

/** Sends finished frames to the hardware H.264 encoder through OpenGL. */
class GlFrameSurface(surface: Surface, private val w: Int, private val h: Int) {
    private var display: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var context: EGLContext = EGL14.EGL_NO_CONTEXT
    private var eglSurface: EGLSurface = EGL14.EGL_NO_SURFACE
    private var program = 0
    private var tex = 0
    private var first = true
    private val verts: FloatBuffer

    init {
        display = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        if (display == EGL14.EGL_NO_DISPLAY) throw RuntimeException("No graphics display for video encoding")
        val ver = IntArray(2)
        if (!EGL14.eglInitialize(display, ver, 0, ver, 1)) throw RuntimeException("Graphics could not start for video encoding")
        val attribs = intArrayOf(
            EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8,
            EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
            0x3142, 1,   // EGL_RECORDABLE_ANDROID
            EGL14.EGL_NONE
        )
        val configs = arrayOfNulls<EGLConfig>(1)
        val num = IntArray(1)
        if (!EGL14.eglChooseConfig(display, attribs, 0, configs, 0, 1, num, 0) || num[0] < 1 || configs[0] == null)
            throw RuntimeException("No graphics configuration for video encoding")
        context = EGL14.eglCreateContext(display, configs[0], EGL14.EGL_NO_CONTEXT,
            intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0)
        if (context == EGL14.EGL_NO_CONTEXT) throw RuntimeException("Graphics context could not be created")
        eglSurface = EGL14.eglCreateWindowSurface(display, configs[0], surface, intArrayOf(EGL14.EGL_NONE), 0)
        if (eglSurface == EGL14.EGL_NO_SURFACE) throw RuntimeException("Encoder surface could not be created")
        if (!EGL14.eglMakeCurrent(display, eglSurface, eglSurface, context)) throw RuntimeException("Graphics context could not be used")

        val vs = "attribute vec4 aPos; attribute vec2 aTex; varying vec2 vTex; void main(){ gl_Position = aPos; vTex = aTex; }"
        val fs = "precision mediump float; varying vec2 vTex; uniform sampler2D uTex; void main(){ gl_FragColor = texture2D(uTex, vTex); }"
        program = GLES20.glCreateProgram()
        GLES20.glAttachShader(program, compile(GLES20.GL_VERTEX_SHADER, vs))
        GLES20.glAttachShader(program, compile(GLES20.GL_FRAGMENT_SHADER, fs))
        GLES20.glLinkProgram(program)
        val linked = IntArray(1)
        GLES20.glGetProgramiv(program, GLES20.GL_LINK_STATUS, linked, 0)
        if (linked[0] == 0) throw RuntimeException("Graphics program failed: " + GLES20.glGetProgramInfoLog(program))

        val ids = IntArray(1)
        GLES20.glGenTextures(1, ids, 0)
        tex = ids[0]
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)

        val data = floatArrayOf(
            -1f, -1f, 0f, 1f,
            1f, -1f, 1f, 1f,
            -1f, 1f, 0f, 0f,
            1f, 1f, 1f, 0f
        )
        verts = ByteBuffer.allocateDirect(data.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        verts.put(data)
        verts.position(0)
    }

    private fun compile(type: Int, src: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, src)
        GLES20.glCompileShader(s)
        val ok = IntArray(1)
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) throw RuntimeException("Graphics shader failed: " + GLES20.glGetShaderInfoLog(s))
        return s
    }

    fun drawBitmap(b: Bitmap) {
        GLES20.glViewport(0, 0, w, h)
        GLES20.glUseProgram(program)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex)
        if (first) { GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, b, 0); first = false }
        else GLUtils.texSubImage2D(GLES20.GL_TEXTURE_2D, 0, 0, 0, b)
        val aPos = GLES20.glGetAttribLocation(program, "aPos")
        val aTex = GLES20.glGetAttribLocation(program, "aTex")
        verts.position(0)
        GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 16, verts)
        GLES20.glEnableVertexAttribArray(aPos)
        verts.position(2)
        GLES20.glVertexAttribPointer(aTex, 2, GLES20.GL_FLOAT, false, 16, verts)
        GLES20.glEnableVertexAttribArray(aTex)
        GLES20.glUniform1i(GLES20.glGetUniformLocation(program, "uTex"), 0)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
    }

    fun setPresentationTime(ns: Long) { EGLExt.eglPresentationTimeANDROID(display, eglSurface, ns) }
    fun swap() { EGL14.eglSwapBuffers(display, eglSurface) }

    fun release() {
        if (display != EGL14.EGL_NO_DISPLAY) {
            EGL14.eglMakeCurrent(display, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
            if (eglSurface != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(display, eglSurface)
            if (context != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(display, context)
            EGL14.eglReleaseThread()
            EGL14.eglTerminate(display)
        }
        display = EGL14.EGL_NO_DISPLAY
        context = EGL14.EGL_NO_CONTEXT
        eglSurface = EGL14.EGL_NO_SURFACE
    }
}

object VideoWriter {
    const val FPS = 30

    /** Renders every frame, encodes H.264 + AAC and writes one MP4. Must stay on a single thread. */
    fun write(
        p: Project, tl: Timeline, audio: EncodedAudio, file: File, W: Int, H: Int, bitrate: Int,
        progress: (Float) -> Unit, cancelled: () -> Boolean
    ) {
        val fmt = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, W, H)
        fmt.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
        fmt.setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
        fmt.setInteger(MediaFormat.KEY_FRAME_RATE, FPS)
        fmt.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        var codec: MediaCodec? = null
        var gl: GlFrameSurface? = null
        var muxer: MediaMuxer? = null
        var painter: FramePainter? = null
        var frameBmp: Bitmap? = null
        var surface: Surface? = null
        var muxStarted = false
        try {
            val enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            codec = enc
            enc.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            val surf = enc.createInputSurface()
            surface = surf
            enc.start()
            val g = GlFrameSurface(surf, W, H)
            gl = g
            file.delete()
            val mux = MediaMuxer(file.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            muxer = mux
            val pt = FramePainter(p, tl, W, H)
            painter = pt
            val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
            frameBmp = bmp
            val canvas = Canvas(bmp)
            val frames = max(1, ceil(tl.total * FPS).toInt())
            val info = MediaCodec.BufferInfo()
            val ainfo = MediaCodec.BufferInfo()
            var vTrack = -1
            var aTrack = -1
            var aIdx = 0
            var lastAudioPts = -1L

            fun writeAudioUpTo(pts: Long) {
                while (aIdx < audio.frames.size && audio.pts[aIdx] <= pts) {
                    val arr = audio.frames[aIdx]
                    val t = audio.pts[aIdx]
                    if (t > lastAudioPts) {
                        ainfo.set(0, arr.size, t, MediaCodec.BUFFER_FLAG_KEY_FRAME)
                        mux.writeSampleData(aTrack, ByteBuffer.wrap(arr), ainfo)
                        lastAudioPts = t
                    }
                    aIdx++
                }
            }

            fun drain(end: Boolean) {
                if (end) enc.signalEndOfInputStream()
                var idle = 0
                while (true) {
                    val oi = enc.dequeueOutputBuffer(info, if (end) 10000L else 0L)
                    if (oi == MediaCodec.INFO_TRY_AGAIN_LATER) {
                        if (!end) break
                        idle++
                        if (idle > 500) break
                    } else if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        if (!muxStarted) {
                            vTrack = mux.addTrack(enc.outputFormat)
                            aTrack = mux.addTrack(audio.format)
                            mux.start()
                            muxStarted = true
                        }
                    } else if (oi >= 0) {
                        idle = 0
                        val ob = enc.getOutputBuffer(oi)
                        if ((info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0
                        if (ob != null && info.size > 0 && muxStarted) {
                            ob.position(info.offset)
                            ob.limit(info.offset + info.size)
                            mux.writeSampleData(vTrack, ob, info)
                            writeAudioUpTo(info.presentationTimeUs)
                        }
                        enc.releaseOutputBuffer(oi, false)
                        if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) break
                    }
                }
            }

            for (i in 0 until frames) {
                if (cancelled()) throw CancellationException("Cancelled")
                pt.draw(canvas, i.toFloat() / FPS)
                g.drawBitmap(bmp)
                g.setPresentationTime(i * 1_000_000_000L / FPS)
                g.swap()
                drain(false)
                if (i % 5 == 0) progress(i.toFloat() / frames)
            }
            drain(true)
            if (!muxStarted) throw Exception("The video encoder produced no output on this phone.")
            writeAudioUpTo(Long.MAX_VALUE)
            mux.stop()
            muxStarted = false
            progress(1f)
        } finally {
            try { painter?.release() } catch (_: Exception) {}
            try { frameBmp?.recycle() } catch (_: Exception) {}
            try { gl?.release() } catch (_: Exception) {}
            try { codec?.stop() } catch (_: Exception) {}
            try { codec?.release() } catch (_: Exception) {}
            try { surface?.release() } catch (_: Exception) {}
            try { if (muxStarted) muxer?.stop() } catch (_: Exception) {}
            try { muxer?.release() } catch (_: Exception) {}
        }
    }
}

object RenderEngine {
    fun outputFile(ctx: Context, id: String): File = File(File(ctx.cacheDir, "render").apply { mkdirs() }, "$id.mp4")
    fun keyFile(ctx: Context, id: String): File = File(File(ctx.cacheDir, "render").apply { mkdirs() }, "$id.key")

    /** True when a finished preview exists and still matches the project's current settings. */
    fun isFresh(ctx: Context, p: Project): Boolean {
        val f = outputFile(ctx, p.id)
        val k = keyFile(ctx, p.id)
        return f.exists() && f.length() > 1000 && k.exists() && k.readText() == p.renderKey()
    }

    /** Music + effects + narration mixed and encoded. Kept separate so the large buffers are freed before video rendering. */
    private fun buildAudio(p: Project, tl: Timeline, style: StyleSpec): EncodedAudio {
        val music: ShortArray? = when (p.music.kind) {
            "none" -> null
            "file" -> {
                if (p.music.file.isEmpty() || !File(p.music.file).exists())
                    throw Exception("Your imported music file is missing. Import it again or pick built-in music.")
                Pcm.decodeToStereo(p.music.file, tl.total + 1f)
            }
            "mood" -> MusicSynth.generate(p.music.mood, tl.total)
            else -> MusicSynth.generate(style.mood, tl.total)
        }
        if (music != null && music.size < SR) throw Exception("The music file has no usable audio.")
        val sfx: ShortArray? = if (!p.music.sfx) null
        else if (p.music.sfxFile.isNotEmpty() && File(p.music.sfxFile).exists()) Pcm.decodeToStereo(p.music.sfxFile, 3f)
        else MusicSynth.whoosh()
        val sfxAt = tl.shots.filter { it.tIn != T_CUT }.map { ((it.start - 0.22f) * SR).toInt() }
        val mixed = Mixer.mix(tl.narration, music, sfx, sfxAt, p.voice.volume, p.music.volume, p.music.duck)
        return Aac.encode(mixed)
    }

    suspend fun render(
        ctx: Context, p: Project, progress: (Float, String) -> Unit, cancelled: () -> Boolean
    ): String = withContext(Dispatchers.Default) {
        progress(0.01f, "Checking pictures")
        val aspects = FloatArray(p.pics.size) { i ->
            if (!File(p.pics[i].file).exists()) throw Exception("Picture ${i + 1} is missing. Remove it and import it again.")
            ImageLoader.aspect(p.pics[i].file)
        }
        val tl = TimelineBuilder.build(ctx, p, aspects, { f, msg -> progress(0.02f + f * 0.30f, msg) }, cancelled)
        val style = Styles.styles[p.style.coerceIn(0, Styles.styles.size - 1)]

        progress(0.33f, "Preparing music and mixing audio")
        if (cancelled()) throw CancellationException("Cancelled")
        val audio = buildAudio(p, tl, style)
        progress(0.41f, "Starting video encoder")

        val out = outputFile(ctx, p.id)
        val tmp = File(out.parentFile, "${p.id}.tmp.mp4")
        val platform = Styles.platforms[p.platform.coerceIn(0, Styles.platforms.size - 1)]
        var resolution = "1080 × 1920"
        try {
            VideoWriter.write(p, tl, audio, tmp, 1080, 1920, platform.bitrate,
                { f -> progress(0.42f + f * 0.57f, "Rendering video ${(f * 100).toInt()}%") }, cancelled)
        } catch (e: CancellationException) {
            tmp.delete()
            throw e
        } catch (e: Exception) {
            // Some phones cannot encode 1080 × 1920; fall back rather than fail.
            tmp.delete()
            if (cancelled()) throw CancellationException("Cancelled")
            resolution = "720 × 1280"
            try {
                VideoWriter.write(p, tl, audio, tmp, 720, 1280, platform.bitrate * 55 / 100,
                    { f -> progress(0.42f + f * 0.57f, "Rendering video (720p) ${(f * 100).toInt()}%") }, cancelled)
            } catch (e2: CancellationException) {
                tmp.delete()
                throw e2
            } catch (e2: Exception) {
                tmp.delete()
                throw Exception("Video rendering failed on this phone: " + (e.message ?: e.javaClass.simpleName))
            }
        }
        if (!tmp.exists() || tmp.length() < 1000) throw Exception("Rendering finished but the video file is empty.")
        out.delete()
        if (!tmp.renameTo(out)) { tmp.copyTo(out, true); tmp.delete() }
        keyFile(ctx, p.id).writeText(p.renderKey())
        progress(1f, "Done")
        resolution
    }
}

object Exporter {
    /** Copies the finished MP4 into the phone gallery (Movies/FacelessReels). Returns where it went. */
    fun saveToGallery(ctx: Context, src: File, title: String): String {
        val safe = title.replace(Regex("[^A-Za-z0-9 _-]"), "").trim().ifEmpty { "video" }.replace(' ', '_')
        val name = safe + "_" + java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.US).format(java.util.Date()) + ".mp4"
        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues()
            values.put(MediaStore.Video.Media.DISPLAY_NAME, name)
            values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            values.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/FacelessReels")
            values.put(MediaStore.Video.Media.IS_PENDING, 1)
            val resolver = ctx.contentResolver
            val uri: Uri = resolver.insert(MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY), values)
                ?: throw Exception("The phone refused to create the video file in the gallery.")
            try {
                resolver.openOutputStream(uri)?.use { o -> src.inputStream().use { it.copyTo(o) } }
                    ?: throw Exception("The phone refused to open the gallery file.")
                val done = ContentValues()
                done.put(MediaStore.Video.Media.IS_PENDING, 0)
                resolver.update(uri, done, null, null)
            } catch (e: Exception) {
                try { resolver.delete(uri, null, null) } catch (_: Exception) {}
                throw e
            }
            return "Movies/FacelessReels/$name"
        } else {
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "FacelessReels")
            dir.mkdirs()
            val dst = File(dir, name)
            src.copyTo(dst, true)
            MediaScannerConnection.scanFile(ctx, arrayOf(dst.absolutePath), arrayOf("video/mp4"), null)
            return "Movies/FacelessReels/$name"
        }
    }
}
