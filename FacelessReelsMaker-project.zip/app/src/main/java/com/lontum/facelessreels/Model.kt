package com.lontum.facelessreels

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

data class Pic(val id: String, val file: String, val scene: Int = -1)

data class VoiceCfg(
    val engine: String = "phone",      // phone | online
    val phoneVoice: String = "",
    val narr: Int = 0,
    val speed: Float = 1f,
    val volume: Float = 1f,
    val onlineVoice: String = ""       // per-character online voice (empty = the one chosen in settings)
)

/** A person in movie mode: their picture, voice and how they are placed in a scene. */
data class Character(
    val id: String,
    val name: String,
    val file: String,
    val phoneVoice: String = "",
    val onlineVoice: String = "",
    val onlineVoiceName: String = "",
    val narr: Int = 0,
    val flip: Boolean = false,
    val cutout: Boolean = true,
    val size: Float = 1f
) {
    fun toJson(): JSONObject = JSONObject().put("id", id).put("name", name).put("file", file)
        .put("phoneVoice", phoneVoice).put("onlineVoice", onlineVoice).put("onlineVoiceName", onlineVoiceName)
        .put("narr", narr).put("flip", flip).put("cutout", cutout).put("size", size.toDouble())

    companion object {
        fun fromJson(o: JSONObject) = Character(
            o.getString("id"), o.optString("name", "Character"), o.optString("file", ""),
            o.optString("phoneVoice", ""), o.optString("onlineVoice", ""), o.optString("onlineVoiceName", ""),
            o.optInt("narr", 0), o.optBoolean("flip", false), o.optBoolean("cutout", true),
            o.optDouble("size", 1.0).toFloat()
        )
    }
}

/** A background picture and how it is framed (zoom 1 = fill the screen, x/y = which part is shown). */
data class Backdrop(
    val id: String,
    val name: String,
    val file: String,
    val zoom: Float = 1f,
    val x: Float = 0.5f,
    val y: Float = 0.5f,
    val soft: Boolean = true
) {
    fun toJson(): JSONObject = JSONObject().put("id", id).put("name", name).put("file", file)
        .put("zoom", zoom.toDouble()).put("x", x.toDouble()).put("y", y.toDouble()).put("soft", soft)

    companion object {
        fun fromJson(o: JSONObject) = Backdrop(
            o.getString("id"), o.optString("name", "Background"), o.optString("file", ""),
            o.optDouble("zoom", 1.0).toFloat(), o.optDouble("x", 0.5).toFloat(), o.optDouble("y", 0.5).toFloat(),
            o.optBoolean("soft", true)
        )
    }
}

data class MusicCfg(
    val kind: String = "auto",         // none | auto | mood | file
    val mood: Int = 0,
    val file: String = "",
    val fileName: String = "",
    val volume: Float = 0.35f,
    val duck: Boolean = true,
    val sfx: Boolean = true,
    val sfxFile: String = "",
    val sfxName: String = ""
)

data class SubCfg(
    val on: Boolean = true,
    val look: Int = -1,                // -1 = follow editing style
    val font: Int = -1,
    val color: Int = -1,
    val hi: Int = -1,
    val pos: Int = -1,                 // -1 auto (platform safe), 0 top, 1 middle, 2 bottom
    val size: Float = 1f,
    val wordHi: Boolean = true
)

data class Project(
    val id: String,
    val name: String,
    val script: String = "",
    val pics: List<Pic> = emptyList(),
    val subEdits: Map<String, String> = emptyMap(),
    val voice: VoiceCfg = VoiceCfg(),
    val style: Int = 0,
    val music: MusicCfg = MusicCfg(),
    val sub: SubCfg = SubCfg(),
    val platform: Int = 0,
    val updated: Long = 0L,
    val mode: String = "narration",               // narration | movie
    val chars: List<Character> = emptyList(),
    val bgs: List<Backdrop> = emptyList(),
    val sceneBgs: Map<String, String> = emptyMap(), // scene number -> background id ("none" = no background)
    val aiOn: Boolean = true
) {
    /** Everything that changes the rendered video. Used to tell if a preview is out of date. */
    fun renderKey(): String = toJson().apply { remove("name"); remove("updated") }.toString() +
        "|" + Settings.onlineSignature() + "|" + Settings.falModel

    fun toJson(): JSONObject {
        val o = JSONObject()
        o.put("id", id); o.put("name", name); o.put("script", script)
        o.put("style", style); o.put("platform", platform); o.put("updated", updated)
        val pa = JSONArray()
        pics.forEach { pa.put(JSONObject().put("id", it.id).put("file", it.file).put("scene", it.scene)) }
        o.put("pics", pa)
        val se = JSONObject()
        subEdits.forEach { (k, v) -> se.put(k, v) }
        o.put("subEdits", se)
        o.put("voice", JSONObject().put("engine", voice.engine).put("phoneVoice", voice.phoneVoice)
            .put("narr", voice.narr).put("speed", voice.speed.toDouble()).put("volume", voice.volume.toDouble())
            .put("onlineVoice", voice.onlineVoice))
        o.put("mode", mode)
        o.put("aiOn", aiOn)
        val ca = JSONArray()
        chars.forEach { ca.put(it.toJson()) }
        o.put("chars", ca)
        val ba = JSONArray()
        bgs.forEach { ba.put(it.toJson()) }
        o.put("bgs", ba)
        val sb = JSONObject()
        sceneBgs.forEach { (k, v) -> sb.put(k, v) }
        o.put("sceneBgs", sb)
        o.put("music", JSONObject().put("kind", music.kind).put("mood", music.mood).put("file", music.file)
            .put("fileName", music.fileName).put("volume", music.volume.toDouble()).put("duck", music.duck)
            .put("sfx", music.sfx).put("sfxFile", music.sfxFile).put("sfxName", music.sfxName))
        o.put("sub", JSONObject().put("on", sub.on).put("look", sub.look).put("font", sub.font)
            .put("color", sub.color).put("hi", sub.hi).put("pos", sub.pos)
            .put("size", sub.size.toDouble()).put("wordHi", sub.wordHi))
        return o
    }

    companion object {
        fun fromJson(o: JSONObject): Project {
            val pics = ArrayList<Pic>()
            val pa = o.optJSONArray("pics") ?: JSONArray()
            for (i in 0 until pa.length()) {
                val p = pa.getJSONObject(i)
                pics.add(Pic(p.getString("id"), p.getString("file"), p.optInt("scene", -1)))
            }
            val edits = HashMap<String, String>()
            val se = o.optJSONObject("subEdits")
            if (se != null) {
                val it = se.keys()
                while (it.hasNext()) { val k = it.next(); edits[k] = se.optString(k) }
            }
            val v = o.optJSONObject("voice") ?: JSONObject()
            val chars = ArrayList<Character>()
            val ca = o.optJSONArray("chars") ?: JSONArray()
            for (i in 0 until ca.length()) chars.add(Character.fromJson(ca.getJSONObject(i)))
            val bgs = ArrayList<Backdrop>()
            val ba = o.optJSONArray("bgs") ?: JSONArray()
            for (i in 0 until ba.length()) bgs.add(Backdrop.fromJson(ba.getJSONObject(i)))
            val sceneBgs = HashMap<String, String>()
            val sb = o.optJSONObject("sceneBgs")
            if (sb != null) {
                val ki = sb.keys()
                while (ki.hasNext()) { val k = ki.next(); sceneBgs[k] = sb.optString(k) }
            }
            val m = o.optJSONObject("music") ?: JSONObject()
            val s = o.optJSONObject("sub") ?: JSONObject()
            return Project(
                id = o.getString("id"),
                name = o.optString("name", "Untitled"),
                script = o.optString("script", ""),
                pics = pics,
                subEdits = edits,
                voice = VoiceCfg(
                    v.optString("engine", "phone"), v.optString("phoneVoice", ""),
                    v.optInt("narr", 0), v.optDouble("speed", 1.0).toFloat(), v.optDouble("volume", 1.0).toFloat(),
                    v.optString("onlineVoice", "")
                ),
                style = o.optInt("style", 0),
                music = MusicCfg(
                    m.optString("kind", "auto"), m.optInt("mood", 0), m.optString("file", ""),
                    m.optString("fileName", ""), m.optDouble("volume", 0.35).toFloat(), m.optBoolean("duck", true),
                    m.optBoolean("sfx", true), m.optString("sfxFile", ""), m.optString("sfxName", "")
                ),
                sub = SubCfg(
                    s.optBoolean("on", true), s.optInt("look", -1), s.optInt("font", -1), s.optInt("color", -1),
                    s.optInt("hi", -1), s.optInt("pos", -1), s.optDouble("size", 1.0).toFloat(), s.optBoolean("wordHi", true)
                ),
                platform = o.optInt("platform", 0),
                updated = o.optLong("updated", 0L),
                mode = o.optString("mode", "narration"),
                chars = chars,
                bgs = bgs,
                sceneBgs = sceneBgs,
                aiOn = o.optBoolean("aiOn", true)
            )
        }
    }
}

/** Saved projects live in the app's private storage, one folder each. */
object Store {
    fun root(ctx: Context): File = File(ctx.filesDir, "projects").apply { mkdirs() }
    fun dir(ctx: Context, id: String): File = File(root(ctx), id).apply { mkdirs() }

    fun create(ctx: Context): Project {
        val n = list(ctx).size + 1
        val p = Project(id = UUID.randomUUID().toString().take(8), name = "Video $n", updated = System.currentTimeMillis())
        save(ctx, p)
        return p
    }

    fun save(ctx: Context, p: Project) {
        try {
            val f = File(dir(ctx, p.id), "project.json")
            val tmp = File(f.parentFile, "project.json.tmp")
            tmp.writeText(p.toJson().toString())
            tmp.renameTo(f)
        } catch (_: Exception) {
        }
    }

    fun list(ctx: Context): List<Project> {
        val out = ArrayList<Project>()
        root(ctx).listFiles()?.forEach { d ->
            val f = File(d, "project.json")
            if (f.exists()) {
                try { out.add(Project.fromJson(JSONObject(f.readText()))) } catch (_: Exception) {}
            }
        }
        return out.sortedByDescending { it.updated }
    }

    fun delete(ctx: Context, id: String) {
        File(root(ctx), id).deleteRecursively()
        File(ctx.cacheDir, "render/$id.mp4").delete()
        File(ctx.cacheDir, "render/$id.key").delete()
    }
}

/** App-wide settings (online voice service). The key is stored only on this phone. */
object Settings {
    private var prefs: android.content.SharedPreferences? = null
    fun init(ctx: Context) { if (prefs == null) prefs = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE) }
    private fun get(k: String, d: String) = prefs?.getString(k, d) ?: d
    private fun set(k: String, v: String) { prefs?.edit()?.putString(k, v)?.apply() }

    var provider: String
        get() = get("provider", "elevenlabs")
        set(v) = set("provider", v)
    var elevenKey: String
        get() = get("elevenKey", "")
        set(v) = set("elevenKey", v.trim())
    var elevenVoiceId: String
        get() = get("elevenVoiceId", "")
        set(v) = set("elevenVoiceId", v.trim())
    var elevenVoiceName: String
        get() = get("elevenVoiceName", "")
        set(v) = set("elevenVoiceName", v)
    var elevenModel: String
        get() = get("elevenModel", "eleven_multilingual_v2")
        set(v) = set("elevenModel", v.trim())
    var customUrl: String
        get() = get("customUrl", "https://api.openai.com/v1/audio/speech")
        set(v) = set("customUrl", v.trim())
    var customKey: String
        get() = get("customKey", "")
        set(v) = set("customKey", v.trim())
    var customModel: String
        get() = get("customModel", "gpt-4o-mini-tts")
        set(v) = set("customModel", v.trim())
    var customVoice: String
        get() = get("customVoice", "onyx")
        set(v) = set("customVoice", v.trim())

    /** fal.ai: makes the character pictures talk (paid, the user's own key). */
    var falKey: String
        get() = get("falKey", "")
        set(v) = set("falKey", v.trim())
    var falModel: String
        get() = get("falModel", FAL_STANDARD)
        set(v) = set("falModel", v.trim())

    const val FAL_STANDARD = "fal-ai/kling-video/ai-avatar/v2/standard"
    const val FAL_PRO = "fal-ai/kling-video/ai-avatar/v2/pro"
    fun falPricePerSecond(): Float = if (falModel == FAL_PRO) 0.115f else 0.0562f

    fun onlineReady(): Boolean =
        if (provider == "elevenlabs") elevenKey.isNotEmpty() && elevenVoiceId.isNotEmpty()
        else customKey.isNotEmpty() && customUrl.isNotEmpty()

    fun onlineSignature(): String =
        if (provider == "elevenlabs") "el:$elevenVoiceId:$elevenModel" else "cu:$customUrl:$customModel:$customVoice"
}

object ScriptTools {
    private val ABBR = setOf("mr.", "mrs.", "ms.", "dr.", "st.", "vs.", "etc.", "no.", "e.g.", "i.e.", "prof.", "sr.", "jr.")

    fun scenes(script: String): List<String> {
        val t = script.replace("\r\n", "\n").trim()
        if (t.isEmpty()) return emptyList()
        var parts = t.split(Regex("\\n\\s*\\n")).map { it.trim() }.filter { it.isNotEmpty() }
        if (parts.size == 1) parts = t.split("\n").map { it.trim() }.filter { it.isNotEmpty() }
        if (parts.size == 1) {
            val s = sentences(parts[0])
            if (s.size > 2) parts = s.chunked(2).map { it.joinToString(" ") }
        }
        return parts.map { it.replace(Regex("\\s+"), " ") }
    }

    fun joinScenes(scenes: List<String>): String = scenes.joinToString("\n\n")

    fun sentences(text: String): List<String> {
        val raw = text.trim().split(Regex("(?<=[.!?…])\\s+")).map { it.trim() }.filter { it.isNotEmpty() }
        val merged = ArrayList<String>()
        for (piece in raw) {
            val last = merged.lastOrNull()
            val lastWord = last?.substringAfterLast(' ')?.lowercase() ?: ""
            if (last != null && (lastWord in ABBR || lastWord.length <= 2 || last.length < 12)) {
                merged[merged.size - 1] = "$last $piece"
            } else merged.add(piece)
        }
        // Break very long sentences so every narration piece stays short.
        val out = ArrayList<String>()
        for (s in merged) {
            if (s.length <= 260) { out.add(s); continue }
            var cur = StringBuilder()
            for (w in s.split(' ')) {
                if (cur.length + w.length + 1 > 220 && cur.isNotEmpty()) { out.add(cur.toString()); cur = StringBuilder() }
                if (cur.isNotEmpty()) cur.append(' ')
                cur.append(w)
            }
            if (cur.isNotEmpty()) out.add(cur.toString())
        }
        return out
    }

    fun wordCount(script: String): Int = script.trim().split(Regex("\\s+")).count { it.isNotEmpty() }

    /** Rough narration length in seconds, before the real voice is generated. */
    fun estimateSeconds(script: String, speed: Float): Float {
        val words = wordCount(script)
        if (words == 0) return 0f
        return words / (150f * speed) * 60f + scenes(script).size * 0.5f + 2f
    }

    private val STOP = setOf(
        "the", "and", "that", "this", "with", "from", "have", "were", "was", "they", "their", "there", "what", "when",
        "where", "which", "while", "would", "could", "should", "about", "after", "before", "into", "than", "then",
        "them", "these", "those", "been", "being", "will", "your", "you", "for", "are", "but", "not", "his", "her",
        "had", "has", "him", "she", "who", "how", "why", "all", "any", "can", "one", "out", "our", "its", "it's",
        "just", "like", "over", "some", "such", "only", "also", "more", "most", "very", "every", "even", "because",
        "through", "during", "until", "again", "other", "many", "much", "each", "does", "did", "said", "came", "went"
    )

    class Suggestion(val titles: List<String>, val description: String, val hashtags: String)

    /** Offline suggestions built from the script itself (keyword based, no AI service). */
    fun suggest(script: String, platform: Int): Suggestion {
        val sents = sentences(script.replace("\n", " "))
        val first = sents.firstOrNull() ?: ""
        val freq = HashMap<String, Int>()
        script.lowercase().split(Regex("[^a-z']+")).forEach { w ->
            if (w.length >= 4 && w !in STOP) freq[w] = (freq[w] ?: 0) + 1
        }
        val keys = freq.entries.sortedWith(compareByDescending<Map.Entry<String, Int>> { it.value }.thenByDescending { it.key.length })
            .map { it.key.replace("'", "") }.filter { it.isNotEmpty() }.take(6)
        fun cap(s: String) = s.replaceFirstChar { it.uppercase() }
        fun clip(s: String, n: Int) = if (s.length <= n) s else s.take(n - 1).substringBeforeLast(' ') + "…"
        val titles = ArrayList<String>()
        if (first.isNotEmpty()) titles.add(clip(first.trimEnd('.', ' '), 80))
        if (keys.isNotEmpty()) titles.add("The Untold Story of " + cap(keys[0]))
        if (keys.size >= 2) titles.add(cap(keys[0]) + " and " + cap(keys[1]) + ": What Nobody Tells You")
        if (titles.isEmpty()) titles.add("Watch this to the end")
        val desc = clip(sents.take(2).joinToString(" "), 220) + "\n\nFollow for more stories like this."
        val tags = Styles.platforms[platform.coerceIn(0, Styles.platforms.size - 1)].tags +
            keys.map { "#$it" }
        return Suggestion(titles, desc, tags.distinct().joinToString(" "))
    }
}
