package com.lontum.facelessreels

import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import java.io.File
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

const val SR = 44100

class ShortBuf(initial: Int = 1 shl 16) {
    var data = ShortArray(initial)
    var size = 0
    fun ensure(extra: Int) {
        if (size + extra > data.size) data = data.copyOf(max(data.size * 2, size + extra))
    }
    fun toArray(): ShortArray = data.copyOf(size)
}

object Pcm {
    /** Reads a 16-bit PCM WAV file and returns mono samples plus the sample rate. */
    fun readWavMono(f: File): Pair<ShortArray, Int> {
        val b = f.readBytes()
        if (b.size < 44 || b[0] != 'R'.code.toByte() || b[1] != 'I'.code.toByte()) throw Exception("Voice file is not a WAV file")
        fun i16(o: Int) = (b[o].toInt() and 0xFF) or (b[o + 1].toInt() shl 8)
        fun i32(o: Int) = (b[o].toInt() and 0xFF) or ((b[o + 1].toInt() and 0xFF) shl 8) or
            ((b[o + 2].toInt() and 0xFF) shl 16) or ((b[o + 3].toInt() and 0xFF) shl 24)
        var pos = 12
        var channels = 1
        var rate = 24000
        var bits = 16
        var dataStart = -1
        var dataLen = 0
        while (pos + 8 <= b.size) {
            val id = String(b, pos, 4, Charsets.US_ASCII)
            var len = i32(pos + 4)
            val body = pos + 8
            if (id == "fmt ") {
                channels = i16(body + 2) and 0xFFFF
                rate = i32(body + 4)
                bits = i16(body + 14) and 0xFFFF
            } else if (id == "data") {
                dataStart = body
                if (len < 0 || body + len > b.size) len = b.size - body
                dataLen = len
                break
            }
            if (len < 0) break
            pos = body + len + (len and 1)
        }
        if (dataStart < 0) throw Exception("Voice file has no audio data")
        if (bits != 16) throw Exception("Unsupported voice audio format ($bits-bit)")
        if (channels < 1) channels = 1
        val frames = dataLen / (2 * channels)
        val out = ShortArray(frames)
        var o = dataStart
        for (i in 0 until frames) {
            var sum = 0
            for (c in 0 until channels) { sum += i16(o).toShort().toInt(); o += 2 }
            out[i] = (sum / channels).toShort()
        }
        return Pair(out, rate)
    }

    fun resampleMono(inp: ShortArray, from: Int, to: Int): ShortArray {
        if (from == to || inp.isEmpty()) return inp
        val n = (inp.size.toLong() * to / from).toInt()
        val out = ShortArray(n)
        val step = from.toDouble() / to
        for (i in 0 until n) {
            val p = i * step
            val i0 = p.toInt()
            val i1 = min(i0 + 1, inp.size - 1)
            val fr = p - i0
            out[i] = (inp[min(i0, inp.size - 1)] * (1 - fr) + inp[i1] * fr).toInt().toShort()
        }
        return out
    }

    /** Removes silence at both ends, leaving a short natural pad. */
    fun trim(s: ShortArray, sr: Int): ShortArray {
        val th = 260
        var a = 0
        while (a < s.size && abs(s[a].toInt()) < th) a++
        var b = s.size - 1
        while (b > a && abs(s[b].toInt()) < th) b--
        if (a >= b) return s
        val pad = sr / 25
        a = max(0, a - pad)
        b = min(s.size - 1, b + pad * 2)
        return s.copyOfRange(a, b + 1)
    }

    fun stereoToMono(st: ShortArray): ShortArray {
        val out = ShortArray(st.size / 2)
        for (i in out.indices) out[i] = ((st[i * 2] + st[i * 2 + 1]) / 2).toShort()
        return out
    }

    /** Decodes any audio file Android can play (mp3, m4a, wav, ogg...) to 44.1 kHz stereo. */
    fun decodeToStereo(path: String, maxSeconds: Float): ShortArray {
        val ex = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            ex.setDataSource(path)
            var track = -1
            var fmt: MediaFormat? = null
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                if ((f.getString(MediaFormat.KEY_MIME) ?: "").startsWith("audio/")) { track = i; fmt = f; break }
            }
            if (track < 0 || fmt == null) throw Exception("No audio found in the selected file")
            ex.selectTrack(track)
            val mime = fmt.getString(MediaFormat.KEY_MIME)!!
            codec = MediaCodec.createDecoderByType(mime)
            codec.configure(fmt, null, null, 0)
            codec.start()
            var rate = if (fmt.containsKey(MediaFormat.KEY_SAMPLE_RATE)) fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE) else SR
            var ch = if (fmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 2
            val buf = ShortBuf(1 shl 18)
            val info = MediaCodec.BufferInfo()
            var inDone = false
            var outDone = false
            var guard = 0
            while (!outDone) {
                if (!inDone) {
                    val ii = codec.dequeueInputBuffer(10000)
                    if (ii >= 0) {
                        val ib = codec.getInputBuffer(ii)!!
                        val n = ex.readSampleData(ib, 0)
                        if (n < 0) {
                            codec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inDone = true
                        } else {
                            codec.queueInputBuffer(ii, 0, n, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val oi = codec.dequeueOutputBuffer(info, 10000)
                if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val of = codec.outputFormat
                    if (of.containsKey(MediaFormat.KEY_SAMPLE_RATE)) rate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    if (of.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) ch = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                } else if (oi >= 0) {
                    guard = 0
                    if (info.size > 0) {
                        val ob = codec.getOutputBuffer(oi)!!
                        ob.position(info.offset)
                        ob.limit(info.offset + info.size)
                        val sb = ob.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
                        val n = sb.remaining()
                        buf.ensure(n)
                        sb.get(buf.data, buf.size, n)
                        buf.size += n
                    }
                    codec.releaseOutputBuffer(oi, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
                    if (buf.size.toFloat() / (rate * max(1, ch)) > maxSeconds) outDone = true
                } else {
                    guard++
                    if (inDone && guard > 300) outDone = true
                }
            }
            val raw = buf.data
            val frames = buf.size / max(1, ch)
            val outFrames = (frames.toLong() * SR / rate).toInt()
            val out = ShortArray(outFrames * 2)
            val step = rate.toDouble() / SR
            for (i in 0 until outFrames) {
                val p = i * step
                val i0 = min(p.toInt(), frames - 1)
                val i1 = min(i0 + 1, frames - 1)
                val fr = p - p.toInt()
                val l0 = raw[i0 * ch]; val l1 = raw[i1 * ch]
                val r0 = if (ch > 1) raw[i0 * ch + 1] else l0
                val r1 = if (ch > 1) raw[i1 * ch + 1] else l1
                out[i * 2] = (l0 * (1 - fr) + l1 * fr).toInt().toShort()
                out[i * 2 + 1] = (r0 * (1 - fr) + r1 * fr).toInt().toShort()
            }
            return out
        } finally {
            try { codec?.stop() } catch (_: Exception) {}
            try { codec?.release() } catch (_: Exception) {}
            try { ex.release() } catch (_: Exception) {}
        }
    }
}

/**
 * Built-in background music. Every track is generated inside the app from chords,
 * so there is nothing to license and nothing to download.
 */
object MusicSynth {
    private class Mood(
        val chords: Array<IntArray>, val bar: Float, val pad: Float, val arp: Float, val arpDiv: Int,
        val pulse: Float, val bass: Float, val bright: Float, val bell: Float
    )

    private val moods = arrayOf(
        // Cinematic: Am F C G
        Mood(arrayOf(intArrayOf(57, 60, 64), intArrayOf(53, 57, 60), intArrayOf(48, 55, 64), intArrayOf(55, 59, 62)), 4.0f, 1.0f, 0.25f, 4, 0.0f, 0.8f, 0.35f, 0.0f),
        // Documentary: C G Am F
        Mood(arrayOf(intArrayOf(48, 55, 64), intArrayOf(55, 59, 62), intArrayOf(57, 60, 64), intArrayOf(53, 57, 60)), 3.2f, 0.7f, 0.5f, 8, 0.0f, 0.6f, 0.25f, 0.0f),
        // Dramatic: Dm Bb Gm A
        Mood(arrayOf(intArrayOf(50, 53, 57), intArrayOf(46, 53, 58), intArrayOf(43, 50, 58), intArrayOf(45, 52, 61)), 3.6f, 1.0f, 0.2f, 4, 0.55f, 1.0f, 0.6f, 0.0f),
        // Motivational: C G Am F, faster
        Mood(arrayOf(intArrayOf(48, 55, 64), intArrayOf(55, 59, 62), intArrayOf(57, 60, 64), intArrayOf(53, 57, 60)), 2.0f, 0.7f, 0.7f, 8, 0.6f, 0.8f, 0.5f, 0.0f),
        // Educational: F C Dm Bb
        Mood(arrayOf(intArrayOf(53, 57, 60), intArrayOf(48, 55, 64), intArrayOf(50, 53, 57), intArrayOf(46, 53, 58)), 2.8f, 0.5f, 0.65f, 8, 0.0f, 0.5f, 0.2f, 0.0f),
        // Historical: Dm C Bb A
        Mood(arrayOf(intArrayOf(50, 53, 57), intArrayOf(48, 52, 55), intArrayOf(46, 50, 53), intArrayOf(45, 49, 52)), 4.4f, 1.0f, 0.3f, 4, 0.0f, 0.7f, 0.3f, 0.0f),
        // Mystery: Em C Am B
        Mood(arrayOf(intArrayOf(52, 55, 59), intArrayOf(48, 52, 55), intArrayOf(45, 52, 60), intArrayOf(47, 51, 54)), 4.8f, 0.8f, 0.0f, 4, 0.0f, 1.0f, 0.15f, 0.6f),
        // Inspirational: D A Bm G
        Mood(arrayOf(intArrayOf(50, 57, 66), intArrayOf(57, 61, 64), intArrayOf(59, 62, 66), intArrayOf(55, 59, 62)), 3.4f, 1.0f, 0.45f, 8, 0.0f, 0.7f, 0.4f, 0.2f)
    )

    private fun freq(m: Int): Double = 440.0 * 2.0.pow((m - 69) / 12.0)

    /** One seamless loop of the progression as 44.1 kHz stereo floats. */
    private fun loop(moodIdx: Int): FloatArray {
        val m = moods[moodIdx.coerceIn(0, moods.size - 1)]
        val barN = (m.bar * SR).toInt()
        val total = barN * m.chords.size
        val out = FloatArray(total * 2)
        val twoPi = 2 * PI
        for ((ci, chord) in m.chords.withIndex()) {
            val start = ci * barN
            val len = barN + (0.9f * SR).toInt()          // tail overlaps the next chord
            val att = 0.9f * SR
            val rel = 0.9f * SR
            // Pad: two detuned voices per note, spread left and right.
            for (note in chord) {
                for (side in 0..1) {
                    val f = freq(note) * (if (side == 0) 0.997 else 1.003)
                    val inc = twoPi * f / SR
                    var ph = note * 0.37 + side
                    val gl = if (side == 0) 0.75f else 0.35f
                    val gr = if (side == 0) 0.35f else 0.75f
                    for (i in 0 until len) {
                        val env = min(1f, i / att) * min(1f, (len - i) / rel)
                        val trem = 0.85 + 0.15 * sin(twoPi * 0.23 * i / SR + note)
                        val v = (sin(ph) + m.bright * 0.35 * sin(2 * ph) + m.bright * 0.18 * sin(3 * ph)) * env * trem * m.pad * 0.16
                        val idx = ((start + i) % total) * 2
                        out[idx] += (v * gl).toFloat()
                        out[idx + 1] += (v * gr).toFloat()
                        ph += inc
                    }
                }
            }
            // Bass on the chord root.
            if (m.bass > 0f) {
                val f = freq(chord[0] - 12)
                val inc = twoPi * f / SR
                var ph = 0.0
                for (i in 0 until len) {
                    val env = min(1f, i / (0.3f * SR)) * min(1f, (len - i) / rel)
                    val v = (sin(ph) * env * m.bass * 0.22).toFloat()
                    val idx = ((start + i) % total) * 2
                    out[idx] += v
                    out[idx + 1] += v
                    ph += inc
                }
            }
            // Plucked arpeggio.
            if (m.arp > 0f) {
                val stepN = barN / m.arpDiv
                val pattern = intArrayOf(0, 1, 2, 1, 0, 2, 1, 2)
                for (s in 0 until m.arpDiv) {
                    val note = chord[pattern[s % pattern.size] % chord.size] + 12
                    val inc = twoPi * freq(note) / SR
                    var ph = 0.0
                    val nLen = min((1.2f * SR).toInt(), stepN * 3)
                    val pan = if (s % 2 == 0) 0.3f else 0.7f
                    for (i in 0 until nLen) {
                        val tt = i.toDouble() / SR
                        val v = (sin(ph) * exp(-4.0 * tt) + 0.3 * sin(2 * ph) * exp(-7.0 * tt)) * m.arp * 0.2 *
                            min(1.0, i / 120.0)
                        val idx = ((start + s * stepN + i) % total) * 2
                        out[idx] += (v * (1 - pan)).toFloat()
                        out[idx + 1] += (v * pan).toFloat()
                        ph += inc
                    }
                }
            }
            // Soft low pulse on each beat.
            if (m.pulse > 0f) {
                val beatN = barN / 4
                for (bt in 0 until 4) {
                    val nLen = min((0.35f * SR).toInt(), beatN)
                    var ph = 0.0
                    for (i in 0 until nLen) {
                        val tt = i.toDouble() / SR
                        val f = 42.0 + 50.0 * exp(-30.0 * tt)
                        ph += twoPi * f / SR
                        val v = (sin(ph) * exp(-11.0 * tt) * m.pulse * 0.5).toFloat()
                        val idx = ((start + bt * beatN + i) % total) * 2
                        out[idx] += v
                        out[idx + 1] += v
                    }
                }
            }
            // Sparse high bell.
            if (m.bell > 0f) {
                val note = chord[(ci * 2 + 1) % chord.size] + 24
                val inc = twoPi * freq(note) / SR
                var ph = 0.0
                val off = barN / 3
                val nLen = (2.5f * SR).toInt()
                for (i in 0 until nLen) {
                    val tt = i.toDouble() / SR
                    val v = ((sin(ph) + 0.4 * sin(2.76 * ph)) * exp(-1.8 * tt) * m.bell * 0.12 * min(1.0, i / 200.0)).toFloat()
                    val idx = ((start + off + i) % total) * 2
                    out[idx] += v * (if (ci % 2 == 0) 0.8f else 0.3f)
                    out[idx + 1] += v * (if (ci % 2 == 0) 0.3f else 0.8f)
                    ph += inc
                }
            }
        }
        var peak = 0.0001f
        for (v in out) peak = max(peak, abs(v))
        val g = 0.85f / peak
        for (i in out.indices) out[i] *= g
        return out
    }

    /** Stereo 16-bit music of the requested length. */
    fun generate(moodIdx: Int, seconds: Float): ShortArray {
        val lp = loop(moodIdx)
        val n = (seconds * SR).toInt() * 2
        val out = ShortArray(n)
        for (i in 0 until n) out[i] = (lp[i % lp.size] * 32000f).toInt().toShort()
        return out
    }

    /** Short transition "whoosh", stereo. */
    fun whoosh(): ShortArray {
        val n = (0.55f * SR).toInt()
        val out = ShortArray(n * 2)
        val rnd = java.util.Random(7)
        var lp = 0f
        for (i in 0 until n) {
            val x = i.toFloat() / n
            val env = sin(PI * x).toFloat().let { it * it }
            val cut = 0.02f + 0.25f * env
            lp += cut * ((rnd.nextFloat() * 2f - 1f) - lp)
            val v = lp * env * 9000f
            out[i * 2] = (v * (1f - x * 0.7f)).toInt().toShort()
            out[i * 2 + 1] = (v * (0.3f + x * 0.7f)).toInt().toShort()
        }
        return out
    }
}

object Mixer {
    /**
     * Mixes mono narration with stereo music and effects into one stereo track.
     * Music is lowered automatically while the voice is speaking (ducking).
     */
    fun mix(
        narr: ShortArray, music: ShortArray?, sfx: ShortArray?, sfxAt: List<Int>,
        narrVol: Float, musicVol: Float, duck: Boolean
    ): ShortArray {
        val n = narr.size
        val out = ShortArray(n * 2)
        val block = 1024
        val blocks = n / block + 1
        val speech = BooleanArray(blocks)
        for (bi in 0 until blocks) {
            var mx = 0
            val a = bi * block
            val e = min(n, a + block)
            for (i in a until e) { val v = abs(narr[i].toInt()); if (v > mx) mx = v }
            speech[bi] = mx > 500
        }
        var g = 1f
        val attack = 1f / (0.12f * SR)
        val release = 1f / (0.7f * SR)
        val fadeIn = (0.8f * SR).toInt()
        val fadeOut = (1.6f * SR).toInt()
        val sfxAcc = if (sfx != null && sfxAt.isNotEmpty()) FloatArray(n * 2) else null
        if (sfxAcc != null && sfx != null) {
            for (at in sfxAt) {
                val base = at * 2
                var i = 0
                while (i < sfx.size && base + i < sfxAcc.size) {
                    if (base + i >= 0) sfxAcc[base + i] += sfx[i] * 0.5f
                    i++
                }
            }
        }
        for (i in 0 until n) {
            val bi = i / block
            val talking = duck && (speech[bi] || (bi + 1 < blocks && speech[bi + 1]) || (bi + 4 < blocks && speech[bi + 4]))
            val target = if (talking) 0.3f else 1f
            g += (target - g) * (if (target < g) attack * 6f else release * 3f)
            var l = narr[i] * narrVol
            var r = l
            if (music != null && music.isNotEmpty()) {
                var fade = 1f
                if (i < fadeIn) fade = i.toFloat() / fadeIn
                if (n - i < fadeOut) fade = min(fade, (n - i).toFloat() / fadeOut)
                val mi = (i * 2) % (music.size - 1)
                val mg = musicVol * g * fade
                l += music[mi and 1.inv()] * mg
                r += music[(mi and 1.inv()) + 1] * mg
            }
            if (sfxAcc != null) { l += sfxAcc[i * 2]; r += sfxAcc[i * 2 + 1] }
            out[i * 2] = l.coerceIn(-32767f, 32767f).toInt().toShort()
            out[i * 2 + 1] = r.coerceIn(-32767f, 32767f).toInt().toShort()
        }
        return out
    }
}

class EncodedAudio(val format: MediaFormat, val frames: List<ByteArray>, val pts: List<Long>)

object Aac {
    /** Encodes stereo 44.1 kHz PCM to AAC-LC and keeps the frames in memory for muxing. */
    fun encode(pcm: ShortArray): EncodedAudio {
        val fmt = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, SR, 2)
        fmt.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
        fmt.setInteger(MediaFormat.KEY_BIT_RATE, 160000)
        fmt.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
        val codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
        val frames = ArrayList<ByteArray>()
        val pts = ArrayList<Long>()
        var outFmt: MediaFormat? = null
        try {
            codec.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            codec.start()
            val info = MediaCodec.BufferInfo()
            var pos = 0
            var inDone = false
            var outDone = false
            var idle = 0
            while (!outDone) {
                if (!inDone) {
                    val ii = codec.dequeueInputBuffer(10000)
                    if (ii >= 0) {
                        val ib = codec.getInputBuffer(ii)!!
                        ib.clear()
                        val remaining = pcm.size - pos
                        if (remaining <= 0) {
                            codec.queueInputBuffer(ii, 0, 0, pos / 2 * 1_000_000L / SR, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inDone = true
                        } else {
                            var shorts = min(remaining, ib.capacity() / 2)
                            shorts -= shorts % 2
                            if (shorts <= 0) shorts = min(remaining, 2)
                            ib.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().put(pcm, pos, shorts)
                            codec.queueInputBuffer(ii, 0, shorts * 2, pos / 2 * 1_000_000L / SR, 0)
                            pos += shorts
                        }
                    }
                }
                val oi = codec.dequeueOutputBuffer(info, 10000)
                if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    outFmt = codec.outputFormat
                } else if (oi >= 0) {
                    idle = 0
                    if (info.size > 0 && (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                        val ob = codec.getOutputBuffer(oi)!!
                        ob.position(info.offset)
                        ob.limit(info.offset + info.size)
                        val arr = ByteArray(info.size)
                        ob.get(arr)
                        frames.add(arr)
                        pts.add(info.presentationTimeUs)
                    }
                    codec.releaseOutputBuffer(oi, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
                } else {
                    idle++
                    if (inDone && idle > 500) outDone = true
                }
            }
        } finally {
            try { codec.stop() } catch (_: Exception) {}
            try { codec.release() } catch (_: Exception) {}
        }
        val f = outFmt ?: throw Exception("Audio encoder did not start on this phone")
        return EncodedAudio(f, frames, pts)
    }
}
