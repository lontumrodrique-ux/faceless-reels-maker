package com.lontum.facelessreels

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.MessageDigest
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

class VoiceInfo(val name: String, val label: String, val detail: String)

/** The phone's own text-to-speech engine. Works offline once the voice data is installed. */
object PhoneTts {
    private var tts: TextToSpeech? = null
    private val waiters = ConcurrentHashMap<String, CompletableDeferred<Boolean>>()
    private val AFRICA = listOf("NG", "KE", "ZA", "GH", "TZ", "UG", "CM", "ZW", "RW")

    suspend fun ensure(ctx: Context): TextToSpeech {
        tts?.let { return it }
        val ready = CompletableDeferred<Int>()
        val t = withContext(Dispatchers.Main) {
            TextToSpeech(ctx.applicationContext) { status -> ready.complete(status) }
        }
        val status = kotlinx.coroutines.withTimeoutOrNull(15000) { ready.await() } ?: TextToSpeech.ERROR
        if (status != TextToSpeech.SUCCESS) {
            try { t.shutdown() } catch (_: Exception) {}
            throw Exception("No text-to-speech engine is working on this phone. Install or update \"Speech Recognition & Synthesis\" by Google from the Play Store, then try again.")
        }
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {
                if (utteranceId != null) waiters.remove(utteranceId)?.complete(true)
            }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                if (utteranceId != null) waiters.remove(utteranceId)?.complete(false)
            }
            override fun onError(utteranceId: String?, errorCode: Int) {
                if (utteranceId != null) waiters.remove(utteranceId)?.complete(false)
            }
        })
        tts = t
        return t
    }

    suspend fun voices(ctx: Context): List<VoiceInfo> {
        val t = ensure(ctx)
        val all = try { t.voices?.toList() ?: emptyList() } catch (_: Exception) { emptyList() }
        val en = all.filter { it.locale.language == "en" && !(it.features?.contains("notInstalled") ?: false) }
        val counters = HashMap<String, Int>()
        fun rank(c: String): Int {
            val a = AFRICA.indexOf(c)
            if (a >= 0) return a
            return when (c) { "GB" -> 20; "US" -> 21; "AU" -> 22; "IN" -> 23; else -> 30 }
        }
        return en.sortedWith(compareBy({ rank(it.locale.country) }, { it.isNetworkConnectionRequired }, { it.name }))
            .map { v ->
                val country = v.locale.getDisplayCountry(Locale.ENGLISH).ifEmpty { "English" }
                val lower = v.name.lowercase()
                val gender = when {
                    lower.contains("female") -> "Female"
                    lower.contains("male") -> "Male"
                    else -> "Voice"
                }
                val key = "$country|$gender"
                val n = (counters[key] ?: 0) + 1
                counters[key] = n
                VoiceInfo(v.name, "$country · $gender $n",
                    if (v.isNetworkConnectionRequired) "needs internet" else "works offline")
            }
    }

    private fun apply(t: TextToSpeech, voiceName: String, rate: Float, pitch: Float) {
        val v = try { t.voices?.firstOrNull { it.name == voiceName } } catch (_: Exception) { null }
        if (v != null) t.voice = v else if (voiceName.isEmpty()) {
            try { t.language = Locale.US } catch (_: Exception) {}
        }
        t.setSpeechRate(rate)
        t.setPitch(pitch)
    }

    suspend fun synth(ctx: Context, text: String, voiceName: String, rate: Float, pitch: Float, out: File) {
        val t = ensure(ctx)
        apply(t, voiceName, rate, pitch)
        val id = UUID.randomUUID().toString()
        val done = CompletableDeferred<Boolean>()
        waiters[id] = done
        out.delete()
        val r = t.synthesizeToFile(text, Bundle(), out, id)
        if (r != TextToSpeech.SUCCESS) {
            waiters.remove(id)
            throw Exception("The phone voice could not start. Check that voice data is installed in Settings > Text-to-speech.")
        }
        val ok = try { withTimeout(90000) { done.await() } } catch (e: kotlinx.coroutines.TimeoutCancellationException) { false }
        if (!ok || !out.exists() || out.length() < 100) {
            throw Exception("The phone voice failed on: \"" + text.take(40) + "…\". If this voice needs internet, connect and retry, or pick another voice.")
        }
    }

    suspend fun speak(ctx: Context, text: String, voiceName: String, rate: Float, pitch: Float, volume: Float) {
        val t = ensure(ctx)
        apply(t, voiceName, rate, pitch)
        val b = Bundle()
        b.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, volume.coerceIn(0f, 1f))
        t.speak(text, TextToSpeech.QUEUE_FLUSH, b, "preview")
    }

    fun stop() { try { tts?.stop() } catch (_: Exception) {} }
}

/** Optional online AI voices. Needs internet and the user's own API key; the service bills the user. */
object OnlineTts {
    class ElVoice(val id: String, val name: String, val detail: String)

    private fun readError(c: HttpURLConnection): String {
        val body = try { c.errorStream?.bufferedReader()?.readText() ?: "" } catch (_: Exception) { "" }
        val msg = try {
            val o = JSONObject(body)
            val d = o.opt("detail")
            when {
                d is JSONObject -> d.optString("message", body)
                d is String -> d
                o.has("error") -> (o.optJSONObject("error")?.optString("message") ?: o.optString("error"))
                else -> body
            }
        } catch (_: Exception) { body }
        return "Online voice service replied ${c.responseCode}: ${msg.take(200)}"
    }

    fun elevenVoices(key: String): List<ElVoice> {
        val c = URL("https://api.elevenlabs.io/v1/voices").openConnection() as HttpURLConnection
        c.connectTimeout = 20000; c.readTimeout = 30000
        c.setRequestProperty("xi-api-key", key)
        try {
            if (c.responseCode != 200) throw Exception(readError(c))
            val o = JSONObject(c.inputStream.bufferedReader().readText())
            val arr = o.optJSONArray("voices") ?: return emptyList()
            val out = ArrayList<ElVoice>()
            for (i in 0 until arr.length()) {
                val v = arr.getJSONObject(i)
                val l = v.optJSONObject("labels")
                val bits = listOf(l?.optString("gender") ?: "", l?.optString("accent") ?: "", l?.optString("description") ?: "")
                    .filter { it.isNotEmpty() }
                out.add(ElVoice(v.getString("voice_id"), v.optString("name", "Voice"), bits.joinToString(" · ")))
            }
            return out
        } finally { c.disconnect() }
    }

    /** Requests speech as MP3 and writes it to [out]. */
    fun synth(text: String, narr: NarrStyle, speed: Float, out: File, voiceOverride: String = "") {
        val c: HttpURLConnection
        val body = JSONObject()
        if (Settings.provider == "elevenlabs") {
            val voiceId = voiceOverride.ifEmpty { Settings.elevenVoiceId }
            if (Settings.elevenKey.isEmpty() || voiceId.isEmpty())
                throw Exception("Online voice is selected but no ElevenLabs key and voice are set. Open SELECT VOICEOVER to add them.")
            c = URL("https://api.elevenlabs.io/v1/text-to-speech/$voiceId?output_format=mp3_44100_128")
                .openConnection() as HttpURLConnection
            c.setRequestProperty("xi-api-key", Settings.elevenKey)
            body.put("text", text)
            body.put("model_id", Settings.elevenModel)
            body.put("voice_settings", JSONObject()
                .put("stability", narr.stability.toDouble())
                .put("similarity_boost", 0.75)
                .put("style", narr.styleAmt.toDouble())
                .put("speed", (speed * narr.rate).coerceIn(0.7f, 1.2f).toDouble()))
        } else {
            if (Settings.customKey.isEmpty())
                throw Exception("Online voice is selected but no API key is set. Open SELECT VOICEOVER to add it.")
            c = URL(Settings.customUrl).openConnection() as HttpURLConnection
            c.setRequestProperty("Authorization", "Bearer ${Settings.customKey}")
            body.put("model", Settings.customModel)
            body.put("voice", voiceOverride.ifEmpty { Settings.customVoice })
            body.put("input", text)
            body.put("response_format", "mp3")
            body.put("speed", (speed * narr.rate).coerceIn(0.5f, 2f).toDouble())
            body.put("instructions", narr.instructions)
        }
        c.connectTimeout = 20000; c.readTimeout = 120000
        c.requestMethod = "POST"
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("Accept", "audio/mpeg")
        try {
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            if (c.responseCode !in 200..299) throw Exception(readError(c))
            c.inputStream.use { inp -> out.outputStream().use { inp.copyTo(it) } }
            if (out.length() < 200) throw Exception("Online voice service returned no audio")
        } catch (e: java.io.IOException) {
            throw Exception("Could not reach the online voice service. Check your internet connection. (${e.message})")
        } finally { c.disconnect() }
    }
}

/** Produces narration audio for one sentence and caches it, so retries don't redo finished work. */
object Narrator {
    private fun sha(s: String): String =
        MessageDigest.getInstance("SHA-1").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

    private fun writeShorts(f: File, s: ShortArray) {
        val bb = ByteBuffer.allocate(s.size * 2).order(ByteOrder.LITTLE_ENDIAN)
        bb.asShortBuffer().put(s)
        f.writeBytes(bb.array())
    }

    private fun readShorts(f: File): ShortArray {
        val b = f.readBytes()
        val s = ShortArray(b.size / 2)
        ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(s)
        return s
    }

    /** Mono 44.1 kHz samples with silence trimmed. */
    suspend fun sentence(ctx: Context, v: VoiceCfg, text: String): ShortArray {
        val dir = File(ctx.cacheDir, "narr").apply { mkdirs() }
        val narr = Styles.narr[v.narr.coerceIn(0, Styles.narr.size - 1)]
        val online = v.engine == "online"
        val key = sha((if (online) "on|" + Settings.onlineSignature() + "|" + v.onlineVoice else "ph|" + v.phoneVoice) + "|${v.narr}|${v.speed}|$text")
        val cached = File(dir, "$key.pcm")
        if (cached.exists() && cached.length() > 1000) return readShorts(cached)
        val pcm: ShortArray
        if (online) {
            val mp3 = File(dir, "$key.mp3")
            withContext(Dispatchers.IO) { OnlineTts.synth(text, narr, v.speed, mp3, v.onlineVoice) }
            pcm = Pcm.trim(Pcm.stereoToMono(Pcm.decodeToStereo(mp3.absolutePath, 600f)), SR)
            mp3.delete()
        } else {
            val wav = File(dir, "$key.wav")
            PhoneTts.synth(ctx, text, v.phoneVoice, v.speed * narr.rate, narr.pitch, wav)
            val (raw, rate) = Pcm.readWavMono(wav)
            pcm = Pcm.trim(Pcm.resampleMono(raw, rate, SR), SR)
            wav.delete()
        }
        if (pcm.size < SR / 20) throw Exception("The voice produced no sound for: \"" + text.take(40) + "…\"")
        writeShorts(cached, pcm)
        return pcm
    }

    fun clearOld(ctx: Context) {
        val dir = File(ctx.cacheDir, "narr")
        val cutoff = System.currentTimeMillis() - 7L * 24 * 3600 * 1000
        dir.listFiles()?.forEach { if (it.lastModified() < cutoff) it.delete() }
    }
}
