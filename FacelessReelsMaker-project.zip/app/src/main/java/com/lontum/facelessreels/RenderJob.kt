package com.lontum.facelessreels

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlin.coroutines.cancellation.CancellationException

/** Keeps the app alive while a long render runs with the screen off or the app in the background. */
class RenderService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel("render", "Video rendering", NotificationManager.IMPORTANCE_LOW))
            val n = Notification.Builder(this, "render")
                .setContentTitle("Creating your video")
                .setContentText("Rendering continues in the background")
                .setSmallIcon(android.R.drawable.stat_sys_download)
                .setOngoing(true)
                .build()
            if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
            else startForeground(1, n)
        } catch (_: Exception) {
            stopSelf()
        }
        return START_NOT_STICKY
    }

    companion object {
        fun start(ctx: Context) {
            try { ctx.startService(Intent(ctx, RenderService::class.java)) } catch (_: Exception) {}
        }
        fun stop(ctx: Context) {
            try { ctx.stopService(Intent(ctx, RenderService::class.java)) } catch (_: Exception) {}
        }
    }
}

/** The one running render job and its progress, observable from the screens. */
object RenderManager {
    var running by mutableStateOf(false)
    var progress by mutableFloatStateOf(0f)
    var message by mutableStateOf("")
    var error by mutableStateOf<String?>(null)
    var tooLong by mutableStateOf(false)
    var doneTick by mutableIntStateOf(0)
    var projectId by mutableStateOf("")
    var resolution by mutableStateOf("")

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    @Volatile private var cancelFlag = false

    fun start(ctx: Context, p: Project) {
        if (running) return
        val app = ctx.applicationContext
        running = true
        progress = 0f
        message = "Starting"
        error = null
        tooLong = false
        projectId = p.id
        cancelFlag = false
        RenderService.start(app)
        scope.launch {
            val wl = try {
                (app.getSystemService(Context.POWER_SERVICE) as PowerManager)
                    .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "facelessreels:render")
                    .apply { acquire(30 * 60 * 1000L) }
            } catch (_: Exception) { null }
            try {
                resolution = RenderEngine.render(app, p, { f, m -> progress = f; message = m }, { cancelFlag })
                doneTick++
            } catch (e: CancellationException) {
                message = "Cancelled"
            } catch (e: TooLongException) {
                tooLong = true
                error = e.message
            } catch (e: OutOfMemoryError) {
                error = "The phone ran out of memory while rendering. Close other apps, then tap Retry."
            } catch (e: Throwable) {
                error = e.message ?: e.toString()
            } finally {
                running = false
                try { wl?.release() } catch (_: Exception) {}
                RenderService.stop(app)
            }
        }
    }

    fun cancel() { cancelFlag = true }
}

/** Plays short previews (voices, music) straight from memory. */
object PcmPlayer {
    private var track: AudioTrack? = null

    fun play(samples: ShortArray, channels: Int) {
        stop()
        if (samples.isEmpty()) return
        try {
            val t = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                .setAudioFormat(AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(SR)
                    .setChannelMask(if (channels == 2) AudioFormat.CHANNEL_OUT_STEREO else AudioFormat.CHANNEL_OUT_MONO)
                    .build())
                .setTransferMode(AudioTrack.MODE_STATIC)
                .setBufferSizeInBytes(samples.size * 2)
                .build()
            t.write(samples, 0, samples.size)
            t.play()
            track = t
        } catch (_: Exception) {
        }
    }

    fun stop() {
        try { track?.stop() } catch (_: Exception) {}
        try { track?.release() } catch (_: Exception) {}
        track = null
    }
}
