package com.lontum.facelessreels

import android.graphics.Typeface

const val T_CROSS = 0
const val T_BLACK = 1
const val T_SLIDE = 2
const val T_ZOOM = 3
const val T_FLASH = 4
const val T_CUT = 5

class StyleSpec(
    val name: String,
    val desc: String,
    val transitions: IntArray,
    val transDur: Float,
    val zoom: Float,
    val maxShot: Float,
    val sat: Float,
    val contrast: Float,
    val tint: Int,
    val tintAmt: Float,
    val vignette: Float,
    val subLook: Int,
    val subFont: Int,
    val subColor: Int,
    val subHi: Int,
    val upper: Boolean,
    val mood: Int
)

class NarrStyle(
    val name: String, val rate: Float, val pitch: Float,
    val stability: Float, val styleAmt: Float, val instructions: String
)

class Platform(val name: String, val subY: Float, val maxTextWidth: Float, val bitrate: Int, val tags: List<String>)

object Styles {
    val styles = listOf(
        StyleSpec("Cinematic storytelling", "Slow zooms, soft cross-fades, teal film look, gold word highlight",
            intArrayOf(T_CROSS, T_ZOOM, T_CROSS, T_BLACK), 0.8f, 0.18f, 6f, 0.9f, 1.12f, 0xFF1B3A4B.toInt(), 0.10f, 0.55f,
            0, 0, 0, 2, false, 0),
        StyleSpec("Documentary style", "Steady pans, clean cuts, boxed captions, neutral colour",
            intArrayOf(T_CROSS, T_CROSS, T_SLIDE), 0.7f, 0.12f, 7f, 1.0f, 1.05f, 0, 0f, 0.3f,
            1, 1, 0, 3, false, 1),
        StyleSpec("Dramatic storytelling", "Hard contrast, fast push-ins, fades through black, red highlight",
            intArrayOf(T_BLACK, T_ZOOM, T_FLASH, T_CROSS), 0.6f, 0.24f, 5f, 0.8f, 1.25f, 0xFF200808.toInt(), 0.12f, 0.7f,
            0, 2, 0, 5, true, 2),
        StyleSpec("Motivational videos", "Quick cuts, energetic zooms, bright colour, bold highlighted words",
            intArrayOf(T_ZOOM, T_SLIDE, T_FLASH), 0.45f, 0.22f, 4f, 1.15f, 1.15f, 0xFFFF8A00.toInt(), 0.06f, 0.35f,
            2, 0, 0, 1, true, 3),
        StyleSpec("Educational videos", "Calm slides, gentle motion, clear boxed captions",
            intArrayOf(T_SLIDE, T_CROSS), 0.5f, 0.10f, 6f, 1.05f, 1.0f, 0, 0f, 0.15f,
            1, 1, 0, 4, false, 4),
        StyleSpec("Historical storytelling", "Sepia tone, long dissolves, classic serif captions",
            intArrayOf(T_CROSS, T_BLACK), 1.0f, 0.14f, 7f, 0.45f, 1.1f, 0xFF704214.toInt(), 0.22f, 0.6f,
            0, 3, 0, 8, false, 5),
        StyleSpec("Mystery and suspense", "Dark blue grade, heavy vignette, slow creeping zooms",
            intArrayOf(T_BLACK, T_CROSS, T_ZOOM), 0.9f, 0.20f, 6f, 0.6f, 1.2f, 0xFF0A1A3A.toInt(), 0.2f, 0.8f,
            0, 2, 0, 7, true, 6),
        StyleSpec("Inspirational storytelling", "Warm glow, smooth rising motion, uplifting captions",
            intArrayOf(T_CROSS, T_ZOOM, T_SLIDE), 0.7f, 0.16f, 6f, 1.1f, 1.05f, 0xFFFFC27A.toInt(), 0.08f, 0.3f,
            2, 0, 0, 2, false, 7)
    )

    val narr = listOf(
        NarrStyle("Natural", 1.0f, 1.0f, 0.5f, 0.2f, "Speak clearly and naturally, like a professional narrator."),
        NarrStyle("Calm storyteller", 0.92f, 0.97f, 0.6f, 0.25f, "Speak in a calm, warm, unhurried storytelling voice."),
        NarrStyle("Deep documentary", 0.95f, 0.85f, 0.65f, 0.15f, "Speak in a deep, steady, authoritative documentary voice."),
        NarrStyle("Dramatic", 0.88f, 0.9f, 0.35f, 0.6f, "Speak slowly and dramatically with tension and weight on key words."),
        NarrStyle("Energetic", 1.08f, 1.05f, 0.4f, 0.5f, "Speak with high energy, confidence and excitement."),
        NarrStyle("Warm and inspiring", 0.96f, 1.02f, 0.5f, 0.45f, "Speak in a warm, hopeful, inspiring tone.")
    )

    val platforms = listOf(
        Platform("Facebook Reels", 0.66f, 0.80f, 7_000_000, listOf("#reels", "#facebookreels", "#viral")),
        Platform("TikTok", 0.66f, 0.76f, 7_000_000, listOf("#fyp", "#foryou", "#tiktok")),
        Platform("YouTube Shorts", 0.70f, 0.82f, 8_000_000, listOf("#shorts", "#youtubeshorts", "#viral"))
    )

    val subLooks = listOf("Bold outline", "Dark box", "Highlight box")
    val fontNames = listOf("Heavy", "Clean", "Condensed", "Classic serif", "Typewriter")
    val colorNames = listOf("White", "Yellow", "Gold", "Sky blue", "Green", "Red", "Pink", "Purple", "Orange")
    val colors = intArrayOf(
        0xFFFFFFFF.toInt(), 0xFFFFEA00.toInt(), 0xFFFFD54A.toInt(), 0xFF4FC3F7.toInt(), 0xFF69F0AE.toInt(),
        0xFFFF5252.toInt(), 0xFFFF80AB.toInt(), 0xFFB388FF.toInt(), 0xFFFFAB40.toInt()
    )

    fun typeface(i: Int): Typeface = when (i) {
        1 -> Typeface.create("sans-serif-medium", Typeface.BOLD)
        2 -> Typeface.create("sans-serif-condensed", Typeface.BOLD)
        3 -> Typeface.create(Typeface.SERIF, Typeface.BOLD)
        4 -> Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        else -> Typeface.create("sans-serif-black", Typeface.NORMAL)
    }

    val moodNames = listOf(
        "Cinematic", "Documentary", "Dramatic", "Motivational",
        "Educational", "Historical", "Mystery", "Inspirational"
    )
}
