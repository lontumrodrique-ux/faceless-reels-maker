@file:OptIn(ExperimentalLayoutApi::class)

package com.lontum.facelessreels

import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

const val MOVIE_HELP = "Write who says what, one line each:\n\n" +
    "[Classroom]\n(Ama walks to the board)\nAMA (happy): Good morning, class!\nKOFI: Good morning, madam.\n" +
    "The lesson begins.\n\n" +
    "[Scene name] starts a new scene and picks the background with that name.\n" +
    "NAME: is a character from CHARACTERS. (emotion) is optional: happy, sad, angry, surprised, excited, confused, worried, serious.\n" +
    "A line in brackets is an action. A line without a name is read by the narrator."

const val MOVIE_EXAMPLE = "[Classroom]\n" +
    "The first day of the new term at the village school.\n" +
    "(Ama stands in front of the class)\n" +
    "AMA (happy): Good morning, everyone! Welcome back.\n" +
    "KOFI: Good morning, madam. We missed you.\n" +
    "AMA: Today we start something exciting. Who knows what water is made of?\n" +
    "KOFI (confused): Water? Is it not just water?\n" +
    "AMA (excited): It is two hydrogen atoms and one oxygen atom!\n" +
    "KOFI (surprised): Wow! So small, but so important."

private fun copyInto(ctx: Context, uri: Uri, dst: File): Boolean = try {
    dst.parentFile?.mkdirs()
    ctx.contentResolver.openInputStream(uri)?.use { inp -> dst.outputStream().use { inp.copyTo(it) } }
    dst.exists() && dst.length() > 0 && ImageLoader.thumb(dst.absolutePath, 64) != null
} catch (_: Exception) { false }

@Composable
private fun CompositePreview(p: Project, bg: Backdrop?, cast: List<Character>, height: Int = 300) {
    val ctx = LocalContext.current
    var img by remember { mutableStateOf<ImageBitmap?>(null) }
    var busy by remember { mutableStateOf(false) }
    val sig = (bg?.toJson()?.toString() ?: "") + cast.joinToString { it.toJson().toString() }
    LaunchedEffect(sig) {
        delay(350)
        busy = true
        img = withContext(Dispatchers.Default) {
            try { Compositor.preview(ctx, p, bg, cast).asImageBitmap() } catch (_: Throwable) { null }
        }
        busy = false
    }
    Box(Modifier.height(height.dp).aspectRatio(9f / 16f).clip(RoundedCornerShape(12.dp)).background(Color.Black),
        contentAlignment = Alignment.Center) {
        val b = img
        if (b != null) Image(b, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        if (busy) CircularProgressIndicator(Modifier.size(28.dp))
    }
}

// ---------- characters ----------

@Composable
fun CastScreen(p: Project, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var editing by remember { mutableStateOf<String?>(null) }
    var pendingName by remember { mutableStateOf("") }
    var replaceFor by remember { mutableStateOf<String?>(null) }
    var confirmDelete by remember { mutableStateOf<Character?>(null) }
    var phoneVoices by remember { mutableStateOf<List<VoiceInfo>>(emptyList()) }
    var elVoices by remember { mutableStateOf<List<OnlineTts.ElVoice>>(emptyList()) }
    var loadingVoices by remember { mutableStateOf(false) }
    val missing = MovieScript.unknownSpeakers(p)
    val imagesOnly = PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)

    LaunchedEffect(p.voice.engine) {
        if (p.voice.engine == "phone") try { phoneVoices = PhoneTts.voices(ctx) } catch (_: Exception) {}
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            val id = UUID.randomUUID().toString().take(8)
            val f = File(Store.dir(ctx, p.id), "chars/$id.img")
            val ok = withContext(Dispatchers.IO) { copyInto(ctx, uri, f) }
            if (!ok) { toast(ctx, "That file could not be read as a picture."); return@launch }
            val target = replaceFor
            if (target != null) {
                AppState.edit { pr -> pr.copy(chars = pr.chars.map { if (it.id == target) { File(it.file).delete(); it.copy(file = f.absolutePath) } else it }) }
                replaceFor = null
            } else {
                val name = pendingName.ifEmpty { "Character ${p.chars.size + 1}" }
                val narr = if (p.chars.size % 2 == 0) 0 else 1
                AppState.edit { it.copy(chars = it.chars + Character(id, name, f.absolutePath, narr = narr)) }
                editing = id
                pendingName = ""
            }
        }
    }

    fun setChar(id: String, f: (Character) -> Character) =
        AppState.edit { pr -> pr.copy(chars = pr.chars.map { if (it.id == id) f(it) else it }) }

    Screen("Characters (${p.chars.size})", onBack) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
            Note("Add one picture per character: a clear, front-facing photo of one person, face well lit, from the chest up works best. Use the same name as in your script.")
            if (missing.isNotEmpty()) {
                Label("SPEAKERS IN YOUR SCRIPT WITHOUT A PICTURE")
                FlowRow { missing.forEach { n -> Chip("＋ $n", false) { pendingName = n; replaceFor = null; picker.launch(imagesOnly) } } }
            }
            Spacer(Modifier.height(10.dp))
            for (c in p.chars) {
                val open = editing == c.id
                Panel(Modifier.padding(bottom = 10.dp), selected = open, onClick = { editing = if (open) null else c.id }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Thumb(c.file, Modifier.size(64.dp).clip(RoundedCornerShape(10.dp)))
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(c.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Note((if (p.voice.engine == "online") (c.onlineVoiceName.ifEmpty { "default online voice" })
                                  else (phoneVoices.firstOrNull { it.name == c.phoneVoice }?.label ?: "default phone voice")) +
                                " · " + Styles.narr[c.narr.coerceIn(0, Styles.narr.size - 1)].name)
                        }
                    }
                    if (open) {
                        Spacer(Modifier.height(10.dp))
                        OutlinedTextField(value = c.name, onValueChange = { v -> setChar(c.id) { it.copy(name = v.take(30)) } },
                            label = { Text("Name (as written in the script)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        Spacer(Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            CompositePreview(p, p.bgs.firstOrNull(), listOf(c), 240)
                            Column(Modifier.weight(1f)) {
                                Note(if (p.bgs.isEmpty()) "Preview of the picture the AI will animate." else "Preview in your first background.")
                                Spacer(Modifier.height(8.dp))
                                SmallButton("Change picture") { replaceFor = c.id; picker.launch(imagesOnly) }
                                Spacer(Modifier.height(8.dp))
                                SmallButton("▶ Hear voice") {
                                    scope.launch {
                                        try {
                                            val v = MovieBuilder.voiceFor(p, c)
                                            val narr = Styles.narr[v.narr.coerceIn(0, Styles.narr.size - 1)]
                                            val text = "Hello, my name is ${c.name}. Nice to meet you."
                                            if (v.engine == "phone") PhoneTts.speak(ctx, text, v.phoneVoice, v.speed * narr.rate, narr.pitch, v.volume)
                                            else PcmPlayer.play(withContext(Dispatchers.Default) { Narrator.sentence(ctx, v, text) }, 1)
                                        } catch (e: Exception) { toast(ctx, e.message ?: "Voice preview failed") }
                                    }
                                }
                            }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Place in background (remove photo background)", color = Color.White, fontSize = 14.sp, modifier = Modifier.weight(1f))
                            Switch(checked = c.cutout, onCheckedChange = { v -> setChar(c.id) { it.copy(cutout = v) } })
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Flip picture (face the other way)", color = Color.White, fontSize = 14.sp, modifier = Modifier.weight(1f))
                            Switch(checked = c.flip, onCheckedChange = { v -> setChar(c.id) { it.copy(flip = v) } })
                        }
                        Text("Size in scene · ${(c.size * 100).toInt()}%", color = Color.White, fontSize = 14.sp)
                        Slider(value = c.size, onValueChange = { v -> setChar(c.id) { it.copy(size = (v * 20).toInt() / 20f) } }, valueRange = 0.6f..1.5f)

                        Label("VOICE")
                        if (p.voice.engine == "phone") {
                            FlowRow {
                                Chip("Default", c.phoneVoice.isEmpty()) { setChar(c.id) { it.copy(phoneVoice = "") } }
                                phoneVoices.forEach { vi -> Chip(vi.label, c.phoneVoice == vi.name) { setChar(c.id) { it.copy(phoneVoice = vi.name) } } }
                            }
                            Note("Phone voices are free and offline. For realistic voices, choose Online AI voices in VOICES.")
                        } else if (Settings.provider == "elevenlabs") {
                            SmallButton(if (loadingVoices) "Loading…" else "Load my ElevenLabs voices", enabled = !loadingVoices && Settings.elevenKey.isNotEmpty()) {
                                loadingVoices = true
                                scope.launch {
                                    try { elVoices = withContext(Dispatchers.IO) { OnlineTts.elevenVoices(Settings.elevenKey) } }
                                    catch (e: Exception) { toast(ctx, e.message ?: "Could not load voices") }
                                    loadingVoices = false
                                }
                            }
                            if (Settings.elevenKey.isEmpty()) Note("Add your ElevenLabs key in VOICES first.", Danger)
                            Spacer(Modifier.height(6.dp))
                            FlowRow {
                                Chip("Default", c.onlineVoice.isEmpty()) { setChar(c.id) { it.copy(onlineVoice = "", onlineVoiceName = "") } }
                                elVoices.forEach { ev -> Chip(ev.name, c.onlineVoice == ev.id) { setChar(c.id) { it.copy(onlineVoice = ev.id, onlineVoiceName = ev.name) } } }
                                if (c.onlineVoice.isNotEmpty() && elVoices.none { it.id == c.onlineVoice }) Chip(c.onlineVoiceName.ifEmpty { "Chosen voice" }, true) {}
                            }
                        } else {
                            OutlinedTextField(value = c.onlineVoice, onValueChange = { v -> setChar(c.id) { it.copy(onlineVoice = v.trim(), onlineVoiceName = v.trim()) } },
                                label = { Text("Voice name for this character") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        }
                        Label("SPEAKING STYLE")
                        FlowRow { Styles.narr.forEachIndexed { i, n -> Chip(n.name, c.narr == i) { setChar(c.id) { it.copy(narr = i) } } } }
                        Spacer(Modifier.height(6.dp))
                        SmallButton("Delete character") { confirmDelete = c }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
        }
        Column(Modifier.padding(16.dp)) {
            BigButton("＋  ADD CHARACTER") { pendingName = ""; replaceFor = null; picker.launch(imagesOnly) }
        }
    }

    val del = confirmDelete
    if (del != null) {
        AlertDialog(onDismissRequest = { confirmDelete = null }, title = { Text("Delete ${del.name}?") },
            text = { Text("Their lines in the script will need a picture again before you can generate.") },
            confirmButton = {
                TextButton(onClick = {
                    File(del.file).delete()
                    AppState.edit { it.copy(chars = it.chars.filter { c -> c.id != del.id }) }
                    confirmDelete = null
                    editing = null
                }) { Text("Delete", color = Danger) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = null }) { Text("Cancel") } })
    }
}

// ---------- backgrounds ----------

@Composable
fun BackgroundsScreen(p: Project, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var editing by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia()) { uris ->
        if (uris.isEmpty()) return@rememberLauncherForActivityResult
        busy = true
        scope.launch {
            val added = withContext(Dispatchers.IO) {
                val out = ArrayList<Backdrop>()
                var n = p.bgs.size
                for (u in uris) {
                    val id = UUID.randomUUID().toString().take(8)
                    val f = File(Store.dir(ctx, p.id), "bgs/$id.img")
                    if (copyInto(ctx, u, f)) { n++; out.add(Backdrop(id, "Background $n", f.absolutePath)) } else f.delete()
                }
                out
            }
            AppState.edit { it.copy(bgs = it.bgs + added) }
            busy = false
            if (added.size < uris.size) toast(ctx, "${uris.size - added.size} file(s) could not be read as pictures.")
            if (added.isNotEmpty()) editing = added.first().id
        }
    }

    fun setBg(id: String, f: (Backdrop) -> Backdrop) =
        AppState.edit { pr -> pr.copy(bgs = pr.bgs.map { if (it.id == id) f(it) else it }) }

    Screen("Backgrounds (${p.bgs.size})", onBack) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
            Note("Import background pictures (JPG, PNG or WEBP). Name each one after the place, like \"Classroom\" or \"Office\": a script scene written as [Classroom] uses it automatically. You can also pick the background of each scene in PASTE YOUR SCRIPT > Scenes.")
            Spacer(Modifier.height(10.dp))
            for (b in p.bgs) {
                val open = editing == b.id
                Panel(Modifier.padding(bottom = 10.dp), selected = open, onClick = { editing = if (open) null else b.id }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Thumb(b.file, Modifier.size(width = 54.dp, height = 96.dp).clip(RoundedCornerShape(8.dp)))
                        Spacer(Modifier.width(12.dp))
                        Text(b.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.weight(1f))
                    }
                    if (open) {
                        Spacer(Modifier.height(10.dp))
                        OutlinedTextField(value = b.name, onValueChange = { v -> setBg(b.id) { it.copy(name = v.take(40)) } },
                            label = { Text("Place name (e.g. Classroom)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        Spacer(Modifier.height(10.dp))
                        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                            CompositePreview(p, b, p.chars.take(2), 340)
                        }
                        Note(if (p.chars.isEmpty()) "Add characters to see them placed here." else "Preview with your characters placed in this background.")
                        Text("Zoom · ${"%.2f".format(b.zoom)}×", color = Color.White, fontSize = 14.sp)
                        Slider(value = b.zoom, onValueChange = { v -> setBg(b.id) { it.copy(zoom = (v * 20).toInt() / 20f) } }, valueRange = 1f..3f)
                        Text("Left ↔ right", color = Color.White, fontSize = 14.sp)
                        Slider(value = b.x, onValueChange = { v -> setBg(b.id) { it.copy(x = (v * 20).toInt() / 20f) } }, valueRange = 0f..1f)
                        Text("Up ↕ down", color = Color.White, fontSize = 14.sp)
                        Slider(value = b.y, onValueChange = { v -> setBg(b.id) { it.copy(y = (v * 20).toInt() / 20f) } }, valueRange = 0f..1f)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Soft focus (film look, characters stand out)", color = Color.White, fontSize = 14.sp, modifier = Modifier.weight(1f))
                            Switch(checked = b.soft, onCheckedChange = { v -> setBg(b.id) { it.copy(soft = v) } })
                        }
                        SmallButton("Delete background") {
                            File(b.file).delete()
                            AppState.edit { it.copy(bgs = it.bgs.filter { x -> x.id != b.id }) }
                            editing = null
                        }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
        }
        Column(Modifier.padding(16.dp)) {
            BigButton(if (busy) "IMPORTING…" else "＋  IMPORT BACKGROUNDS", enabled = !busy) {
                picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            }
        }
    }
}

// ---------- AI animation ----------

@Composable
fun AiScreen(p: Project, onBack: () -> Unit) {
    var key by remember { mutableStateOf(Settings.falKey) }
    var model by remember { mutableStateOf(Settings.falModel) }
    val (sec, usd) = remember(p.script, p.chars, model) { MovieBuilder.estimate(p) }

    Screen("AI animation (fal.ai)", onBack) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
            Panel(selected = p.aiOn, onClick = { AppState.edit { it.copy(aiOn = !it.aiOn) } }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Make the characters talk with AI", color = Color.White, fontWeight = FontWeight.Bold)
                        Note("NEEDS INTERNET · PAID PER SECOND on your fal.ai account")
                    }
                    Switch(checked = p.aiOn, onCheckedChange = { v -> AppState.edit { it.copy(aiOn = v) } })
                }
            }
            Spacer(Modifier.height(6.dp))
            Note(if (p.aiOn) "Each spoken line is sent to the Kling AI Avatar model on fal.ai with the character's picture and voice. It returns the character talking with lip-sync, blinking, head movement and the expression of the line."
                 else "Off: the video is made for free with still pictures, so you can check timing, voices, captions and backgrounds before paying.")

            Label("fal.ai API KEY")
            OutlinedTextField(value = key, onValueChange = { key = it; Settings.falKey = it },
                label = { Text("Paste your fal.ai key") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Note("Your key stays on this phone and is sent only to fal.ai.")
            Spacer(Modifier.height(6.dp))
            Note("How to get one: open fal.ai in your browser, sign up, add credit under Billing (card payment), then create a key under Keys and paste it here. This app adds no fee and no subscription.")

            Label("QUALITY")
            FlowRow {
                Chip("Standard · about $0.056/s", model == Settings.FAL_STANDARD) { model = Settings.FAL_STANDARD; Settings.falModel = model }
                Chip("Pro · about $0.115/s", model == Settings.FAL_PRO) { model = Settings.FAL_PRO; Settings.falModel = model }
            }
            Note("Pro gives finer facial detail and smoother lip-sync for about double the price.")

            Label("COST OF THIS SCRIPT")
            Panel {
                Text("About ${sec.toInt()} seconds of talking ≈ US$${"%.2f".format(usd)}", color = Color.White, fontWeight = FontWeight.Bold)
                Note("Only character lines are animated; narrator lines are free. Lines already animated are reused without paying again, as long as their words, voice, picture and background stay the same. Prices are fal.ai's published rates and can change.")
            }

            Label("WHAT TO EXPECT")
            Note("• Characters talk one at a time, film-style: the speaker is shown, placed on their side of the scene and turned toward the other person.\n" +
                "• Each scene opens with everyone together in the background.\n" +
                "• Emotions come from the words or from (happy), (sad)… in the script; actions in brackets are suggested to the AI.\n" +
                "• The AI animates from one photo, so big body movements (walking, sitting down) are limited.\n" +
                "• Best results: one person per picture, face clearly visible, natural expression.")
            Spacer(Modifier.height(16.dp))
        }
    }
}

// ---------- scene breakdown ----------

@Composable
fun MovieScenesScreen(p: Project, onBack: () -> Unit) {
    val scenes = MovieScript.parse(p)
    Screen("Scenes (${scenes.size})", onBack) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
            Note("How the app understood your script: who is in each scene, who speaks, with which emotion, and the background used. Tap a background to change it for that scene.")
            Spacer(Modifier.height(10.dp))
            for (s in scenes) {
                Panel(Modifier.padding(bottom = 10.dp)) {
                    Text("Scene ${s.index + 1}" + (if (s.heading.isNotEmpty()) " · ${s.heading}" else ""),
                        color = Gold, fontWeight = FontWeight.Bold)
                    Note(if (s.cast.isEmpty()) "Narrator only" else "Characters: " + s.cast.joinToString(", ") { c ->
                        c.name + when (s.sideOf(c)) { -1 -> " (left)"; 1 -> " (right)"; else -> "" }
                    })
                    Spacer(Modifier.height(6.dp))
                    val chosen = p.sceneBgs[s.index.toString()]
                    FlowRow {
                        Chip("Auto" + (if (chosen == null && s.bg != null) ": ${s.bg.name}" else ""), chosen == null) {
                            AppState.edit { val m = it.sceneBgs.toMutableMap(); m.remove(s.index.toString()); it.copy(sceneBgs = m) }
                        }
                        Chip("No background", chosen == "none") {
                            AppState.edit { val m = it.sceneBgs.toMutableMap(); m[s.index.toString()] = "none"; it.copy(sceneBgs = m) }
                        }
                        p.bgs.forEach { b ->
                            Chip(b.name, chosen == b.id) {
                                AppState.edit { val m = it.sceneBgs.toMutableMap(); m[s.index.toString()] = b.id; it.copy(sceneBgs = m) }
                            }
                        }
                    }
                    for (l in s.lines) {
                        val who = l.speaker?.name ?: if (l.speakerName.isNotEmpty()) "${l.speakerName} (no picture!)" else "Narrator"
                        val emo = if (l.speaker != null && l.emotion != "neutral") " · ${l.emotion}" else ""
                        Text("$who$emo", color = if (l.speaker == null && l.speakerName.isNotEmpty()) Danger else Color.White,
                            fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
                        if (l.action.isNotEmpty()) Note("Action: " + l.action)
                        Text(l.text, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp, maxLines = 3,
                            overflow = TextOverflow.Ellipsis)
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}
