@file:OptIn(ExperimentalLayoutApi::class)

package com.lontum.facelessreels

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

fun toast(ctx: Context, msg: String) = Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()

// ---------- 1. script ----------

@Composable
fun ScriptScreen(p: Project, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val narrRate = Styles.narr[p.voice.narr.coerceIn(0, Styles.narr.size - 1)].rate
    val est = ScriptTools.estimateSeconds(p.script, p.voice.speed * narrRate)
    val words = ScriptTools.wordCount(p.script)
    val scenes = ScriptTools.scenes(p.script).size
    var confirmClear by remember { mutableStateOf(false) }

    Screen("Paste your script", onBack) {
        OutlinedTextField(
            value = p.script,
            onValueChange = { v -> AppState.edit { it.copy(script = v) } },
            placeholder = {
                Text(if (p.mode == "movie") MOVIE_HELP
                     else "Paste or type your full script here.\n\nLeave an empty line between paragraphs. Each paragraph becomes one scene.")
            },
            modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp),
            textStyle = MaterialTheme.typography.bodyLarge.copy(fontSize = 17.sp, lineHeight = 25.sp)
        )
        Column(Modifier.padding(12.dp)) {
            Text(
                if (words == 0) "Your script is used exactly as written. Nothing is rewritten or shortened."
                else "$words words · $scenes scenes · about ${fmtTime(est)} of narration",
                fontSize = 14.sp, color = Color.White
            )
            if (est > 120f) {
                Note("This looks longer than the 2-minute limit. Nothing will be cut: shorten the script or raise the voice speed before generating.", Danger)
            } else if (words > 0) {
                Note("Saved automatically. The exact length is known once the voice is generated.")
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SmallButton("Paste") {
                    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    val t = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(ctx)?.toString() ?: ""
                    if (t.isBlank()) toast(ctx, "Nothing to paste. Copy your script first.")
                    else AppState.edit { it.copy(script = if (it.script.isBlank()) t else it.script.trimEnd() + "\n\n" + t) }
                }
                if (p.mode == "movie") {
                    val ms = MovieScript.parse(p).size
                    SmallButton("Scenes ($ms)", enabled = ms > 0) { AppState.screen = "scenes" }
                    if (words == 0) SmallButton("Example") { AppState.edit { it.copy(script = MOVIE_EXAMPLE) } }
                } else {
                    SmallButton("Scenes ($scenes)", enabled = scenes > 0) { AppState.screen = "scenes" }
                }
                SmallButton("Clear", enabled = words > 0) { confirmClear = true }
            }
        }
    }
    if (confirmClear) {
        AlertDialog(onDismissRequest = { confirmClear = false }, title = { Text("Clear the whole script?") },
            confirmButton = {
                TextButton(onClick = { AppState.edit { it.copy(script = "") }; confirmClear = false }) { Text("Clear", color = Danger) }
            },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancel") } })
    }
}

@Composable
fun ScenesScreen(p: Project, onBack: () -> Unit) {
    val scenes = ScriptTools.scenes(p.script)
    var editing by remember { mutableStateOf(-1) }
    var editText by remember { mutableStateOf("") }
    var captionFor by remember { mutableStateOf(-1) }
    var captionText by remember { mutableStateOf("") }

    fun applyScenes(list: List<String>) = AppState.edit { it.copy(script = ScriptTools.joinScenes(list)) }

    Screen("Scenes (${scenes.size})", onBack) {
        Note("Each scene is one paragraph of your script. Move, edit or delete scenes here. \"Caption\" lets you change only the on-screen subtitle of a scene, without changing what the voice says.")
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(12.dp)) {
            itemsIndexed(scenes) { i, s ->
                Panel(Modifier.padding(bottom = 10.dp)) {
                    Text("Scene ${i + 1}", fontWeight = FontWeight.Bold, color = Gold, fontSize = 13.sp)
                    Text(s, color = Color.White, fontSize = 15.sp, maxLines = 4, overflow = TextOverflow.Ellipsis)
                    if (!p.subEdits[s].isNullOrBlank()) Note("Custom caption: " + p.subEdits[s])
                    Spacer(Modifier.height(8.dp))
                    FlowRow {
                        Chip("↑ Up", false) {
                            if (i > 0) { val l = scenes.toMutableList(); val t = l[i - 1]; l[i - 1] = l[i]; l[i] = t; applyScenes(l) }
                        }
                        Chip("↓ Down", false) {
                            if (i < scenes.size - 1) { val l = scenes.toMutableList(); val t = l[i + 1]; l[i + 1] = l[i]; l[i] = t; applyScenes(l) }
                        }
                        Chip("Edit", false) { editing = i; editText = s }
                        Chip("Caption", false) { captionFor = i; captionText = p.subEdits[s] ?: s }
                        Chip("Delete", false) { val l = scenes.toMutableList(); l.removeAt(i); applyScenes(l) }
                    }
                }
            }
        }
    }

    if (editing in scenes.indices) {
        AlertDialog(onDismissRequest = { editing = -1 }, title = { Text("Edit scene ${editing + 1}") },
            text = { OutlinedTextField(value = editText, onValueChange = { editText = it }, modifier = Modifier.height(220.dp)) },
            confirmButton = {
                TextButton(onClick = {
                    val l = scenes.toMutableList()
                    val v = editText.trim()
                    if (v.isEmpty()) l.removeAt(editing) else l[editing] = v
                    applyScenes(l)
                    editing = -1
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { editing = -1 }) { Text("Cancel") } })
    }
    if (captionFor in scenes.indices) {
        val key = scenes[captionFor]
        AlertDialog(onDismissRequest = { captionFor = -1 }, title = { Text("Caption for scene ${captionFor + 1}") },
            text = {
                Column {
                    Note("The voice still reads the script. Only the subtitle text changes.")
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = captionText, onValueChange = { captionText = it }, modifier = Modifier.height(180.dp))
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val v = captionText.trim()
                    AppState.edit {
                        val m = it.subEdits.toMutableMap()
                        if (v.isEmpty() || v == key) m.remove(key) else m[key] = v
                        it.copy(subEdits = m)
                    }
                    captionFor = -1
                }) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = {
                    AppState.edit { val m = it.subEdits.toMutableMap(); m.remove(key); it.copy(subEdits = m) }
                    captionFor = -1
                }) { Text("Use script text") }
            })
    }
}

// ---------- 2. pictures ----------

private fun copyUri(ctx: Context, uri: Uri, dst: File): Boolean = try {
    ctx.contentResolver.openInputStream(uri)?.use { inp -> dst.outputStream().use { inp.copyTo(it) } }
    dst.exists() && dst.length() > 0
} catch (_: Exception) { false }

private fun displayName(ctx: Context, uri: Uri): String {
    try {
        ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && c.moveToFirst()) return c.getString(i) ?: "audio"
        }
    } catch (_: Exception) {}
    return "audio"
}

@Composable
fun Thumb(path: String, modifier: Modifier) {
    val bmp by produceState<ImageBitmap?>(null, path) {
        value = withContext(Dispatchers.IO) { ImageLoader.thumb(path, 220)?.asImageBitmap() }
    }
    Box(modifier.background(Color(0xFF20232D)), contentAlignment = Alignment.Center) {
        val b = bmp
        if (b != null) Image(b, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
    }
}

@Composable
fun PicturesScreen(p: Project, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<String?>(null) }
    var assignOpen by remember { mutableStateOf(false) }
    val scenes = ScriptTools.scenes(p.script)

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia()) { uris ->
        if (uris.isNotEmpty()) {
            busy = true
            scope.launch {
                val added = withContext(Dispatchers.IO) {
                    val dir = File(Store.dir(ctx, p.id), "pics").apply { mkdirs() }
                    val out = ArrayList<Pic>()
                    for (u in uris) {
                        val id = UUID.randomUUID().toString().take(10)
                        val f = File(dir, "$id.img")
                        if (copyUri(ctx, u, f) && ImageLoader.thumb(f.absolutePath, 64) != null) out.add(Pic(id, f.absolutePath))
                        else f.delete()
                    }
                    out
                }
                AppState.edit { it.copy(pics = it.pics + added) }
                busy = false
                if (added.size < uris.size) toast(ctx, "${uris.size - added.size} file(s) could not be read as pictures and were skipped.")
            }
        }
    }
    val replacer = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        val target = selected
        if (uri != null && target != null) {
            scope.launch {
                val np = withContext(Dispatchers.IO) {
                    val dir = File(Store.dir(ctx, p.id), "pics").apply { mkdirs() }
                    val id = UUID.randomUUID().toString().take(10)
                    val f = File(dir, "$id.img")
                    if (copyUri(ctx, uri, f) && ImageLoader.thumb(f.absolutePath, 64) != null) Pic(id, f.absolutePath) else null
                }
                if (np == null) toast(ctx, "That file could not be read as a picture.")
                else {
                    AppState.edit { pr ->
                        pr.copy(pics = pr.pics.map { if (it.id == target) { File(it.file).delete(); np.copy(scene = it.scene) } else it })
                    }
                    selected = np.id
                }
            }
        }
    }
    val imagesOnly = PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)

    Screen("Import pictures (${p.pics.size})", onBack) {
        Column(Modifier.padding(horizontal = 12.dp)) {
            BigButton(if (busy) "IMPORTING…" else "＋  IMPORT PICTURES FROM GALLERY", enabled = !busy) { picker.launch(imagesOnly) }
            Spacer(Modifier.height(8.dp))
            Note("Pictures play in this order and are spread across your script automatically. Tap a picture to move it, replace it, delete it, or pin it to one scene. High-resolution pictures are fine.")
            Spacer(Modifier.height(8.dp))
        }
        LazyVerticalGrid(GridCells.Fixed(3), Modifier.weight(1f), contentPadding = PaddingValues(12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            itemsIndexed(p.pics, key = { _, pic -> pic.id }) { i, pic ->
                val sel = pic.id == selected
                Box(Modifier.aspectRatio(0.75f).clip(RoundedCornerShape(10.dp))
                    .border(if (sel) 3.dp else 0.dp, if (sel) Gold else Color.Transparent, RoundedCornerShape(10.dp))
                    .clickable { selected = if (sel) null else pic.id }) {
                    Thumb(pic.file, Modifier.fillMaxSize())
                    Text(" ${i + 1} ", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(4.dp).clip(RoundedCornerShape(6.dp)).background(Color(0xAA000000)))
                    if (pic.scene >= 0) {
                        Text(" Scene ${pic.scene + 1} ", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier.align(Alignment.BottomStart).padding(4.dp).clip(RoundedCornerShape(6.dp)).background(Gold))
                    }
                }
            }
        }
        val idx = p.pics.indexOfFirst { it.id == selected }
        if (idx >= 0) {
            val pic = p.pics[idx]
            Column(Modifier.background(MaterialTheme.colorScheme.surface).padding(12.dp)) {
                Text("Picture ${idx + 1}" + (if (pic.scene >= 0) " · pinned to scene ${pic.scene + 1}" else " · placed automatically"),
                    color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Spacer(Modifier.height(8.dp))
                FlowRow {
                    Chip("← Earlier", false) {
                        if (idx > 0) AppState.edit { val l = it.pics.toMutableList(); val t = l[idx - 1]; l[idx - 1] = l[idx]; l[idx] = t; it.copy(pics = l) }
                    }
                    Chip("Later →", false) {
                        if (idx < p.pics.size - 1) AppState.edit { val l = it.pics.toMutableList(); val t = l[idx + 1]; l[idx + 1] = l[idx]; l[idx] = t; it.copy(pics = l) }
                    }
                    Chip("Pin to scene", false) { assignOpen = true }
                    Chip("Replace", false) { replacer.launch(imagesOnly) }
                    Chip("Delete", false) {
                        File(pic.file).delete()
                        AppState.edit { it.copy(pics = it.pics.filter { x -> x.id != pic.id }) }
                        selected = null
                    }
                }
            }
        } else if (p.pics.any { it.scene >= 0 }) {
            Column(Modifier.padding(12.dp)) {
                SmallButton("Spread all pictures automatically (remove pins)") {
                    AppState.edit { it.copy(pics = it.pics.map { x -> x.copy(scene = -1) }) }
                }
            }
        }
    }

    if (assignOpen && selected != null) {
        AlertDialog(onDismissRequest = { assignOpen = false }, title = { Text("Show this picture during…") },
            text = {
                LazyColumn(Modifier.height(360.dp)) {
                    item {
                        Text("Automatic (spread across the script)", color = Gold,
                            modifier = Modifier.fillMaxWidth().clickable {
                                AppState.edit { it.copy(pics = it.pics.map { x -> if (x.id == selected) x.copy(scene = -1) else x }) }
                                assignOpen = false
                            }.padding(vertical = 12.dp))
                    }
                    itemsIndexed(scenes) { i, s ->
                        Text("Scene ${i + 1}: " + s.take(70), color = Color.White, maxLines = 2, overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.fillMaxWidth().clickable {
                                AppState.edit { it.copy(pics = it.pics.map { x -> if (x.id == selected) x.copy(scene = i) else x }) }
                                assignOpen = false
                            }.padding(vertical = 12.dp))
                    }
                    if (scenes.isEmpty()) item { Note("Paste your script first, then you can pin pictures to its scenes.") }
                }
            },
            confirmButton = { TextButton(onClick = { assignOpen = false }) { Text("Close") } })
    }
}

// ---------- 3. voice ----------

@Composable
fun VoiceScreen(p: Project, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val v = p.voice
    val narr = Styles.narr[v.narr.coerceIn(0, Styles.narr.size - 1)]
    val sample = "This is how your story will sound. Every great video starts with a voice people want to listen to."
    var voices by remember { mutableStateOf<List<VoiceInfo>?>(null) }
    var voiceError by remember { mutableStateOf<String?>(null) }
    var previewBusy by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        try { voices = PhoneTts.voices(ctx) } catch (e: Exception) { voiceError = e.message; voices = emptyList() }
    }

    fun set(f: (VoiceCfg) -> VoiceCfg) = AppState.edit { it.copy(voice = f(it.voice)) }

    Screen("Select voiceover", onBack) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
            Panel(Modifier.padding(bottom = 10.dp), selected = v.engine == "phone", onClick = { set { it.copy(engine = "phone") } }) {
                Text("Phone voices  ·  OFFLINE  ·  FREE", fontWeight = FontWeight.Bold, color = Color.White)
                Note("Uses the text-to-speech voices installed on this phone. No internet and no cost. Clear, but less human than CapCut.")
            }
            Panel(Modifier.padding(bottom = 4.dp), selected = v.engine == "online", onClick = { set { it.copy(engine = "online") } }) {
                Text("Online AI voices  ·  NEEDS INTERNET  ·  PAID SERVICE", fontWeight = FontWeight.Bold, color = Color.White)
                Note("Most realistic, CapCut-like narration. Works only with your own account and API key at a voice service, which bills you directly. This app adds no fee.")
            }

            if (v.engine == "phone") {
                Label("VOICE")
                val list = voices
                if (list == null) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(Modifier.size(22.dp)); Spacer(Modifier.width(10.dp)); Note("Loading the phone's voices…")
                    }
                } else if (list.isEmpty()) {
                    Note(voiceError ?: "No English voices are installed on this phone yet.", Danger)
                    Spacer(Modifier.height(8.dp))
                    SmallButton("Open the phone's voice settings") {
                        try { ctx.startActivity(Intent("com.android.settings.TTS_SETTINGS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                        catch (_: Exception) { toast(ctx, "Open Settings > System > Languages > Text-to-speech on your phone.") }
                    }
                } else {
                    Note("Accents depend on the voice data installed on your phone (for example Nigeria, Kenya, South Africa, UK, US, India, Australia). More can be downloaded in the phone's text-to-speech settings.")
                    Spacer(Modifier.height(6.dp))
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().clickable { set { it.copy(phoneVoice = "") } }) {
                        RadioButton(selected = v.phoneVoice.isEmpty(), onClick = { set { it.copy(phoneVoice = "") } })
                        Text("Phone default voice", color = Color.White)
                    }
                    for (vi in list) {
                        Row(verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth().clickable { set { it.copy(phoneVoice = vi.name) } }) {
                            RadioButton(selected = v.phoneVoice == vi.name, onClick = { set { it.copy(phoneVoice = vi.name) } })
                            Column(Modifier.weight(1f)) {
                                Text(vi.label, color = Color.White)
                                Text(vi.detail, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            SmallButton("▶ Preview") {
                                scope.launch {
                                    try { PhoneTts.speak(ctx, sample, vi.name, v.speed * narr.rate, narr.pitch, v.volume) }
                                    catch (e: Exception) { toast(ctx, e.message ?: "Preview failed") }
                                }
                            }
                        }
                    }
                    SmallButton("Get more voices (phone settings)", Modifier.padding(top = 8.dp)) {
                        try { ctx.startActivity(Intent("com.android.settings.TTS_SETTINGS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                        catch (_: Exception) { toast(ctx, "Open Settings > System > Languages > Text-to-speech on your phone.") }
                    }
                }
            } else {
                OnlineVoiceSetup()
            }

            Label("NARRATION STYLE")
            FlowRow { Styles.narr.forEachIndexed { i, n -> Chip(n.name, v.narr == i) { set { it.copy(narr = i) } } } }

            Label("NARRATION SPEED  ·  ${"%.2f".format(v.speed)}×")
            Slider(value = v.speed, onValueChange = { s -> set { it.copy(speed = (s * 20).toInt() / 20f) } }, valueRange = 0.7f..1.4f)

            Label("VOICE VOLUME  ·  ${(v.volume * 100).toInt()}%")
            Slider(value = v.volume, onValueChange = { s -> set { it.copy(volume = (s * 20).toInt() / 20f) } }, valueRange = 0.3f..1.5f)

            Spacer(Modifier.height(6.dp))
            BigButton(if (previewBusy) "PREPARING PREVIEW…" else "▶  PREVIEW THE SELECTED VOICE", enabled = !previewBusy) {
                if (v.engine == "phone") {
                    scope.launch {
                        try { PhoneTts.speak(ctx, sample, v.phoneVoice, v.speed * narr.rate, narr.pitch, v.volume) }
                        catch (e: Exception) { toast(ctx, e.message ?: "Preview failed") }
                    }
                } else if (!Settings.onlineReady()) {
                    toast(ctx, "Add your API key and choose a voice first.")
                } else {
                    previewBusy = true
                    scope.launch {
                        try {
                            val pcm = withContext(Dispatchers.Default) { Narrator.sentence(ctx, v, sample) }
                            PcmPlayer.play(pcm, 1)
                        } catch (e: Exception) { toast(ctx, e.message ?: "Preview failed") }
                        previewBusy = false
                    }
                }
            }
            Spacer(Modifier.height(20.dp))
        }
    }
}

@Composable
private fun OnlineVoiceSetup() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var provider by remember { mutableStateOf(Settings.provider) }
    var elKey by remember { mutableStateOf(Settings.elevenKey) }
    var elVoice by remember { mutableStateOf(Settings.elevenVoiceId) }
    var elVoiceName by remember { mutableStateOf(Settings.elevenVoiceName) }
    var elList by remember { mutableStateOf<List<OnlineTts.ElVoice>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var cuUrl by remember { mutableStateOf(Settings.customUrl) }
    var cuKey by remember { mutableStateOf(Settings.customKey) }
    var cuModel by remember { mutableStateOf(Settings.customModel) }
    var cuVoice by remember { mutableStateOf(Settings.customVoice) }

    Label("ONLINE VOICE SERVICE")
    FlowRow {
        Chip("ElevenLabs", provider == "elevenlabs") { provider = "elevenlabs"; Settings.provider = "elevenlabs" }
        Chip("Other (OpenAI-style)", provider == "custom") { provider = "custom"; Settings.provider = "custom" }
    }
    if (provider == "elevenlabs") {
        Note("Create an account at elevenlabs.io, then copy an API key from its developer settings. ElevenLabs charges about 1 credit per character of script. Its free plan gives a small monthly allowance but does not allow commercial (monetised) use; paid plans start at a few US dollars per month. Check elevenlabs.io/pricing for current prices.")
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = elKey, onValueChange = { elKey = it; Settings.elevenKey = it },
            label = { Text("ElevenLabs API key") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        SmallButton(if (loading) "Loading…" else "Load my voices", enabled = !loading && elKey.isNotBlank()) {
            loading = true
            scope.launch {
                try { elList = withContext(Dispatchers.IO) { OnlineTts.elevenVoices(elKey.trim()) } }
                catch (e: Exception) { toast(ctx, e.message ?: "Could not load voices") }
                loading = false
            }
        }
        if (elVoice.isNotEmpty()) Note("Selected voice: " + elVoiceName.ifEmpty { elVoice }, Good)
        for (ev in elList) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().clickable {
                elVoice = ev.id; elVoiceName = ev.name
                Settings.elevenVoiceId = ev.id; Settings.elevenVoiceName = ev.name
            }) {
                RadioButton(selected = elVoice == ev.id, onClick = {
                    elVoice = ev.id; elVoiceName = ev.name
                    Settings.elevenVoiceId = ev.id; Settings.elevenVoiceName = ev.name
                })
                Column {
                    Text(ev.name, color = Color.White)
                    if (ev.detail.isNotEmpty()) Text(ev.detail, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    } else {
        Note("For any service with an OpenAI-style /audio/speech address that returns MP3. You pay that service per use. Fill in the values the service gives you.")
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = cuUrl, onValueChange = { cuUrl = it; Settings.customUrl = it },
            label = { Text("Service address (URL)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = cuKey, onValueChange = { cuKey = it; Settings.customKey = it },
            label = { Text("API key") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = cuModel, onValueChange = { cuModel = it; Settings.customModel = it },
            label = { Text("Model name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = cuVoice, onValueChange = { cuVoice = it; Settings.customVoice = it },
            label = { Text("Voice name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
    }
    Note("Your key is stored only on this phone and is sent only to the voice service you chose.")
}

// ---------- 4. style ----------

@Composable
fun StyleScreen(p: Project, onBack: () -> Unit) {
    Screen("Select editing style", onBack) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
            Note("A style sets the transitions, picture movement, colour look, caption design and matching music together.")
            Spacer(Modifier.height(10.dp))
            Styles.styles.forEachIndexed { i, s ->
                Panel(Modifier.padding(bottom = 10.dp), selected = p.style == i, onClick = { AppState.edit { it.copy(style = i) } }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = p.style == i, onClick = { AppState.edit { it.copy(style = i) } })
                        Column {
                            Text("${i + 1}. ${s.name}", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 16.sp)
                            Note(s.desc)
                        }
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}

// ---------- 5. subtitles ----------

@Composable
private fun ColorDots(selected: Int, allowDefault: Boolean, onPick: (Int) -> Unit) {
    FlowRow(verticalArrangement = Arrangement.Center) {
        if (allowDefault) Chip("Style default", selected < 0) { onPick(-1) }
        Styles.colors.forEachIndexed { i, c ->
            Box(Modifier.padding(end = 10.dp, bottom = 8.dp).size(36.dp).clip(CircleShape).background(Color(c))
                .border(if (selected == i) 3.dp else 1.dp, if (selected == i) Accent else Color(0xFF555A6B), CircleShape)
                .clickable { onPick(i) })
        }
    }
}

@Composable
fun SubtitleScreen(p: Project, onBack: () -> Unit) {
    val s = p.sub
    fun set(f: (SubCfg) -> SubCfg) = AppState.edit { it.copy(sub = f(it.sub)) }
    Screen("Subtitles and captions", onBack) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Show subtitles", color = Color.White, modifier = Modifier.weight(1f))
                Switch(checked = s.on, onCheckedChange = { c -> set { it.copy(on = c) } })
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Highlight each word as it is spoken", color = Color.White, modifier = Modifier.weight(1f))
                Switch(checked = s.wordHi, onCheckedChange = { c -> set { it.copy(wordHi = c) } })
            }
            Note("Subtitles are made from your script and timed to the voice, a few words at a time, with automatic line breaks. To change the words of one caption, open PASTE YOUR SCRIPT > Scenes > Caption.")

            Label("CAPTION DESIGN")
            FlowRow {
                Chip("Style default", s.look < 0) { set { it.copy(look = -1) } }
                Styles.subLooks.forEachIndexed { i, n -> Chip(n, s.look == i) { set { it.copy(look = i) } } }
            }
            Label("FONT")
            FlowRow {
                Chip("Style default", s.font < 0) { set { it.copy(font = -1) } }
                Styles.fontNames.forEachIndexed { i, n -> Chip(n, s.font == i) { set { it.copy(font = i) } } }
            }
            Label("TEXT COLOUR")
            ColorDots(s.color, true) { c -> set { it.copy(color = c) } }
            Label("HIGHLIGHT COLOUR")
            ColorDots(s.hi, true) { c -> set { it.copy(hi = c) } }
            Label("POSITION")
            FlowRow {
                Chip("Auto (safe for the platform)", s.pos < 0) { set { it.copy(pos = -1) } }
                Chip("Top", s.pos == 0) { set { it.copy(pos = 0) } }
                Chip("Middle", s.pos == 1) { set { it.copy(pos = 1) } }
                Chip("Bottom", s.pos == 2) { set { it.copy(pos = 2) } }
            }
            Note("Auto keeps captions clear of the like, comment and caption areas of Facebook Reels, TikTok and YouTube Shorts.")
            Label("TEXT SIZE  ·  ${(s.size * 100).toInt()}%")
            Slider(value = s.size, onValueChange = { x -> set { it.copy(size = (x * 20).toInt() / 20f) } }, valueRange = 0.7f..1.4f)
            Spacer(Modifier.height(16.dp))
        }
    }
}

// ---------- 6. music ----------

@Composable
fun MusicScreen(p: Project, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val m = p.music
    val style = Styles.styles[p.style.coerceIn(0, Styles.styles.size - 1)]
    var busy by remember { mutableStateOf(false) }
    fun set(f: (MusicCfg) -> MusicCfg) = AppState.edit { it.copy(music = f(it.music)) }

    fun preview(mood: Int) {
        busy = true
        scope.launch {
            val pcm = withContext(Dispatchers.Default) { MusicSynth.generate(mood, 14f) }
            PcmPlayer.play(pcm, 2)
            busy = false
        }
    }

    val musicPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            busy = true
            scope.launch {
                val name = displayName(ctx, uri)
                val f = File(Store.dir(ctx, p.id), "music_" + UUID.randomUUID().toString().take(6))
                val ok = withContext(Dispatchers.IO) {
                    copyUri(ctx, uri, f) && try { Pcm.decodeToStereo(f.absolutePath, 2f).size > SR / 2 } catch (_: Exception) { false }
                }
                busy = false
                if (ok) set { old ->
                    if (old.file.isNotEmpty()) File(old.file).delete()
                    old.copy(kind = "file", file = f.absolutePath, fileName = name)
                } else { f.delete(); toast(ctx, "That file could not be read as music. Try an MP3 or M4A file.") }
            }
        }
    }
    val sfxPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            scope.launch {
                val name = displayName(ctx, uri)
                val f = File(Store.dir(ctx, p.id), "sfx_" + UUID.randomUUID().toString().take(6))
                val ok = withContext(Dispatchers.IO) {
                    copyUri(ctx, uri, f) && try { Pcm.decodeToStereo(f.absolutePath, 2f).size > SR / 10 } catch (_: Exception) { false }
                }
                if (ok) set { old ->
                    if (old.sfxFile.isNotEmpty()) File(old.sfxFile).delete()
                    old.copy(sfx = true, sfxFile = f.absolutePath, sfxName = name)
                } else { f.delete(); toast(ctx, "That file could not be read as a sound effect.") }
            }
        }
    }

    Screen("Add background music", onBack) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
            Note("The built-in tracks are composed inside the app itself, so they are free to use anywhere and work offline. You can also import your own music; make sure you have the right to use it.")
            Spacer(Modifier.height(10.dp))
            Panel(Modifier.padding(bottom = 8.dp), selected = m.kind == "auto", onClick = { set { it.copy(kind = "auto") } }) {
                Text("Match the editing style", fontWeight = FontWeight.Bold, color = Color.White)
                Note("Now: " + Styles.moodNames[style.mood] + " mood, for \"" + style.name + "\"")
            }
            Panel(Modifier.padding(bottom = 8.dp), selected = m.kind == "mood", onClick = { set { it.copy(kind = "mood") } }) {
                Text("Choose a built-in track", fontWeight = FontWeight.Bold, color = Color.White)
                Spacer(Modifier.height(8.dp))
                FlowRow {
                    Styles.moodNames.forEachIndexed { i, n ->
                        Chip(n, m.kind == "mood" && m.mood == i) { set { it.copy(kind = "mood", mood = i) }; preview(i) }
                    }
                }
                Note("Tap a track to select it and hear it.")
            }
            Panel(Modifier.padding(bottom = 8.dp), selected = m.kind == "file", onClick = { musicPicker.launch("audio/*") }) {
                Text("Import my own music", fontWeight = FontWeight.Bold, color = Color.White)
                Note(if (m.file.isNotEmpty()) "Imported: " + m.fileName + "  (tap to change)" else "Pick an audio file from your phone")
            }
            Panel(Modifier.padding(bottom = 8.dp), selected = m.kind == "none", onClick = { set { it.copy(kind = "none") } }) {
                Text("No music", fontWeight = FontWeight.Bold, color = Color.White)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SmallButton(if (busy) "Preparing…" else "▶ Preview music", enabled = !busy && m.kind != "none") {
                    when (m.kind) {
                        "file" -> {
                            busy = true
                            scope.launch {
                                try {
                                    val pcm = withContext(Dispatchers.IO) { Pcm.decodeToStereo(m.file, 15f) }
                                    PcmPlayer.play(pcm, 2)
                                } catch (e: Exception) { toast(ctx, e.message ?: "Could not play that file") }
                                busy = false
                            }
                        }
                        "mood" -> preview(m.mood)
                        else -> preview(style.mood)
                    }
                }
                SmallButton("■ Stop") { PcmPlayer.stop() }
            }

            Label("MUSIC VOLUME  ·  ${(m.volume * 100).toInt()}%")
            Slider(value = m.volume, onValueChange = { x -> set { it.copy(volume = (x * 20).toInt() / 20f) } }, valueRange = 0f..1f)
            Note("Voice volume is set separately in SELECT VOICEOVER.")
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Lower the music while the voice is speaking", color = Color.White, modifier = Modifier.weight(1f))
                Switch(checked = m.duck, onCheckedChange = { c -> set { it.copy(duck = c) } })
            }

            Label("SOUND EFFECTS")
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Whoosh sound on scene transitions", color = Color.White, modifier = Modifier.weight(1f))
                Switch(checked = m.sfx, onCheckedChange = { c -> set { it.copy(sfx = c) } })
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                SmallButton("Import my own effect") { sfxPicker.launch("audio/*") }
                if (m.sfxFile.isNotEmpty()) SmallButton("Use built-in whoosh") {
                    set { old -> File(old.sfxFile).delete(); old.copy(sfxFile = "", sfxName = "") }
                }
            }
            if (m.sfxFile.isNotEmpty()) Note("Using your effect: " + m.sfxName)
            Spacer(Modifier.height(20.dp))
        }
    }
}

// ---------- 7. preview and export ----------

@Composable
private fun CopyBlock(title: String, text: String) {
    val ctx = LocalContext.current
    Panel(Modifier.padding(bottom = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, fontWeight = FontWeight.Bold, color = Gold, fontSize = 13.sp, modifier = Modifier.weight(1f))
            SmallButton("Copy") {
                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText(title, text))
                toast(ctx, "Copied")
            }
        }
        Text(text, color = Color.White, fontSize = 14.sp)
    }
}

@Composable
fun PreviewScreen(p: Project, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val view = androidx.compose.ui.platform.LocalView.current
    val mine = RenderManager.projectId == p.id
    val running = RenderManager.running && mine
    val tick = RenderManager.doneTick
    val file = RenderEngine.outputFile(ctx, p.id)
    val exists = remember(tick, running) { file.exists() && file.length() > 1000 }
    val fresh = remember(tick, running, p) { RenderEngine.isFresh(ctx, p) }
    var exporting by remember { mutableStateOf(false) }
    var savedTo by remember { mutableStateOf<String?>(null) }
    var problem by remember { mutableStateOf<String?>(null) }

    androidx.compose.runtime.DisposableEffect(running) {
        view.keepScreenOn = running
        onDispose { view.keepScreenOn = false }
    }

    fun generate() {
        savedTo = null
        val issue = requestGenerate(ctx, p)
        if (issue != null) problem = issue
    }

    fun doExport() {
        exporting = true
        scope.launch {
            try {
                savedTo = withContext(Dispatchers.IO) { Exporter.saveToGallery(ctx, file, p.name) }
                toast(ctx, "Saved to your gallery")
            } catch (e: Exception) {
                toast(ctx, "Export failed: " + (e.message ?: "unknown error") + ". Tap EXPORT VIDEO to try again.")
            }
            exporting = false
        }
    }
    val storagePerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) doExport() else toast(ctx, "Storage permission is needed to save the video on this Android version.")
    }

    Screen("Video preview and export", onBack) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
            if (running) {
                Panel {
                    Text("Creating your video", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 17.sp)
                    Spacer(Modifier.height(10.dp))
                    Box(Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(5.dp)).background(MaterialTheme.colorScheme.surfaceVariant)) {
                        Box(Modifier.fillMaxWidth(RenderManager.progress.coerceIn(0.02f, 1f)).height(10.dp).clip(RoundedCornerShape(5.dp)).background(Accent))
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("${(RenderManager.progress * 100).toInt()}%  ·  ${RenderManager.message}", color = Color.White)
                    Spacer(Modifier.height(6.dp))
                    Note(if (p.mode == "movie" && p.aiOn && Settings.falKey.isNotEmpty())
                        "The AI animates all lines at the same time on fal.ai. This usually takes 3 to 15 minutes. You can leave the app; if it stops, tap Retry and finished lines are picked up without paying again."
                        else "A 1 to 2 minute video usually takes a few minutes. Rendering continues if you switch apps or the screen turns off.")
                    Spacer(Modifier.height(10.dp))
                    SmallButton("Cancel") { RenderManager.cancel() }
                }
            } else {
                val err = if (mine) RenderManager.error else null
                if (err != null) {
                    Panel(Modifier.padding(bottom = 10.dp)) {
                        Text(if (RenderManager.tooLong) "Script is too long" else "The video could not be created",
                            fontWeight = FontWeight.Bold, color = Danger, fontSize = 16.sp)
                        Spacer(Modifier.height(6.dp))
                        Text(err, color = Color.White, fontSize = 14.sp)
                        Spacer(Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            SmallButton("Retry") { generate() }
                            if (RenderManager.tooLong) {
                                SmallButton("Edit script") { AppState.screen = "script" }
                                SmallButton("Change speed") { AppState.screen = "voice" }
                            }
                        }
                        Note("Voice audio that was already generated is kept, so a retry continues from there.")
                    }
                }
                if (exists) {
                    if (!fresh) {
                        Note("You changed something since this video was made. Tap REGENERATE to see the changes.", Gold)
                        Spacer(Modifier.height(8.dp))
                    }
                    androidx.compose.runtime.key(tick) { VideoBox(file) }
                    if (fresh && RenderManager.resolution.isNotEmpty() && mine) {
                        Note("MP4 · H.264 + AAC · " + RenderManager.resolution + " · 30 fps · " +
                            "%.1f".format(file.length() / 1048576f) + " MB" +
                            (if (p.mode == "movie" && MovieEngine.lastNote.isNotEmpty()) " · " + MovieEngine.lastNote else ""))
                    }
                    Label("CHANGE SOMETHING")
                    FlowRow {
                        if (p.mode == "movie") {
                            Chip("Characters", false) { AppState.screen = "cast" }
                            Chip("Backgrounds", false) { AppState.screen = "backgrounds" }
                        }
                        Chip("Pictures", false) { AppState.screen = "pictures" }
                        Chip("Voice", false) { AppState.screen = "voice" }
                        Chip("Music", false) { AppState.screen = "music" }
                        Chip("Style", false) { AppState.screen = "style" }
                        Chip("Subtitles", false) { AppState.screen = "subs" }
                        Chip("Script", false) { AppState.screen = "script" }
                    }
                    SmallButton("↻  REGENERATE THE VIDEO") { generate() }
                } else if (err == null) {
                    Panel {
                        Text("No video yet", fontWeight = FontWeight.Bold, color = Color.White)
                        Note("Tap GENERATE VIDEO. The app will create the voice, time the pictures and subtitles, add music and render the MP4. Then you can watch it here before exporting.")
                    }
                }

                Label("PLATFORM")
                FlowRow {
                    Styles.platforms.forEachIndexed { i, pl -> Chip(pl.name, p.platform == i) { AppState.edit { it.copy(platform = i) } } }
                }
                Note("The platform sets the safe caption position and video quality, and the suggested hashtags below. Changing it needs a regenerate. You upload the video yourself; the app never asks for your social-media logins.")

                if (p.script.isNotBlank()) {
                    val sg = remember(p.script, p.platform) { ScriptTools.suggest(p.script, p.platform) }
                    Label("SUGGESTED TITLE, DESCRIPTION AND HASHTAGS")
                    sg.titles.forEachIndexed { i, t -> CopyBlock("Title option ${i + 1}", t) }
                    CopyBlock("Description", sg.description)
                    CopyBlock("Hashtags", sg.hashtags)
                    Note("These suggestions are built from the words of your own script on the phone, not by an online AI.")
                }
                Spacer(Modifier.height(12.dp))
            }
        }
        if (!running) {
            Column(Modifier.padding(16.dp)) {
                val s = savedTo
                if (s != null) { Note("Saved in your gallery: $s", Good); Spacer(Modifier.height(8.dp)) }
                if (exists) {
                    BigButton(if (exporting) "SAVING…" else "EXPORT VIDEO", enabled = !exporting, gold = true) {
                        if (android.os.Build.VERSION.SDK_INT < 29 &&
                            ctx.checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) !=
                            android.content.pm.PackageManager.PERMISSION_GRANTED
                        ) storagePerm.launch(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                        else doExport()
                    }
                } else {
                    BigButton("GENERATE VIDEO") { generate() }
                }
            }
        }
    }

    val pr = problem
    if (pr != null) {
        AlertDialog(onDismissRequest = { problem = null }, title = { Text("Not ready yet") }, text = { Text(pr) },
            confirmButton = { TextButton(onClick = { problem = null }) { Text("OK") } })
    }
}

@Composable
private fun VideoBox(file: File) {
    var player by remember { mutableStateOf<android.widget.VideoView?>(null) }
    var playing by remember { mutableStateOf(false) }
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
        Box(Modifier.height(430.dp).aspectRatio(9f / 16f).clip(RoundedCornerShape(14.dp)).background(Color.Black)
            .clickable {
                val vv = player ?: return@clickable
                if (vv.isPlaying) { vv.pause(); playing = false } else { vv.start(); playing = true }
            }) {
            androidx.compose.ui.viewinterop.AndroidView(
                factory = { c ->
                    android.widget.VideoView(c).apply {
                        setVideoPath(file.absolutePath)
                        setOnPreparedListener { mp -> mp.isLooping = false; seekTo(1) }
                        setOnCompletionListener { playing = false }
                        setOnErrorListener { _, _, _ -> playing = false; true }
                        player = this
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
            if (!playing) {
                Box(Modifier.align(Alignment.Center).size(64.dp).clip(CircleShape).background(Color(0xAA000000)),
                    contentAlignment = Alignment.Center) { Text("▶", color = Color.White, fontSize = 26.sp) }
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SmallButton(if (playing) "❚❚ Pause" else "▶ Play") {
                val vv = player
                if (vv != null) { if (vv.isPlaying) { vv.pause(); playing = false } else { vv.start(); playing = true } }
            }
            SmallButton("⏮ Restart") {
                val vv = player
                if (vv != null) { vv.seekTo(0); vv.start(); playing = true }
            }
        }
        Spacer(Modifier.height(6.dp))
    }
}
