package com.lontum.facelessreels

/** One spoken line in movie mode. speaker == null means the narrator. */
class MLine(
    val speaker: Character?,
    val speakerName: String,
    val text: String,
    val emotion: String,
    val action: String
)

class MScene(
    val index: Int,
    val heading: String,
    val lines: List<MLine>,
    val bg: Backdrop?,
    val cast: List<Character>
) {
    /** Where a character stands in this scene: -1 left, 0 centre, 1 right. */
    fun sideOf(c: Character): Int {
        if (cast.size <= 1) return 0
        val i = cast.indexOfFirst { it.id == c.id }
        return if (i % 2 == 0) -1 else 1
    }
}

/**
 * Reads a movie script written like this:
 *
 *   [Classroom]
 *   (Ama walks to the board)
 *   AMA (happy): Good morning, everyone!
 *   KOFI: Good morning, madam.
 *   The lesson begins.            <- no name = narrator
 */
object MovieScript {
    private val DIALOGUE = Regex("^([A-Za-z][A-Za-z0-9 .'_-]{0,30}?)\\s*(?:\\(([^)]{1,40})\\))?\\s*:\\s*(.+)$")
    private val HEADING_WORD = Regex("^(scene\\b\\s*\\d*|int\\.|ext\\.)\\s*[:.\\-–]?\\s*(.*)$", RegexOption.IGNORE_CASE)
    private val NARRATOR_NAMES = setOf("narrator", "voice over", "voiceover", "vo")

    private fun heading(line: String): String? {
        val t = line.trim()
        if (t.length >= 2 && t.startsWith("[") && t.endsWith("]")) {
            val inner = t.substring(1, t.length - 1).trim()
            val m = HEADING_WORD.find(inner)
            return if (m != null && inner.lowercase().startsWith("scene")) m.groupValues[2].trim() else inner
        }
        val m = HEADING_WORD.find(t) ?: return null
        return m.groupValues[2].trim()
    }

    private fun looksLikeName(name: String): Boolean {
        val words = name.trim().split(Regex("\\s+"))
        if (words.isEmpty() || words.size > 2) return false
        return words.all { w -> w.isNotEmpty() && w[0].isUpperCase() }
    }

    fun findCharacter(p: Project, name: String): Character? {
        val n = name.trim().lowercase()
        return p.chars.firstOrNull { it.name.trim().lowercase() == n }
            ?: p.chars.firstOrNull { it.name.trim().lowercase().split(" ").firstOrNull() == n }
    }

    /** Names used as speakers in the script that have no character picture yet. */
    fun unknownSpeakers(p: Project): List<String> {
        val out = LinkedHashSet<String>()
        for (raw in p.script.replace("\r\n", "\n").split("\n")) {
            val line = raw.trim()
            if (line.isEmpty() || heading(line) != null) continue
            val m = DIALOGUE.find(line) ?: continue
            val name = m.groupValues[1].trim()
            if (name.lowercase() in NARRATOR_NAMES) continue
            if (findCharacter(p, name) == null && looksLikeName(name)) {
                out.add(name.lowercase().split(" ").joinToString(" ") { w -> w.replaceFirstChar { it.uppercase() } })
            }
        }
        return out.toList()
    }

    fun parse(p: Project): List<MScene> {
        class Raw(val heading: String) { val lines = ArrayList<MLine>() }
        val raws = ArrayList<Raw>()
        var cur = Raw("")
        var pendingAction = ""
        for (raw in p.script.replace("\r\n", "\n").split("\n")) {
            val line = raw.trim()
            if (line.isEmpty()) continue
            val h = heading(line)
            if (h != null) {
                if (cur.lines.isNotEmpty() || cur.heading.isNotEmpty()) raws.add(cur)
                cur = Raw(h)
                pendingAction = ""
                continue
            }
            if (line.startsWith("(") && line.endsWith(")")) {
                pendingAction = line.substring(1, line.length - 1).trim()
                continue
            }
            val m = DIALOGUE.find(line)
            if (m != null) {
                val name = m.groupValues[1].trim()
                val emo = m.groupValues[2].trim()
                val text = m.groupValues[3].trim()
                if (name.lowercase() in NARRATOR_NAMES) {
                    cur.lines.add(MLine(null, "", text, "", ""))
                    continue
                }
                val c = findCharacter(p, name)
                if (c != null || looksLikeName(name)) {
                    cur.lines.add(MLine(c, name, text, detectEmotion(text, emo), pendingAction))
                    pendingAction = ""
                    continue
                }
            }
            cur.lines.add(MLine(null, "", line, "", ""))
        }
        if (cur.lines.isNotEmpty()) raws.add(cur)

        val scenes = ArrayList<MScene>()
        raws.filter { it.lines.isNotEmpty() }.forEachIndexed { i, r ->
            val cast = ArrayList<Character>()
            for (l in r.lines) { val c = l.speaker; if (c != null && cast.none { it.id == c.id }) cast.add(c) }
            scenes.add(MScene(i, r.heading, r.lines, backgroundFor(p, i, r.heading), cast))
        }
        return scenes
    }

    /** Chosen background for a scene: the one picked by hand, else one whose name appears in the heading, else in turn. */
    fun backgroundFor(p: Project, index: Int, heading: String): Backdrop? {
        val chosen = p.sceneBgs[index.toString()]
        if (chosen == "none") return null
        if (chosen != null) p.bgs.firstOrNull { it.id == chosen }?.let { return it }
        if (p.bgs.isEmpty()) return null
        val h = heading.lowercase()
        if (h.isNotEmpty()) {
            for (b in p.bgs) {
                val words = b.name.lowercase().split(Regex("[^a-z0-9]+")).filter { it.length >= 3 && it != "background" }
                if (words.any { h.contains(it) }) return b
            }
        }
        return p.bgs[index % p.bgs.size]
    }

    val EMOTIONS = listOf("neutral", "happy", "sad", "angry", "surprised", "excited", "confused", "worried", "serious", "calm")

    fun detectEmotion(text: String, explicit: String): String {
        val e = explicit.lowercase()
        if (e.isNotEmpty()) {
            for (k in EMOTIONS) if (e.contains(if (k.length <= 4) k else k.dropLast(1))) return k
            if (e.contains("laugh") || e.contains("smil") || e.contains("joy")) return "happy"
            if (e.contains("cry") || e.contains("tear")) return "sad"
            if (e.contains("shout") || e.contains("furious") || e.contains("mad")) return "angry"
            if (e.contains("shock")) return "surprised"
            if (e.contains("whisper")) return "worried"
            return e.take(30)
        }
        val t = text.lowercase()
        fun has(vararg w: String) = w.any { t.contains(it) }
        return when {
            has("sorry", "miss you", "died", "lost", "cry", "sad", "alone", "pain", "hurt") -> "sad"
            has("how dare", "stop it", "shut up", "i hate", "get out", "nonsense", "angry", "enough!") -> "angry"
            has("wow", "really?", "what?!", "no way", "oh my") -> "surprised"
            t.contains("!") && has("yes", "great", "amazing", "congrat", "we did", "let's go", "won") -> "excited"
            has("haha", "funny", "thank you", "love", "happy", "good morning", "welcome", "glad") -> "happy"
            has("i don't understand", "what do you mean", "why", "how come", "confus") && t.contains("?") -> "confused"
            has("afraid", "scared", "worried", "careful", "danger") -> "worried"
            t.contains("!") -> "excited"
            else -> "neutral"
        }
    }

    private fun emotionPhrase(e: String): String = when (e) {
        "happy" -> "with a warm, happy expression and a natural smile"
        "sad" -> "with a sad, emotional expression and soft eyes"
        "angry" -> "with an angry, intense expression and a frown"
        "surprised" -> "with a surprised expression, eyebrows raised"
        "excited" -> "with an excited, energetic expression"
        "confused" -> "with a confused, puzzled expression"
        "worried" -> "with a worried, nervous expression"
        "serious" -> "with a serious, focused expression"
        "calm", "neutral" -> "with a calm, natural expression"
        else -> "with a $e expression"
    }

    /** Instruction sent with each line to the talking-character AI. */
    fun prompt(line: MLine, side: Int, replying: Boolean): String {
        val direction = when (side) {
            -1 -> " to another person standing to their right, turning slightly and looking toward the right"
            1 -> " to another person standing to their left, turning slightly and looking toward the left"
            else -> ""
        }
        val sb = StringBuilder()
        sb.append("A realistic person speaking naturally").append(direction).append(", ")
        sb.append(emotionPhrase(line.emotion)).append(". ")
        sb.append("Accurate lip sync, natural blinking, subtle head movements and small natural hand gestures")
        if (replying) sb.append(", responding to what the other person just said")
        sb.append(". ")
        if (line.action.isNotEmpty()) sb.append("Action: ").append(line.action).append(". ")
        sb.append("Keep the same face, clothes, background and lighting. Steady camera, cinematic film look.")
        return sb.toString()
    }
}
