package com.lontum.facelessreels

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.media.MediaMetadataRetriever
import android.os.Build
import android.util.Base64
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.Segmentation
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions
import kotlinx.coroutines.delay
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.MessageDigest
import java.util.concurrent.TimeUnit
import kotlin.coroutines.cancellation.CancellationException
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

private fun sha1(b: ByteArray): String = MessageDigest.getInstance("SHA-1").digest(b).joinToString("") { "%02x".format(it) }
private fun sha1(s: String): String = sha1(s.toByteArray())

// ---------------------------------------------------------------- cut-out

class CutInfo(val bmp: Bitmap, val touchesBottom: Boolean)

/** Separates the person from the rest of their photo (on the phone, offline, with Google ML Kit). */
object Cutout {
    fun get(ctx: Context, projectId: String, c: Character): CutInfo? {
        if (!c.cutout) return null
        val f = File(c.file)
        if (!f.exists()) return null
        val tag = sha1(c.file + "|" + f.length())
        val dir = File(Store.dir(ctx, projectId), "cutouts").apply { mkdirs() }
        if (File(dir, "$tag.none").exists()) return null
        for (b in 0..1) {
            val cf = File(dir, "${tag}_$b.png")
            if (cf.exists()) BitmapFactory.decodeFile(cf.absolutePath)?.let { return CutInfo(it, b == 1) }
        }
        val made = make(c.file)
        if (made == null) {
            try { File(dir, "$tag.none").writeText("x") } catch (_: Exception) {}
            return null
        }
        try {
            File(dir, "${tag}_${if (made.touchesBottom) 1 else 0}.png").outputStream().use {
                made.bmp.compress(Bitmap.CompressFormat.PNG, 100, it)
            }
        } catch (_: Exception) {}
        return made
    }

    private fun make(path: String): CutInfo? {
        var src = try { ImageLoader.load(path, 900, 900) } catch (_: Exception) { return null }
        val maxSide = max(src.width, src.height)
        if (maxSide > 1100) {
            val k = 1100f / maxSide
            val s2 = Bitmap.createScaledBitmap(src, (src.width * k).toInt(), (src.height * k).toInt(), true)
            if (s2 != src) src.recycle()
            src = s2
        }
        val w = src.width
        val h = src.height
        val seg = Segmentation.getClient(
            SelfieSegmenterOptions.Builder().setDetectorMode(SelfieSegmenterOptions.SINGLE_IMAGE_MODE).build()
        )
        try {
            val mask = Tasks.await(seg.process(InputImage.fromBitmap(src, 0)), 60, TimeUnit.SECONDS)
            val mw = mask.width
            val mh = mask.height
            val buf: ByteBuffer = mask.buffer
            buf.rewind()
            val conf = FloatArray(mw * mh)
            buf.order(ByteOrder.nativeOrder()).asFloatBuffer().get(conf)
            val px = IntArray(w * h)
            src.getPixels(px, 0, w, 0, 0, w, h)
            var minX = w
            var minY = h
            var maxX = -1
            var maxY = -1
            var count = 0
            for (y in 0 until h) {
                val my = min(mh - 1, y * mh / h)
                for (x in 0 until w) {
                    val mx = min(mw - 1, x * mw / w)
                    val a0 = ((conf[my * mw + mx] - 0.3f) / 0.45f).coerceIn(0f, 1f)
                    val a = (a0 * a0 * (3f - 2f * a0) * 255f).toInt()
                    val i = y * w + x
                    px[i] = (a shl 24) or (px[i] and 0x00FFFFFF)
                    if (a > 60) {
                        count++
                        if (x < minX) minX = x
                        if (x > maxX) maxX = x
                        if (y < minY) minY = y
                        if (y > maxY) maxY = y
                    }
                }
            }
            val cover = count.toFloat() / (w * h)
            if (cover < 0.03f || cover > 0.97f || maxX <= minX || maxY <= minY) return null
            val full = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            full.setPixels(px, 0, w, 0, 0, w, h)
            val x0 = max(0, minX - 4)
            val y0 = max(0, minY - 4)
            val x1 = min(w, maxX + 5)
            val y1 = min(h, maxY + 5)
            val crop = Bitmap.createBitmap(full, x0, y0, x1 - x0, y1 - y0)
            if (crop != full) full.recycle()
            return CutInfo(crop, maxY >= h - 6)
        } catch (_: Throwable) {
            return null
        } finally {
            try { seg.close() } catch (_: Exception) {}
            src.recycle()
        }
    }
}

// ---------------------------------------------------------------- compositor

/** Builds the still frames the AI animates: the character placed inside the chosen background. */
object Compositor {
    const val CW = 720
    const val CH = 1280
    private val filterPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)

    private fun avgColor(b: Bitmap, opaqueOnly: Boolean): FloatArray {
        var r = 0f; var g = 0f; var bl = 0f; var n = 0
        val stepX = max(1, b.width / 40)
        val stepY = max(1, b.height / 40)
        var y = 0
        while (y < b.height) {
            var x = 0
            while (x < b.width) {
                val c = b.getPixel(x, y)
                if (!opaqueOnly || Color.alpha(c) > 160) {
                    r += Color.red(c); g += Color.green(c); bl += Color.blue(c); n++
                }
                x += stepX
            }
            y += stepY
        }
        if (n == 0) return floatArrayOf(128f, 128f, 128f)
        return floatArrayOf(r / n, g / n, bl / n)
    }

    /** Draws the background as framed by the user and returns its average colour. */
    fun drawBackground(c: Canvas, bg: Backdrop): FloatArray {
        val src = ImageLoader.load(bg.file, CW, CH)
        val base = Bitmap.createBitmap(CW, CH, Bitmap.Config.ARGB_8888)
        val bc = Canvas(base)
        val cover = max(CW.toFloat() / src.width, CH.toFloat() / src.height) * bg.zoom.coerceIn(1f, 3f)
        val dw = src.width * cover
        val dh = src.height * cover
        val m = Matrix()
        m.setScale(cover, cover)
        m.postTranslate(-(dw - CW) * bg.x.coerceIn(0f, 1f), -(dh - CH) * bg.y.coerceIn(0f, 1f))
        bc.drawBitmap(src, m, filterPaint)
        src.recycle()
        if (bg.soft) {
            // Gentle depth of field so the character stands out like in a film.
            val small = Bitmap.createScaledBitmap(base, CW / 8, CH / 8, true)
            val p = Paint(Paint.FILTER_BITMAP_FLAG)
            p.alpha = 150
            bc.drawBitmap(small, null, Rect(0, 0, CW, CH), p)
            small.recycle()
        }
        c.drawBitmap(base, 0f, 0f, null)
        val avg = avgColor(base, false)
        base.recycle()
        return avg
    }

    /** The character's own photo filling the frame (used when there is no background or no cut-out). */
    fun drawPhoto(c: Canvas, ch: Character, x: Int, y: Int, w: Int, h: Int) {
        val src = try { ImageLoader.load(ch.file, w, h) } catch (_: Exception) { return }
        val cover = max(w.toFloat() / src.width, h.toFloat() / src.height)
        val dw = src.width * cover
        val dh = src.height * cover
        val m = Matrix()
        if (ch.flip) {
            m.setScale(-cover, cover)
            m.postTranslate(x + w - (w - dw) / 2f, y + (h - dh) * 0.3f)
        } else {
            m.setScale(cover, cover)
            m.postTranslate(x + (w - dw) / 2f, y + (h - dh) * 0.3f)
        }
        c.save()
        c.clipRect(x, y, x + w, y + h)
        c.drawBitmap(src, m, filterPaint)
        c.restore()
        src.recycle()
    }

    private fun place(c: Canvas, cut: CutInfo, ch: Character, cx: Float, heightFrac: Float, bgAvg: FloatArray) {
        val b = cut.bmp
        val target = CH * heightFrac * ch.size.coerceIn(0.6f, 1.5f)
        var sc = target / b.height
        if (b.width * sc > CW * 0.95f) sc = CW * 0.95f / b.width
        val dw = b.width * sc
        val dh = b.height * sc
        val bottom = if (cut.touchesBottom) CH.toFloat() else CH * 0.95f
        val left = cx - dw / 2f
        val top = bottom - dh
        if (!cut.touchesBottom) {
            val sp = Paint(Paint.ANTI_ALIAS_FLAG)
            sp.color = Color.argb(110, 0, 0, 0)
            sp.maskFilter = BlurMaskFilter(dw * 0.06f + 1f, BlurMaskFilter.Blur.NORMAL)
            c.drawOval(RectF(cx - dw * 0.36f, bottom - dh * 0.022f, cx + dw * 0.36f, bottom + dh * 0.022f), sp)
        }
        // Match the character's colours to the light of the background.
        val ca = avgColor(b, true)
        fun k(i: Int) = ((bgAvg[i] + 25f) / (ca[i] + 25f)).pow(0.35f).coerceIn(0.82f, 1.18f)
        val cm = ColorMatrix()
        cm.setScale(k(0), k(1), k(2), 1f)
        val p = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
        p.colorFilter = ColorMatrixColorFilter(cm)
        val m = Matrix()
        if (ch.flip) {
            m.setScale(-sc, sc)
            m.postTranslate(left + dw, top)
        } else {
            m.setScale(sc, sc)
            m.postTranslate(left, top)
        }
        c.drawBitmap(b, m, p)
    }

    private fun save(bmp: Bitmap, out: File): String {
        out.parentFile?.mkdirs()
        val tmp = File(out.parentFile, out.name + ".tmp")
        tmp.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
        tmp.renameTo(out)
        bmp.recycle()
        return out.absolutePath
    }

    private fun dir(ctx: Context, p: Project) = File(ctx.cacheDir, "movie/${p.id}").apply { mkdirs() }

    private fun bgSig(bg: Backdrop?) = if (bg == null) "nobg" else "${bg.file}|${bg.zoom}|${bg.x}|${bg.y}|${bg.soft}"
    private fun chSig(c: Character) = "${c.file}|${c.flip}|${c.cutout}|${c.size}"

    /** One person speaking, placed on the side of the frame facing the person they talk to. */
    fun speakerShot(ctx: Context, p: Project, bg: Backdrop?, ch: Character, side: Int): String {
        val out = File(dir(ctx, p), "s_" + sha1(bgSig(bg) + "|" + chSig(ch) + "|" + side) + ".jpg")
        if (out.exists() && out.length() > 1000) return out.absolutePath
        val bmp = Bitmap.createBitmap(CW, CH, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(Color.BLACK)
        val cut = if (bg != null) Cutout.get(ctx, p.id, ch) else null
        if (bg == null || cut == null) {
            drawPhoto(c, ch, 0, 0, CW, CH)
        } else {
            val avg = drawBackground(c, bg)
            val cx = when (side) { -1 -> 0.40f; 1 -> 0.60f; else -> 0.5f } * CW
            place(c, cut, ch, cx, if (cut.touchesBottom) 0.66f else 0.84f, avg)
        }
        return save(bmp, out)
    }

    /** Everyone in the scene together (opening shot of each scene). */
    fun groupShot(ctx: Context, p: Project, bg: Backdrop?, cast: List<Character>): String {
        val out = File(dir(ctx, p), "g_" + sha1(bgSig(bg) + "|" + cast.joinToString(";") { chSig(it) }) + ".jpg")
        if (out.exists() && out.length() > 1000) return out.absolutePath
        val bmp = Bitmap.createBitmap(CW, CH, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(Color.BLACK)
        if (bg == null) {
            when {
                cast.isEmpty() -> {}
                cast.size == 1 -> drawPhoto(c, cast[0], 0, 0, CW, CH)
                else -> {
                    val n = min(cast.size, 3)
                    val hh = CH / n
                    for (i in 0 until n) drawPhoto(c, cast[i], 0, i * hh, CW, hh - (if (i < n - 1) 4 else 0))
                }
            }
        } else {
            val avg = drawBackground(c, bg)
            val n = min(cast.size, 3)
            val xs = when (n) { 1 -> floatArrayOf(0.5f); 2 -> floatArrayOf(0.3f, 0.7f); else -> floatArrayOf(0.2f, 0.5f, 0.8f) }
            for (i in 0 until n) {
                val cut = Cutout.get(ctx, p.id, cast[i]) ?: continue
                place(c, cut, cast[i], xs[i] * CW, if (cut.touchesBottom) 0.5f else 0.66f, avg)
            }
        }
        return save(bmp, out)
    }

    /** Small preview for the screens (not saved). */
    fun preview(ctx: Context, p: Project, bg: Backdrop?, cast: List<Character>): Bitmap {
        val path = if (cast.size == 1) speakerShot(ctx, p, bg, cast[0], 0) else groupShot(ctx, p, bg, cast)
        return BitmapFactory.decodeFile(path) ?: Bitmap.createBitmap(CW / 4, CH / 4, Bitmap.Config.ARGB_8888)
    }
}

// ---------------------------------------------------------------- fal.ai

/** Talks to fal.ai's queue API with the user's own key. */
object Fal {
    class Job(val statusUrl: String, val responseUrl: String)

    private fun open(url: String, method: String): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 25000
        c.readTimeout = 120000
        c.requestMethod = method
        c.setRequestProperty("Authorization", "Key " + Settings.falKey)
        c.setRequestProperty("Accept", "application/json")
        return c
    }

    private fun body(c: HttpURLConnection): String = try {
        (if (c.responseCode in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
    } catch (_: Exception) { "" }

    private fun failure(code: Int, text: String): Exception {
        val msg = try {
            val o = JSONObject(text)
            val d = o.opt("detail")
            when (d) {
                is String -> d
                is org.json.JSONArray -> (0 until d.length()).joinToString("; ") {
                    d.optJSONObject(it)?.optString("msg") ?: d.optString(it)
                }
                else -> o.optString("error", o.optString("message", text))
            }
        } catch (_: Exception) { text }
        val low = msg.lowercase()
        return when {
            code == 401 || code == 403 && !low.contains("balance") ->
                Exception("fal.ai did not accept your API key. Check it in AI ANIMATION. (${msg.take(120)})")
            code == 402 || low.contains("balance") || low.contains("exhausted") || low.contains("credit") ->
                Exception("Your fal.ai balance is empty. Add credit at fal.ai (Billing), then tap Retry. Lines already animated are kept and not charged again.")
            else -> Exception("fal.ai error $code: ${msg.take(220)}")
        }
    }

    private fun jsonCall(url: String, method: String, payload: JSONObject?): JSONObject {
        val c = open(url, method)
        try {
            if (payload != null) {
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
            }
            val code = c.responseCode
            val text = body(c)
            if (code !in 200..299) throw failure(code, text)
            return JSONObject(text)
        } catch (e: java.io.IOException) {
            throw Exception("Could not reach fal.ai. Check your internet connection, then tap Retry. (${e.message})")
        } finally { c.disconnect() }
    }

    /** Puts a file on fal's storage and returns its URL (falls back to sending it inline). */
    fun upload(bytes: ByteArray, type: String, name: String): String {
        for (host in listOf("https://rest.fal.ai", "https://rest.alpha.fal.ai")) {
            try {
                val init = jsonCall("$host/storage/upload/initiate?storage_type=fal-cdn-v3", "POST",
                    JSONObject().put("content_type", type).put("file_name", name))
                val up = init.optString("upload_url")
                val fileUrl = init.optString("file_url")
                if (up.isEmpty() || fileUrl.isEmpty()) continue
                val c = URL(up).openConnection() as HttpURLConnection
                try {
                    c.requestMethod = "PUT"
                    c.doOutput = true
                    c.connectTimeout = 25000
                    c.readTimeout = 120000
                    c.setRequestProperty("Content-Type", type)
                    c.setFixedLengthStreamingMode(bytes.size)
                    c.outputStream.use { it.write(bytes) }
                    if (c.responseCode in 200..299) return fileUrl
                } finally { c.disconnect() }
            } catch (e: Exception) {
                if (e.message?.contains("API key") == true || e.message?.contains("balance") == true) throw e
            }
        }
        return "data:$type;base64," + Base64.encodeToString(bytes, Base64.NO_WRAP)
    }

    fun submit(model: String, input: JSONObject): Job {
        val o = jsonCall("https://queue.fal.run/$model", "POST", input)
        val s = o.optString("status_url")
        val r = o.optString("response_url")
        if (s.isEmpty() || r.isEmpty()) throw Exception("fal.ai did not accept the request: " + o.toString().take(200))
        return Job(s, r)
    }

    fun status(job: Job): String = jsonCall(job.statusUrl, "GET", null).optString("status", "IN_QUEUE")

    fun videoUrl(job: Job): String {
        val o = jsonCall(job.responseUrl, "GET", null)
        val url = o.optJSONObject("video")?.optString("url") ?: ""
        if (url.isEmpty()) throw Exception("fal.ai finished but returned no video: " + o.toString().take(200))
        return url
    }

    fun download(url: String, out: File) {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 25000
        c.readTimeout = 180000
        try {
            if (c.responseCode !in 200..299) throw Exception("Could not download the animated clip (${c.responseCode}).")
            val tmp = File(out.parentFile, out.name + ".part")
            c.inputStream.use { inp -> tmp.outputStream().use { inp.copyTo(it) } }
            if (tmp.length() < 1000) throw Exception("The animated clip downloaded empty.")
            tmp.renameTo(out)
        } catch (e: java.io.IOException) {
            throw Exception("Download from fal.ai failed. Check your internet, then tap Retry. (${e.message})")
        } finally { c.disconnect() }
    }
}

class AiJob(val image: String, val wav: ByteArray, val prompt: String, val label: String) {
    var clip: String? = null
}

/** Sends every dialogue line to the talking-character AI, in parallel, and keeps results so nothing is paid twice. */
object AiAnimator {
    private fun dir(ctx: Context) = File(ctx.cacheDir, "ai").apply { mkdirs() }

    suspend fun run(ctx: Context, jobs: List<AiJob>, progress: (Float, String) -> Unit, cancelled: () -> Boolean) {
        if (jobs.isEmpty()) return
        val model = Settings.falModel
        val keys = jobs.map { j ->
            sha1(model + "|" + j.prompt + "|" + sha1(File(j.image).readBytes()) + "|" + sha1(j.wav))
        }
        val pending = HashMap<Int, Fal.Job>()
        for ((i, j) in jobs.withIndex()) {
            val mp4 = File(dir(ctx), keys[i] + ".mp4")
            if (mp4.exists() && mp4.length() > 1000) { j.clip = mp4.absolutePath; continue }
            val req = File(dir(ctx), keys[i] + ".req")
            if (req.exists()) {
                try {
                    val o = JSONObject(req.readText())
                    pending[i] = Fal.Job(o.getString("s"), o.getString("r"))
                    continue
                } catch (_: Exception) { req.delete() }
            }
            if (cancelled()) throw CancellationException("Cancelled")
            progress(i.toFloat() / jobs.size * 0.3f, "Sending ${j.label} to the AI (${i + 1} of ${jobs.size})")
            val imgUrl = Fal.upload(File(j.image).readBytes(), "image/jpeg", "shot_${keys[i].take(8)}.jpg")
            val audUrl = Fal.upload(j.wav, "audio/wav", "line_${keys[i].take(8)}.wav")
            val job = Fal.submit(model, JSONObject().put("image_url", imgUrl).put("audio_url", audUrl).put("prompt", j.prompt))
            req.writeText(JSONObject().put("s", job.statusUrl).put("r", job.responseUrl).toString())
            pending[i] = job
        }
        val total = jobs.size
        val started = System.currentTimeMillis()
        while (pending.isNotEmpty()) {
            val done = total - pending.size
            progress(0.3f + 0.7f * done / total, "AI is animating the characters: $done of $total lines ready")
            for (i in pending.keys.toList()) {
                if (cancelled()) throw CancellationException("Cancelled")
                val job = pending[i] ?: continue
                val st = try { Fal.status(job) } catch (e: Exception) {
                    if (e.message?.contains("404") == true) { File(dir(ctx), keys[i] + ".req").delete() }
                    throw e
                }
                if (st == "COMPLETED") {
                    val url = try { Fal.videoUrl(job) } catch (e: Exception) {
                        File(dir(ctx), keys[i] + ".req").delete()
                        throw Exception("The AI could not animate ${jobs[i].label}: ${e.message}")
                    }
                    val mp4 = File(dir(ctx), keys[i] + ".mp4")
                    Fal.download(url, mp4)
                    File(dir(ctx), keys[i] + ".req").delete()
                    jobs[i].clip = mp4.absolutePath
                    pending.remove(i)
                }
            }
            if (pending.isEmpty()) break
            if (System.currentTimeMillis() - started > 45L * 60 * 1000)
                throw Exception("fal.ai is taking unusually long. Tap Retry later: lines already sent will be picked up without paying again.")
            for (k in 0 until 10) {
                if (cancelled()) throw CancellationException("Cancelled")
                delay(500)
            }
        }
        progress(1f, "All lines animated")
    }

    fun clearOld(ctx: Context) {
        val cutoff = System.currentTimeMillis() - 30L * 24 * 3600 * 1000
        dir(ctx).listFiles()?.forEach { if (it.lastModified() < cutoff) it.delete() }
    }
}

// ---------------------------------------------------------------- timeline

class MSeg(val start: Float, var end: Float, val still: String, val clip: String?, val z0: Float, val z1: Float)

class MovieTimeline(
    val total: Float,
    val segs: List<MSeg>,
    val cues: List<Cue>,
    val narration: ShortArray,
    val sceneStarts: List<Float>,
    val animated: Int,
    val lines: Int
)

object MovieBuilder {
    private const val LEAD = 0.25f      // silence before each spoken line (gives the AI a closed mouth to start)
    private const val TAIL = 0.35f
    private const val MIN_LINE = 2.3f   // the AI needs at least about 2 seconds of audio

    fun voiceFor(p: Project, c: Character?): VoiceCfg =
        if (c == null) p.voice
        else VoiceCfg(p.voice.engine, c.phoneVoice.ifEmpty { p.voice.phoneVoice }, c.narr, p.voice.speed, p.voice.volume, c.onlineVoice)

    private fun wav(pcm: ShortArray): ByteArray {
        val data = pcm.size * 2
        val bb = ByteBuffer.allocate(44 + data).order(ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray()); bb.putInt(36 + data); bb.put("WAVE".toByteArray())
        bb.put("fmt ".toByteArray()); bb.putInt(16); bb.putShort(1); bb.putShort(1)
        bb.putInt(SR); bb.putInt(SR * 2); bb.putShort(2); bb.putShort(16)
        bb.put("data".toByteArray()); bb.putInt(data)
        for (s in pcm) bb.putShort(s)
        return bb.array()
    }

    /** Problems that stop a movie from being made, in plain words; null when ready. */
    fun problem(p: Project): String? {
        val scenes = MovieScript.parse(p)
        if (scenes.isEmpty()) return "Write your movie script first (step 1)."
        val missing = MovieScript.unknownSpeakers(p)
        if (missing.isNotEmpty()) return "These speakers have no picture yet: ${missing.joinToString(", ")}. Add them in CHARACTERS (step 2)."
        if (scenes.all { s -> s.lines.all { it.speaker == null } })
            return "No character speaks in this script. Write lines like \"AMA: Hello!\" with a name from CHARACTERS."
        for (c in p.chars) if (!File(c.file).exists()) return "The picture of ${c.name} is missing. Choose it again in CHARACTERS."
        return null
    }

    /** Rough talking time and cost before anything is generated. */
    fun estimate(p: Project): Pair<Float, Float> {
        var sec = 0f
        for (s in MovieScript.parse(p)) for (l in s.lines) if (l.speaker != null) {
            sec += max(MIN_LINE, ScriptTools.wordCount(l.text) / (150f * p.voice.speed) * 60f + LEAD + TAIL + 0.3f)
        }
        return Pair(sec, sec * Settings.falPricePerSecond())
    }

    suspend fun build(ctx: Context, p: Project, progress: (Float, String) -> Unit, cancelled: () -> Boolean): MovieTimeline {
        problem(p)?.let { throw Exception(it) }
        val scenes = MovieScript.parse(p)
        val style = Styles.styles[p.style.coerceIn(0, Styles.styles.size - 1)]

        // 1. Voices.
        class Spoken(val pcm: ShortArray, val sentStarts: IntArray, val sentLens: IntArray, val sentences: List<String>)
        val all = scenes.flatMap { it.lines }
        val spoken = ArrayList<Spoken>()
        for ((n, line) in all.withIndex()) {
            if (cancelled()) throw CancellationException("Cancelled")
            progress(0.01f + 0.19f * n / all.size, "Generating voices ${n + 1} of ${all.size}")
            val v = voiceFor(p, line.speaker)
            val sents = ScriptTools.sentences(line.text).ifEmpty { listOf(line.text) }
            val parts = sents.map { Narrator.sentence(ctx, v, it) }
            val gap = (0.14f * SR).toInt()
            val lead = if (line.speaker != null) (LEAD * SR).toInt() else 0
            val tail = if (line.speaker != null) (TAIL * SR).toInt() else 0
            var len = lead + parts.sumOf { it.size } + gap * (parts.size - 1) + tail
            if (line.speaker != null) len = max(len, (MIN_LINE * SR).toInt())
            val pcm = ShortArray(len)
            val st = IntArray(parts.size)
            val ln = IntArray(parts.size)
            var pos = lead
            for ((k, a) in parts.withIndex()) {
                System.arraycopy(a, 0, pcm, pos, a.size)
                st[k] = pos; ln[k] = a.size
                pos += a.size + gap
            }
            if (line.speaker != null && pcm.size > 50 * SR)
                throw Exception("A line of ${line.speakerName} is longer than 50 seconds. Split it into shorter lines.")
            spoken.add(Spoken(pcm, st, ln, sents))
        }

        // 2. Timeline.
        class Slot(val start: Float, val kind: Int, val scene: Int, val line: Int) // kind 0 = opening shot, 1 = line
        val slots = ArrayList<Slot>()
        val sceneStarts = ArrayList<Float>()
        var cur = 0.4f
        var li = 0
        for (s in scenes) {
            sceneStarts.add(if (s.index == 0) 0f else cur)
            if (s.lines.first().speaker != null) {
                slots.add(Slot(cur, 0, s.index, -1))
                cur += 1.3f
            }
            for (l in s.lines) {
                slots.add(Slot(cur, 1, s.index, li))
                cur += spoken[li].pcm.size.toFloat() / SR + (if (l.speaker != null) 0.08f else 0.25f)
                li++
            }
            cur += 0.35f
        }
        val total = cur + 1.2f
        if (total > TimelineBuilder.MAX_SECONDS + 0.5f) throw TooLongException(total)
        val narr = ShortArray((total * SR).toInt())
        for (sl in slots) if (sl.kind == 1) {
            val a = spoken[sl.line].pcm
            val at = (sl.start * SR).toInt()
            if (at < narr.size) System.arraycopy(a, 0, narr, at, min(a.size, narr.size - at))
        }

        // 3. Pictures for every shot.
        progress(0.21f, "Placing characters in the backgrounds")
        val stills = arrayOfNulls<String>(slots.size)
        val jobs = ArrayList<AiJob>()
        val jobOfSlot = IntArray(slots.size) { -1 }
        var picIdx = 0
        var prevSpeaker: String? = null
        for ((k, sl) in slots.withIndex()) {
            if (cancelled()) throw CancellationException("Cancelled")
            val s = scenes[sl.scene]
            if (sl.kind == 0) {
                stills[k] = Compositor.groupShot(ctx, p, s.bg, s.cast)
                prevSpeaker = null
                continue
            }
            val line = all[sl.line]
            val c = line.speaker
            if (c == null) {
                stills[k] = if (p.pics.isNotEmpty()) p.pics[picIdx++ % p.pics.size].file
                else Compositor.groupShot(ctx, p, s.bg, s.cast)
                continue
            }
            val side = s.sideOf(c)
            stills[k] = Compositor.speakerShot(ctx, p, s.bg, c, side)
            val replying = prevSpeaker != null && prevSpeaker != c.id
            prevSpeaker = c.id
            jobOfSlot[k] = jobs.size
            jobs.add(AiJob(stills[k]!!, wav(spoken[sl.line].pcm), MovieScript.prompt(line, side, replying),
                "${c.name}'s line"))
        }

        // 4. Talking animation (paid, online) or a free still preview.
        val useAi = p.aiOn && Settings.falKey.isNotEmpty()
        if (useAi) {
            AiAnimator.run(ctx, jobs, { f, m -> progress(0.23f + f * 0.55f, m) }, cancelled)
        }

        // 5. Segments and captions.
        val segs = ArrayList<MSeg>()
        for ((k, sl) in slots.withIndex()) {
            val end = if (k + 1 < slots.size) slots[k + 1].start else total
            val clip = if (jobOfSlot[k] >= 0) jobs[jobOfSlot[k]].clip else null
            val push = k % 2 == 0
            segs.add(MSeg(sl.start, end, stills[k] ?: "", clip, if (push) 1f else 1.06f, if (push) 1.06f else 1f))
        }
        if (segs.isNotEmpty() && segs[0].start > 0f) segs[0] = MSeg(0f, segs[0].end, segs[0].still, segs[0].clip, segs[0].z0, segs[0].z1)

        val cues = ArrayList<Cue>()
        val maxChars = if (style.upper) 16 else 18
        for (sl in slots) if (sl.kind == 1) {
            val sp = spoken[sl.line]
            val line = all[sl.line]
            val who = line.speaker?.name ?: ""
            for ((k, sentence) in sp.sentences.withIndex()) {
                val t0 = sl.start + sp.sentStarts[k].toFloat() / SR
                val t1 = t0 + sp.sentLens[k].toFloat() / SR
                val words = ArrayList<Word>()
                TimelineBuilder.timeWords(sentence, t0 + 0.03f, t1 - 0.06f, words)
                var group = ArrayList<Word>()
                var chars = 0
                for (w in words) {
                    if (group.isNotEmpty() && (group.size >= 3 || chars + w.text.length + 1 > maxChars)) {
                        cues.add(Cue(group.first().start, group.last().end, group, who)); group = ArrayList(); chars = 0
                    }
                    group.add(w); chars += w.text.length + 1
                }
                if (group.isNotEmpty()) cues.add(Cue(group.first().start, group.last().end, group, who))
            }
        }
        for (i in cues.indices) {
            val next = if (i + 1 < cues.size) cues[i + 1].start else Float.MAX_VALUE
            cues[i].end = min(next, cues[i].end + 0.3f)
        }
        val animated = jobs.count { it.clip != null }
        return MovieTimeline(total, segs, cues, narr, sceneStarts, animated, jobs.size)
    }
}

// ---------------------------------------------------------------- frame drawing

/** Reads frames from an AI clip in order, a few at a time. */
class ClipReader(path: String) {
    private val mmr = MediaMetadataRetriever()
    private var count = 0
    private var fps = 25f
    private var batch: List<Bitmap> = emptyList()
    private var batchStart = -1
    private var single: Bitmap? = null
    private var singleIdx = -1
    var ok = false
        private set

    init {
        try {
            mmr.setDataSource(path)
            val dur = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            if (Build.VERSION.SDK_INT >= 28) {
                count = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_FRAME_COUNT)?.toIntOrNull() ?: 0
            }
            if (count > 0 && dur > 0) fps = count * 1000f / dur
            if (count <= 0) count = max(1, (dur / 1000f * fps).toInt())
            ok = dur > 0
        } catch (_: Exception) { ok = false }
    }

    fun frame(sec: Float): Bitmap? {
        if (!ok) return null
        val idx = (sec * fps).toInt().coerceIn(0, count - 1)
        if (Build.VERSION.SDK_INT >= 28) {
            if (batchStart >= 0 && idx >= batchStart && idx < batchStart + batch.size) return batch[idx - batchStart]
            try {
                batch.forEach { it.recycle() }
                batch = emptyList()
                batch = mmr.getFramesAtIndex(idx, min(8, count - idx))
                batchStart = idx
                if (batch.isNotEmpty()) return batch[0]
            } catch (_: Exception) {}
        }
        if (idx == singleIdx && single != null) return single
        return try {
            val b = mmr.getFrameAtTime((idx * 1_000_000L / fps).toLong(), MediaMetadataRetriever.OPTION_CLOSEST)
            single?.recycle()
            single = b
            singleIdx = idx
            b
        } catch (_: Exception) { single }
    }

    fun release() {
        batch.forEach { try { it.recycle() } catch (_: Exception) {} }
        batch = emptyList()
        try { single?.recycle() } catch (_: Exception) {}
        try { mmr.release() } catch (_: Exception) {}
    }
}

/** Captions for movie mode: same look as narration captions, plus the speaker's name. */
class SubtitlePainter(private val p: Project, private val cues: List<Cue>, private val W: Int, private val H: Int) {
    private val style = Styles.styles[p.style.coerceIn(0, Styles.styles.size - 1)]
    private val platform = Styles.platforms[p.platform.coerceIn(0, Styles.platforms.size - 1)]
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val namePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val look = if (p.sub.look >= 0) p.sub.look else style.subLook
    private val baseColor = Styles.colors[(if (p.sub.color >= 0) p.sub.color else style.subColor).coerceIn(0, Styles.colors.size - 1)]
    private val hiColor = Styles.colors[(if (p.sub.hi >= 0) p.sub.hi else style.subHi).coerceIn(0, Styles.colors.size - 1)]
    private val posY = when (p.sub.pos) { 0 -> 0.2f; 1 -> 0.5f; 2 -> 0.75f; else -> platform.subY }
    private var ci = 0

    init {
        val tf = Styles.typeface(if (p.sub.font >= 0) p.sub.font else style.subFont)
        textPaint.typeface = tf
        strokePaint.typeface = tf
        strokePaint.style = Paint.Style.STROKE
        strokePaint.strokeJoin = Paint.Join.ROUND
        strokePaint.color = Color.BLACK
        namePaint.typeface = Styles.typeface(1)
    }

    fun draw(c: Canvas, t: Float) {
        if (!p.sub.on || cues.isEmpty()) return
        while (ci < cues.size - 1 && t >= cues[ci].end) ci++
        while (ci > 0 && t < cues[ci].start) ci--
        val cue = cues[ci]
        if (t < cue.start || t >= cue.end) return
        val texts = cue.words.map { if (style.upper) it.text.uppercase() else it.text }
        val maxW = W * platform.maxTextWidth
        var size = W * 0.074f * p.sub.size
        textPaint.textSize = size
        var widest = 0f
        for (s in texts) widest = max(widest, textPaint.measureText(s))
        if (widest > maxW) { size *= maxW / widest; textPaint.textSize = size }
        strokePaint.textSize = size
        strokePaint.strokeWidth = size * (if (look == 1) 0.07f else 0.17f)
        val space = textPaint.measureText(" ")
        val widths = FloatArray(texts.size) { textPaint.measureText(texts[it]) }
        val lineStart = ArrayList<Int>()
        val lineEnd = ArrayList<Int>()
        val lineW = ArrayList<Float>()
        var st = 0
        var lw = 0f
        for (i in texts.indices) {
            val add = widths[i] + (if (i > st) space else 0f)
            if (i > st && lw + add > maxW) {
                lineStart.add(st); lineEnd.add(i); lineW.add(lw)
                st = i; lw = widths[i]
            } else lw += add
        }
        lineStart.add(st); lineEnd.add(texts.size); lineW.add(lw)
        var active = 0
        for (i in cue.words.indices) if (t >= cue.words[i].start) active = i
        val lineH = size * 1.24f
        val blockH = lineH * lineStart.size
        val cy = H * posY
        val asc = textPaint.ascent()
        val desc = textPaint.descent()
        if (cue.speaker.isNotEmpty()) {
            namePaint.textSize = size * 0.5f
            val nw = namePaint.measureText(cue.speaker)
            val ny = cy - blockH / 2 - size * 0.45f
            boxPaint.color = 0xCC000000.toInt()
            c.drawRoundRect(W / 2f - nw / 2 - size * 0.3f, ny - size * 0.5f, W / 2f + nw / 2 + size * 0.3f, ny + size * 0.16f,
                size * 0.2f, size * 0.2f, boxPaint)
            namePaint.color = hiColor
            c.drawText(cue.speaker, W / 2f - nw / 2, ny, namePaint)
        }
        if (look == 1) {
            var bw = 0f
            for (x in lineW) bw = max(bw, x)
            boxPaint.color = 0xB8000000.toInt()
            c.drawRoundRect(W / 2f - bw / 2 - size * 0.45f, cy - blockH / 2 - size * 0.28f, W / 2f + bw / 2 + size * 0.45f,
                cy + blockH / 2 + size * 0.28f, size * 0.3f, size * 0.3f, boxPaint)
        }
        var y = cy - blockH / 2 + lineH / 2 - (asc + desc) / 2
        for (ln in lineStart.indices) {
            var x = W / 2f - lineW[ln] / 2
            for (i in lineStart[ln] until lineEnd[ln]) {
                val isAct = p.sub.wordHi && i == active
                if (isAct && look == 2) {
                    boxPaint.color = hiColor
                    c.drawRoundRect(x - size * 0.16f, y + asc - size * 0.02f, x + widths[i] + size * 0.16f,
                        y + desc + size * 0.04f, size * 0.22f, size * 0.22f, boxPaint)
                }
                c.drawText(texts[i], x, y, strokePaint)
                textPaint.color = if (isAct && look != 2) hiColor else baseColor
                c.drawText(texts[i], x, y, textPaint)
                x += widths[i] + space
            }
            y += lineH
        }
    }
}

class MoviePainter(private val p: Project, private val tl: MovieTimeline, private val W: Int, private val H: Int) : FrameSource {
    private val style = Styles.styles[p.style.coerceIn(0, Styles.styles.size - 1)]
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val plain = Paint(Paint.FILTER_BITMAP_FLAG)
    private val overlay = Paint()
    private val m = Matrix()
    private val subs = SubtitlePainter(p, tl.cues, W, H)
    private val stills = LinkedHashMap<String, Bitmap>(4, 0.75f, true)
    private var reader: ClipReader? = null
    private var readerPath = ""
    private var vignette: Bitmap? = null
    private val full = Rect(0, 0, W, H)
    private var si = 0

    init {
        val cm = ColorMatrix()
        cm.setSaturation(style.sat)
        val k = 1f + (style.contrast - 1f) * 0.6f
        val o = 128f * (1f - k)
        cm.postConcat(ColorMatrix(floatArrayOf(k, 0f, 0f, 0f, o, 0f, k, 0f, 0f, o, 0f, 0f, k, 0f, o, 0f, 0f, 0f, 1f, 0f)))
        if (style.tintAmt > 0f) {
            val a = style.tintAmt * 0.7f
            val q = 1f - a
            cm.postConcat(ColorMatrix(floatArrayOf(
                q, 0f, 0f, 0f, a * Color.red(style.tint), 0f, q, 0f, 0f, a * Color.green(style.tint),
                0f, 0f, q, 0f, a * Color.blue(style.tint), 0f, 0f, 0f, 1f, 0f
            )))
        }
        bmpPaint.colorFilter = ColorMatrixColorFilter(cm)
        if (style.vignette > 0.01f) {
            val vw = W / 4
            val vh = H / 4
            val vb = Bitmap.createBitmap(vw, vh, Bitmap.Config.ARGB_8888)
            val vp = Paint()
            vp.shader = RadialGradient(vw / 2f, vh / 2f, hypot(vw / 2f, vh / 2f),
                intArrayOf(0, 0, Color.argb((style.vignette * 200).toInt(), 0, 0, 0)), floatArrayOf(0f, 0.55f, 1f),
                Shader.TileMode.CLAMP)
            Canvas(vb).drawRect(0f, 0f, vw.toFloat(), vh.toFloat(), vp)
            vignette = vb
        }
    }

    private fun still(path: String): Bitmap? {
        stills[path]?.let { return it }
        while (stills.size >= 2) { val k = stills.keys.first(); stills.remove(k)?.recycle() }
        val b = try { ImageLoader.load(path, (W * 1.1f).toInt(), (H * 1.1f).toInt()) } catch (_: Exception) { null } ?: return null
        stills[path] = b
        return b
    }

    private fun cover(c: Canvas, b: Bitmap, zoom: Float) {
        val sc = max(W.toFloat() / b.width, H.toFloat() / b.height) * zoom
        m.reset()
        m.setScale(sc, sc)
        m.postTranslate((W - b.width * sc) / 2f, (H - b.height * sc) * 0.4f)
        c.drawBitmap(b, m, bmpPaint)
    }

    private fun wash(c: Canvas, color: Int, a: Float) {
        overlay.color = color
        overlay.alpha = (a.coerceIn(0f, 1f) * 255).toInt()
        c.drawRect(0f, 0f, W.toFloat(), H.toFloat(), overlay)
    }

    override fun draw(c: Canvas, t: Float) {
        c.drawColor(Color.BLACK)
        val segs = tl.segs
        if (segs.isNotEmpty()) {
            while (si < segs.size - 1 && t >= segs[si].end) si++
            while (si > 0 && t < segs[si].start) si--
            val s = segs[si]
            var drawn = false
            val clip = s.clip
            if (clip != null) {
                if (readerPath != clip) {
                    reader?.release()
                    reader = ClipReader(clip)
                    readerPath = clip
                }
                val f = reader?.frame(t - s.start)
                if (f != null) { cover(c, f, 1f); drawn = true }
            }
            if (!drawn) {
                val b = still(s.still)
                if (b != null) {
                    val u = ((t - s.start) / max(0.01f, s.end - s.start)).coerceIn(0f, 1f)
                    cover(c, b, s.z0 + (s.z1 - s.z0) * u)
                }
            }
        }
        vignette?.let { c.drawBitmap(it, null, full, plain) }
        subs.draw(c, t)
        for (st in tl.sceneStarts) {
            if (st <= 0f) continue
            val d = abs(t - st)
            if (d < 0.3f) wash(c, Color.BLACK, 1f - d / 0.3f)
        }
        if (t < 0.5f) wash(c, Color.BLACK, 1f - t / 0.5f)
        if (t > tl.total - 1f) wash(c, Color.BLACK, t - (tl.total - 1f))
    }

    override fun release() {
        reader?.release()
        reader = null
        stills.values.forEach { try { it.recycle() } catch (_: Exception) {} }
        stills.clear()
        vignette?.recycle()
        vignette = null
    }
}

object MovieEngine {
    var lastNote = ""

    suspend fun render(ctx: Context, p: Project, progress: (Float, String) -> Unit, cancelled: () -> Boolean): String {
        val tl = MovieBuilder.build(ctx, p, progress, cancelled)
        lastNote = when {
            !p.aiOn || Settings.falKey.isEmpty() -> "Free test: still pictures, no AI animation"
            tl.animated < tl.lines -> "${tl.animated} of ${tl.lines} lines animated"
            else -> "All ${tl.lines} lines animated by AI"
        }
        val style = Styles.styles[p.style.coerceIn(0, Styles.styles.size - 1)]
        if (cancelled()) throw CancellationException("Cancelled")
        progress(0.8f, "Mixing voices and music")
        val sfxAt = tl.sceneStarts.filter { it > 0f }.map { ((it - 0.25f) * SR).toInt() }
        val audio = RenderEngine.mixAndEncode(p, tl.narration, tl.total, sfxAt, style)
        progress(0.83f, "Starting video encoder")
        return RenderEngine.encodeVideo(ctx, p, tl.total, audio, { w, h -> MoviePainter(p, tl, w, h) }, 0.84f, progress, cancelled)
    }
}
